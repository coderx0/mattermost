// Client for OpenRouter's Decisions API (POST /api/alpha/decisions). A decision
// model never writes text: it answers typed questions about a `state` with
// probabilities. https://openrouter.ai/docs/api/api-reference/alphadecisions

export type NoulQuestion = {
  type: 'noul'
  instructions: string
  criteria: { true: string; false: string }
}

export type ChoiceQuestion = {
  type: 'choice'
  instructions: string
  /** option key → what choosing it means */
  criteria: Record<string, string>
}

export type Question = NoulQuestion | ChoiceQuestion

/** Probability that the answer is yes. */
export type NoulAnswer = { type: 'noul'; noul: number }

export type ChoiceAnswer = {
  type: 'choice'
  choice: string
  confidence?: number
  probabilities?: Record<string, number>
}

export type Answer = NoulAnswer | ChoiceAnswer

/** Questions in one request are answered independently: none sees another's answer. */
export type DecideRequest = { state: unknown; questions: Record<string, Question> }

export type Decide = (request: DecideRequest, signal?: AbortSignal) => Promise<Record<string, Answer>>

/** The API rejects a choice question with more options than this. */
export const MAX_CRITERIA = 255

/** `model`: an OpenRouter decision model id (see models.ts). */
export function openRouterDecide(apiKey: string, model: string, fetchImpl: typeof fetch = (...a) => fetch(...a)): Decide {
  return async (request, signal) => {
    const res = await fetchImpl('https://openrouter.ai/api/alpha/decisions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, ...request }),
      signal,
    })
    const body = (await res.json().catch(() => null)) as {
      answers?: Record<string, Answer>
      error?: { message?: string }
    } | null
    if (!res.ok || !body?.answers) {
      throw new Error(`Decisions API ${res.status}: ${body?.error?.message ?? res.statusText}`)
    }
    return body.answers
  }
}

/** Probability of yes; 0 if the question wasn't answered. */
export function noul(answers: Record<string, Answer>, key: string) {
  const a = answers[key]
  return a?.type === 'noul' ? a.noul : 0
}

/** The chosen option and the alternatives, most probable first. */
export function choice(answers: Record<string, Answer>, key: string) {
  const a = answers[key]
  if (a?.type !== 'choice') throw new Error(`no answer for "${key}"`)
  const ranked = Object.entries(a.probabilities ?? { [a.choice]: a.confidence ?? 1 })
    .sort((x, y) => y[1] - x[1])
    .map(([option, p]) => ({ option, p }))
  return { choice: a.choice, confidence: a.confidence ?? ranked[0]?.p ?? 0, ranked }
}
