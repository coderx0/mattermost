import type { SemanticNode, SemanticState } from '@agent-om/core'
import { indexNodes } from './describe'

// Rules enforced outside the model (docs/semantic-projection.md §12): they read
// the projection at the moment of acting, never what the model "thinks".

/**
 * Why a decision made on an earlier snapshot no longer applies to its target,
 * or undefined if it still does. Unrelated changes elsewhere don't matter.
 */
export function staleReason(decided: SemanticNode, now: SemanticState): string | undefined {
  const current = indexNodes(now.root).get(decided.id)?.node
  if (!current) return 'it is no longer on the page'
  if (current.role !== decided.role || current.name !== decided.name) return 'it changed'
  if (current.state?.disabled) return 'it is disabled now'
  return undefined
}

/** Why the user must confirm before acting on this node, or undefined. From projected metadata only. */
export function confirmationReason(node: SemanticNode): string | undefined {
  if (node.confirmationRequired) return 'it requires confirmation'
  if (node.risk === 'destructive') return 'it is destructive'
  if (node.risk === 'sensitive') return 'it is sensitive'
  return undefined
}
