import { locate, type SitemapNode } from '@agent-om/core/sitemap'

// The app's sitemap as the model reads it: one line per page, indented under
// the page it sits below, with its name, views and what it holds, and the
// current page marked.
// It says what exists and where; the agent still gets there page by page,
// through the links each page has.

/**
 *     /: Home
 *       campaigns ?view=archived
 *         {campaignId} ?tab=performance|ad-groups|settings   ← you are here (tab=ad-groups)
 *       products/{handle} — holds: Product Information, Shipping & Returns
 */
export function siteOutline(map: SitemapNode, path: string, query: Record<string, unknown> = {}): string[] {
  const here = locate(map, path, query)
  const lines: string[] = []
  const visit = (node: SitemapNode, depth: number) => {
    let line = `${'  '.repeat(depth)}${node.path}`
    if (node.name) line += `: ${node.name}`
    for (const [param, values] of Object.entries(node.views ?? {})) line += ` ?${param}=${values.join('|')}`
    if (node.holds?.length) line += ` — holds: ${node.holds.join(', ')}`
    if (node === here?.node) {
      const views = Object.entries(here.views).map(([k, v]) => `${k}=${v}`)
      line += `   ← you are here${views.length ? ` (${views.join(', ')})` : ''}`
    }
    lines.push(line)
    for (const child of node.children ?? []) visit(child, depth + 1)
  }
  visit(map, 0)
  return lines
}
