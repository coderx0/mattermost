import type { SemanticNode, SemanticProjector, SemanticState } from '@agent-om/core'
import { sleep } from './util'

/** Some part of the page says it's still loading or updating (`aria-busy`). */
const anyBusy = (node: SemanticNode): boolean => !!node.state?.busy || !!node.children?.some(anyBusy)

/**
 * Wait until the page has stopped changing (no patch for `quietMs`), the app
 * isn't loading and no part of the page is busy, then return a fresh snapshot.
 * Busy matters on its own: a page can be ready while one of its lists is still
 * loading, and an empty list labelled "loading" isn't a list with nothing in it.
 * Gives up waiting after `maxMs` (enough for a slow request) and returns what
 * is there.
 */
export async function settled(
  projector: SemanticProjector,
  { quietMs = 300, maxMs = 10_000, signal }: { quietMs?: number; maxMs?: number; signal?: AbortSignal } = {},
): Promise<SemanticState> {
  let last = performance.now()
  const unsubscribe = projector.subscribe(() => (last = performance.now()))
  const deadline = performance.now() + maxMs
  try {
    projector.snapshot() // flush anything pending
    for (;;) {
      const state = projector.snapshot()
      const waiting = state.context.state === 'loading' || anyBusy(state.root)
      if ((!waiting && performance.now() - last >= quietMs) || performance.now() >= deadline) break
      await sleep(50, signal)
    }
  } finally {
    unsubscribe()
  }
  return projector.snapshot()
}
