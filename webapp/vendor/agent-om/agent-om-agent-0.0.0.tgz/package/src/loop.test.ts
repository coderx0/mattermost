import { describe, expect, it } from 'vitest'
import type { SemanticNode, SemanticState } from '@agent-om/core'
import type { ActionStep } from '@agent-om/actions'
import type { Answer, ChoiceQuestion, DecideRequest } from './decide'
import { StepFailed, type AgentPage } from './page'
import { runAgent, type AgentEvent, type AgentOptions } from './loop'
import type { FormRequest, Writer, WriterRequest } from './writer'

// The loop over a small app made of projection snapshots: a page is plain
// data, so the loop runs here in Node exactly as it does on a real page. The
// decision model is scripted: it answers by the options' descriptions.

type App = { path: string; search: string; dark: boolean; refreshes: number }

const link = (id: string, name: string, href: string): SemanticNode => ({ id, role: 'link', name, href })
const button = (id: string, name: string, extra: Partial<SemanticNode> = {}): SemanticNode => ({ id, role: 'button', name, ...extra })

const REPORTS = [
  ['Weekly visits', 'o_123'],
  ['Monthly revenue', 'o_456'],
]

function render(app: App): SemanticState {
  const nav: SemanticNode = {
    id: 'nav',
    role: 'navigation',
    name: 'Primary',
    children: [link('nav.home', 'Home', '/'), link('nav.reports', 'Reports', '/reports'), link('nav.settings', 'Settings', '/settings')],
  }
  const pages: Record<string, SemanticNode[]> = {
    '/': [
      { id: 'h.home', role: 'heading', name: 'Home', state: { level: 1 } },
      { id: 'kpi.visitors', role: 'group', kind: 'metric', name: 'Visitors', text: '1,234' },
      button('b.refresh', 'Refresh'),
      button('b.help', 'Help'),
      button('b.info', 'Info'),
    ],
    '/reports': [
      { id: 'h.reports', role: 'heading', name: 'Reports', state: { level: 1 } },
      { id: 'search', role: 'searchbox', name: 'Search reports', ...(app.search ? { value: app.search } : {}) },
      {
        id: 'table.reports',
        role: 'table',
        name: 'Reports',
        table: { columns: ['Report', 'Code'], rows: REPORTS.filter(([r]) => r.toLowerCase().includes(app.search.toLowerCase())), totalRows: 2 },
      },
    ],
    '/settings': [
      { id: 'h.settings', role: 'heading', name: 'Settings', state: { level: 1 } },
      { id: 'dark', role: 'switch', name: 'Dark mode', state: { checked: app.dark } },
      { id: 'code', role: 'textbox', name: 'Order code' },
      button('b.delete', 'Delete account', { risk: 'destructive' }),
    ],
  }
  return {
    revision: 1,
    timestamp: 0,
    context: { url: `https://app.test${app.path}`, path: app.path, query: {}, title: app.path },
    root: { id: 'root', role: 'document', children: [nav, { id: 'main', role: 'main', children: pages[app.path] ?? [] }] },
  }
}

/** The app as the agent's page; `acted` lists every step it ran. */
function fakePage(start: Partial<App> = {}, hooks: { before?: (step: ActionStep) => void } = {}) {
  const app: App = { path: '/', search: '', dark: false, refreshes: 0, ...start }
  const acted: ActionStep[] = []
  const page: AgentPage = {
    observe: async () => render(app),
    snapshot: async () => render(app),
    async act(step) {
      hooks.before?.(step)
      acted.push(step)
      const node = 'target' in step ? find(render(app).root, String(step.target)) : undefined
      if (step.type === 'click' && node?.href) app.path = node.href
      else if (step.type === 'input' && step.target === 'search') app.search = String(step.value)
      else if (step.type === 'toggle' && step.target === 'dark') app.dark = !!step.on
      else if (step.type === 'click' && step.target === 'b.refresh') app.refreshes++
    },
    scroll: async () => {},
  }
  return { app, page, acted }
}

function find(node: SemanticNode, id: string): SemanticNode | undefined {
  if (node.id === id) return node
  for (const c of node.children ?? []) {
    const hit = find(c, id)
    if (hit) return hit
  }
}

// ---- scripted answers, by description ----

const pick = (choice: string, p = 0.9, others: Record<string, number> = {}): Answer => ({ type: 'choice', choice, confidence: p, probabilities: { [choice]: p, ...others } })

const noul = (p: number): Answer => ({ type: 'noul', noul: p })

/** The key of the next action whose description starts with `text`. */
function optionOf(req: DecideRequest, text: string) {
  const hit = Object.entries((req.questions.next as ChoiceQuestion).criteria).find(([, d]) => d.startsWith(text))
  if (!hit) throw new Error(`no option "${text}"`)
  return hit[0]
}

/** Take the option described as `text`, the goal not met. */
const step = (req: DecideRequest, text: string, p = 0.9): Record<string, Answer> => ({ done: noul(0.01), next: pick(optionOf(req, text), p), answer: pick('none') })

/** The goal met, pointing at the content described as `text` (or nothing). */
const done = (req: DecideRequest, text?: string, p = 0.9): Record<string, Answer> => {
  const criteria = (req.questions.answer as ChoiceQuestion).criteria
  const key = text ? Object.keys(criteria).find((k) => criteria[k].startsWith(text))! : 'none'
  return { done: noul(p), next: pick('none'), answer: pick(key) }
}

const agent = (o: Partial<AgentOptions> & Pick<AgentOptions, 'query' | 'decide' | 'page'>) => runAgent({ confirm: async () => true, ...o })

const historyOf = (req: DecideRequest) => (req.state as { history: string[] }).history

describe('a step: one request, one choice among every action', () => {
  it('asks whether the goal is met, the next action (with "none"), and which content shows the answer', async () => {
    const { page } = fakePage()
    const sent: DecideRequest[] = []
    await agent({ query: 'how many visitors?', page, decide: async (req) => (sent.push(req), done(req)) })
    const req = sent[0]
    expect(Object.entries(req.questions).map(([k, q]) => `${k}:${q.type}`)).toEqual(['done:noul', 'next:choice', 'answer:choice'])
    // every action, the reads among them, and "none"
    expect(Object.values((req.questions.next as ChoiceQuestion).criteria)).toEqual([
      "link 'Home' → /",
      "link 'Reports' → /reports",
      "link 'Settings' → /settings",
      "button 'Refresh'",
      "button 'Help'",
      "button 'Info'",
      "read metric 'Visitors'",
      'None of these actions moves toward the goal.',
    ])
    expect((req.questions.answer as ChoiceQuestion).criteria).toHaveProperty('none')
  })

  it('takes the top action however its probability is split (no threshold, no asking)', async () => {
    const { page, app } = fakePage()
    const result = await agent({
      query: 'open the reports',
      page,
      decide: async (req) => {
        if (app.path === '/reports') return done(req)
        return { done: noul(0.02), next: pick(optionOf(req, "link 'Reports'"), 0.34, { [optionOf(req, "link 'Settings'")]: 0.33, none: 0.2 }), answer: pick('none') }
      },
    })
    expect(result).toEqual({ status: 'done', message: 'Done.' })
    expect(app.path).toBe('/reports')
  })

  it('with an `unsure` threshold, asks instead of taking a top action below it', async () => {
    const { page, acted } = fakePage()
    const asked: string[] = []
    const result = await agent({
      query: 'open the reports',
      page,
      thresholds: { unsure: 0.5 },
      decide: async (req) => ({ done: noul(0.02), next: pick(optionOf(req, "link 'Reports'"), 0.34), answer: pick('none') }),
      unblock: async (prompt) => (asked.push(prompt), null),
    })
    expect(result).toEqual({ status: 'stopped', message: 'Stopped.' })
    expect(asked).toEqual(['Not sure what to do next. Pick a step, or stop:'])
    expect(acted).toEqual([])
  })
})

describe('finishing', () => {
  const finishes = async (doneP: number, nextTop: 'none' | 'an action') => {
    const { page, acted } = fakePage()
    const result = await agent({
      query: 'how many visitors?',
      page,
      decide: async (req) => ({ done: noul(doneP), next: nextTop === 'none' ? pick('none', 0.6) : pick(optionOf(req, "button 'Help'"), 0.6), answer: pick('none') }),
    })
    return { status: result.status, acted: acted.length }
  }

  it('finishes when the goal is met (done ≥ 0.8), or when "none" is the top action and it may well be (done ≥ 0.5)', async () => {
    expect(await finishes(0.85, 'an action')).toEqual({ status: 'done', acted: 0 })
    expect(await finishes(0.6, 'none')).toEqual({ status: 'done', acted: 0 })
    // done that likely, but an action on top: it acts
    expect((await finishes(0.6, 'an action')).acted).toBeGreaterThan(0)
    // "none" on top and the goal unlikely met: nothing to do
    expect(await finishes(0.3, 'none')).toEqual({ status: 'blocked', acted: 0 })
  })

  it('decision model only: the answer is the content it points at, in the page\'s own words', async () => {
    const { page } = fakePage()
    const result = await agent({ query: 'how many visitors?', page, decide: async (req) => done(req, "metric 'Visitors'") })
    expect(result).toMatchObject({ status: 'done', text: '1,234', answer: { nodeId: 'kpi.visitors', text: '1,234' } })
  })

  it("with a writer: a failed final answer doesn't fail a run that reached its goal; the answer is the content pointed at", async () => {
    const { page } = fakePage()
    const events: AgentEvent[] = []
    const writer: Writer = { field: async () => null, answer: async () => Promise.reject(new Error('Chat API: not JSON: ""')) }
    const result = await agent({ query: 'how many visitors?', page, writer, decide: async (req) => done(req, "metric 'Visitors'"), onEvent: (e) => events.push(e) })
    expect(result).toMatchObject({ status: 'done', text: '1,234', answer: { nodeId: 'kpi.visitors' } })
    expect(events.find((e) => e.type === 'writer-failed')).toMatchObject({ what: 'answer', message: 'Chat API: not JSON: ""' })
    // an empty answer is no answer either
    const empty = await agent({ query: 'how many visitors?', page: fakePage().page, writer: { field: async () => null, answer: async () => '' }, decide: async (req) => done(req, "metric 'Visitors'") })
    expect(empty).toMatchObject({ status: 'done', text: '1,234' })
  })

  it('with a writer: the writer writes the final answer from what the run saw', async () => {
    const { page } = fakePage()
    const asked: WriterRequest[] = []
    const writer: Writer = { field: async () => null, answer: async (r) => (asked.push(r), '1,234 visitors') }
    const result = await agent({ query: 'how many visitors?', page, writer, decide: async (req) => done(req, "metric 'Visitors'") })
    expect(result).toMatchObject({ status: 'done', text: '1,234 visitors', answer: { nodeId: 'kpi.visitors' } })
    expect(asked[0].state).toMatchObject({ goal: 'how many visitors?', path: '/', history: [] })
  })

  it("with a writer: a goal that asked for a change has nothing to tell, so the writer isn't asked for an answer", async () => {
    const answers = async (answer: string) => {
      let asked = 0
      const writer: Writer = { field: async () => null, answer: async () => (asked++, 'ok') }
      const result = await agent({ query: 'turn on dark mode', page: fakePage({ dark: true, path: '/settings' }).page, writer, decide: async () => ({ done: noul(0.9), next: pick('none'), answer: pick(answer) }) })
      return { result, asked }
    }
    expect(await answers('change')).toEqual({ result: { status: 'done', message: 'Done.' }, asked: 0 })
    // nothing shown that answers it: the writer says so
    expect(await answers('none')).toMatchObject({ result: { status: 'done', text: 'ok' }, asked: 1 })
  })

  it('the answer question tells a goal that asks for a change from information nothing shows', async () => {
    const sent: DecideRequest[] = []
    await agent({ query: 'x', page: fakePage().page, decide: async (req) => (sent.push(req), done(req)) })
    const criteria = (sent[0].questions.answer as ChoiceQuestion).criteria
    expect(criteria.none).toBe('Nothing on the page shows the information the goal asks for.')
    expect(criteria.change).toBe('The goal asks for a change to be made on the page, not for information.')
  })

  it('blocked ends the run; with someone to ask, their pick is carried out', async () => {
    const blocked = (req: DecideRequest) => ({ done: noul(0.1), next: pick('none', 0.5, { [optionOf(req, "link 'Settings'")]: 0.4 }), answer: pick('none') })
    const alone = fakePage()
    expect(await agent({ query: 'x', page: alone.page, decide: async (req) => blocked(req) })).toEqual({ status: 'blocked', message: 'Nothing on the page moves toward the goal.' })
    expect(alone.acted).toEqual([])
    const asked = fakePage()
    let first = true
    const result = await agent({
      query: 'x',
      page: asked.page,
      decide: async (req) => (first ? ((first = false), blocked(req)) : done(req)),
      unblock: async (_prompt, options) => options[0].key,
    })
    expect(result.status).toBe('done')
    expect(asked.app.path).toBe('/settings')
  })
})

describe('text', () => {
  it('decision model only: types the top run of the goal\'s words', async () => {
    const { page, app } = fakePage({ path: '/reports' })
    const result = await agent({
      query: 'find the weekly report',
      page,
      decide: async (req) => {
        if (req.questions.text) return { text: pick('weekly', 0.4, { 'weekly report': 0.35 }) }
        return app.search ? done(req) : step(req, "type into searchbox 'Search reports'")
      },
    })
    expect(result.status).toBe('done')
    expect(app.search).toBe('weekly')
  })

  it('with a writer: types what it writes; when it has nothing, says so in the history and goes on', async () => {
    const typed = fakePage({ path: '/reports' })
    const fields: WriterRequest[] = []
    const writer: Writer = { field: async (r) => (fields.push(r), 'Monthly'), answer: async () => 'ok' }
    await agent({
      query: 'find the monthly report',
      page: typed.page,
      writer,
      decide: async (req) => (typed.app.search ? done(req) : step(req, "type into searchbox 'Search reports'")),
    })
    expect(typed.app.search).toBe('Monthly')
    expect(fields[0].state).toMatchObject({ goal: 'find the monthly report', field: "searchbox 'Search reports'" })

    const none = fakePage({ path: '/settings' })
    const sent: DecideRequest[] = []
    const result = await agent({
      query: 'enter my order code',
      page: none.page,
      writer: { field: async () => null, answer: async () => 'no code' },
      decide: async (req) => (sent.push(req), sent.length === 1 ? step(req, "type into textbox 'Order code'") : done(req)),
    })
    expect(result.status).toBe('done')
    expect(none.acted).toEqual([])
    expect(historyOf(sent[1])).toEqual(["1. no text to type into textbox 'Order code': nothing in the goal or on the page gives a value"])
  })
})

describe('guards', () => {
  it('three steps in a row that change nothing: blocked', async () => {
    const { page, acted } = fakePage()
    const buttons = ["button 'Help'", "button 'Info'", "button 'Help'"]
    let i = 0
    const result = await agent({ query: 'x', page, decide: async (req) => step(req, buttons[i++] ?? "button 'Info'") })
    expect(result).toEqual({ status: 'blocked', message: 'Stopped: 3 steps in a row changed nothing.' })
    expect(acted).toHaveLength(3)
  })

  it('the same step again on a page that has not changed: blocked, not run again', async () => {
    const { page, acted } = fakePage()
    const result = await agent({ query: 'x', page, decide: async (req) => step(req, "button 'Help'") })
    expect(result).toEqual({ status: 'blocked', message: 'Stopped: the same step again on a page that has not changed.' })
    expect(acted).toHaveLength(1)
  })

  it('stuck on an unchanged page whose goal may well be met (done ≥ 0.4): it finishes there instead', async () => {
    // an in-page anchor clicked again on the right page: done 0.42–0.63 in the runs that did it, 0.10–0.15 on wrong pages
    const stuck = async (doneP: number, text: string) => {
      const { page, acted } = fakePage()
      const result = await agent({ query: 'x', page, decide: async (req) => ({ done: noul(doneP), next: pick(optionOf(req, text)), answer: pick('none') }) })
      return { status: result.status, acted: acted.length }
    }
    expect(await stuck(0.5, "button 'Help'")).toEqual({ status: 'done', acted: 1 })
    expect(await stuck(0.15, "button 'Help'")).toEqual({ status: 'blocked', acted: 1 })
    // three steps that change nothing, the goal likely met
    const { page } = fakePage()
    const buttons = ["button 'Help'", "button 'Info'", "button 'Help'"]
    let i = 0
    const result = await agent({ query: 'x', page, decide: async (req) => ({ done: noul(0.45), next: pick(optionOf(req, buttons[i++] ?? "button 'Info'")), answer: pick('none') }) })
    expect(result.status).toBe('done')
  })

  it('a step can be taken again once the page has changed', async () => {
    // the same field typed into twice, with different text: the page changed in between
    const { page, app } = fakePage({ path: '/reports' })
    const words = ['weekly', 'monthly']
    let i = 0
    const result = await agent({
      query: 'x',
      page,
      writer: { field: async () => words[i++], answer: async () => 'ok' },
      decide: async (req) => (i < 2 ? step(req, "type into searchbox 'Search reports'") : done(req)),
    })
    expect(result.status).toBe('done')
    expect(app.search).toBe('monthly')
  })

  it('going back and forth between the same two pages: blocked', async () => {
    const { page, acted } = fakePage()
    let i = 0
    const result = await agent({ query: 'x', page, decide: async (req) => step(req, i++ % 2 ? "link 'Home'" : "link 'Reports'") })
    expect(result).toEqual({ status: 'blocked', message: 'Stopped: going back and forth between the same two pages.' })
    expect(acted).toHaveLength(4)
  })

  it('decides again when the target is gone by the time it would act', async () => {
    const fake = fakePage()
    const snapshot = fake.page.snapshot
    let gone = true
    fake.page.snapshot = async () => {
      const s = await snapshot()
      if (gone) {
        gone = false
        const nav = s.root.children![0]
        nav.children = nav.children!.filter((n) => n.id !== 'nav.reports')
      }
      return s
    }
    const sent: DecideRequest[] = []
    const result = await agent({ query: 'open reports', page: fake.page, decide: async (req) => (sent.push(req), fake.app.path === '/reports' ? done(req) : step(req, "link 'Reports'")) })
    expect(result.status).toBe('done')
    expect(historyOf(sent[1])).toEqual(["(not done: link 'Reports' it is no longer on the page; deciding again)"])
  })

  it('stops after two failed steps in a row', async () => {
    const { page } = fakePage({}, { before: () => { throw new StepFailed('covered') } })
    let i = 0
    const result = await agent({ query: 'x', page, decide: async (req) => step(req, i++ ? "button 'Info'" : "button 'Help'") })
    expect(result).toEqual({ status: 'failed', message: 'Stopped after repeated failures (last: covered).' })
  })

  it('stops at the step limit', async () => {
    const { page } = fakePage()
    const links = ["link 'Reports'", "link 'Settings'", "link 'Home'"]
    let i = 0
    const result = await agent({ query: 'x', page, maxSteps: 2, decide: async (req) => step(req, links[i++]) })
    expect(result).toEqual({ status: 'failed', message: 'Stopped after 2 steps without reaching the goal.' })
  })
})

describe('policy', () => {
  it('a risky target needs confirmation (from the projection, not the model); declining stops', async () => {
    const { page, acted } = fakePage({ path: '/settings' })
    const prompts: string[] = []
    const result = await agent({ query: 'delete my account', page, confirm: async (p) => (prompts.push(p), false), decide: async (req) => step(req, "button 'Delete account'") })
    expect(result).toEqual({ status: 'stopped', message: 'Cancelled.' })
    expect(prompts).toEqual(["button 'Delete account': it is destructive. Go ahead?"])
    expect(acted).toEqual([])
  })

  it('turning a toggle straight back needs confirmation', async () => {
    const { page, app } = fakePage({ path: '/settings' })
    const prompts: string[] = []
    const result = await agent({
      query: 'x',
      page,
      confirm: async (p) => (prompts.push(p), false),
      decide: async (req) => step(req, app.dark ? "turn off switch 'Dark mode'" : "turn on switch 'Dark mode'"),
    })
    expect(result).toEqual({ status: 'stopped', message: 'Cancelled.' })
    expect(prompts).toEqual(["turn off switch 'Dark mode' would undo the previous step. Go ahead?"])
    expect(app.dark).toBe(true)
  })
})

describe('what the page shows only on hover', () => {
  /** A message whose Reply shows only while the pointer is over it, and a menu with a destructive submenu that opens on hover. */
  function hoverPage() {
    const app = { hovered: '', replied: false }
    const acted: ActionStep[] = []
    const render = (): SemanticState => ({
      revision: 1,
      timestamp: 0,
      context: { url: 'https://app.test/channel', path: '/channel', query: {}, title: 'Channel' },
      root: {
        id: 'root',
        role: 'document',
        children: [
          {
            id: 'main',
            role: 'main',
            children: [
              {
                id: 'post.1',
                role: 'article',
                name: 'Message from Ada',
                text: 'Lunch at noon?',
                reveals: ['Reply', 'Message actions'],
                children: app.hovered === 'post.1' ? [button('post.1.reply', 'Reply'), button('post.1.actions', 'Message actions', { haspopup: 'menu' })] : [],
              },
              {
                id: 'menu',
                role: 'menu',
                name: 'Channel',
                children: [{ id: 'm.archive', role: 'menuitem', name: 'Archive to', haspopup: 'menu', risk: 'destructive' }],
              },
            ],
          },
        ],
      },
    })
    const page: AgentPage = {
      observe: async () => render(),
      snapshot: async () => render(),
      async act(step) {
        acted.push(step)
        if (step.type === 'hover') app.hovered = String(step.target)
        if (step.type === 'click' && step.target === 'post.1.reply') app.replied = true
      },
      scroll: async () => {},
    }
    return { app, page, acted }
  }

  it('offers hovering over what says it shows controls, then the controls it showed', async () => {
    const { app, page, acted } = hoverPage()
    const requests: DecideRequest[] = []
    const result = await agent({
      query: 'reply to Ada',
      page,
      decide: async (req) => {
        requests.push(req)
        if (requests.length === 1) return step(req, "hover over article 'Message from Ada' (shows: Reply, Message actions)")
        if (requests.length === 2) return step(req, "button 'Reply'")
        return done(req)
      },
    })
    expect(result.status).toBe('done')
    expect(acted).toEqual([
      { type: 'hover', target: 'post.1' },
      { type: 'click', target: 'post.1.reply' },
    ])
    expect(app.replied).toBe(true)
    expect(historyOf(requests[2])[0]).toContain("hovered over article 'Message from Ada'")
    // a hover option has a key of its own: a menu item's click and hover are two options
    const criteria = (requests[0].questions.next as ChoiceQuestion).criteria
    expect(Object.entries(criteria).filter(([, d]) => d.includes("'Archive to'")).map(([k, d]) => [k[0], d])).toEqual([
      ['a', "menuitem 'Archive to' opens its menu"],
      ['h', "hover over menuitem 'Archive to' (opens its menu)"],
    ])
  })

  it('hovering needs no confirmation, whatever the element does when clicked', async () => {
    const { page, acted } = hoverPage()
    const prompts: string[] = []
    let n = 0
    await agent({
      query: 'archive the channel',
      page,
      confirm: async (p) => (prompts.push(p), false),
      decide: async (req) => (n++ ? done(req) : step(req, "hover over menuitem 'Archive to'")),
    })
    expect(acted).toEqual([{ type: 'hover', target: 'm.archive' }])
    expect(prompts).toEqual([])
  })
})

describe('reading and memory', () => {
  it('a read shows the content with the next decision, takes no step, and is remembered after leaving the page', async () => {
    const { page, app } = fakePage({ path: '/reports' })
    const sent: DecideRequest[] = []
    const result = await agent({
      query: 'type the weekly report code into the order code field',
      page,
      maxSteps: 1,
      decide: async (req) => {
        sent.push(req)
        if (sent.length === 1) return step(req, "read the rows of table 'Reports'")
        if (app.path === '/reports') return step(req, "link 'Settings'")
        return done(req)
      },
    })
    expect(result.status).toBe('done')
    // read, then one step (the limit), then done: the read didn't count
    expect((sent[1].state as { reading: unknown }).reading).toEqual([{ of: "table 'Reports'", lines: ['Report: Weekly visits · Code: o_123', 'Report: Monthly revenue · Code: o_456'] }])
    expect((sent[2].state as { memory: string[] }).memory).toEqual(["table 'Reports' (on /reports): Report: Weekly visits · Code: o_123 | Report: Monthly revenue · Code: o_456"])
    expect(sent[2].state).not.toHaveProperty('reading')
  })
})

describe('stepping through', () => {
  it('shows each decision before it is carried out: go on, take another option, or stop', async () => {
    const { page, app } = fakePage()
    const seen: string[] = []
    let calls = 0
    const result = await agent({
      query: 'open settings',
      page,
      decide: async (req) => (app.path === '/settings' ? done(req) : step(req, "link 'Reports'")),
      review: async (decision, options) => {
        seen.push(decision.chosen.description)
        if (calls++ === 0) return options.find((o) => o.description.startsWith("link 'Settings'"))!.key
        return undefined
      },
    })
    expect(result.status).toBe('done')
    expect(app.path).toBe('/settings')
    expect(seen).toEqual(["link 'Reports' → /reports", 'done'])
    const stopped = fakePage()
    expect(await agent({ query: 'x', page: stopped.page, decide: async (req) => step(req, "link 'Reports'"), review: async () => null })).toEqual({ status: 'stopped', message: 'Stopped.' })
    expect(stopped.acted).toEqual([])
  })

  it('reports every decision with its alternatives, and a request near the size limit', async () => {
    const { page } = fakePage()
    const events: AgentEvent[] = []
    await agent({ query: 'x'.repeat(31_000), page, decide: async (req) => done(req), onEvent: (e) => events.push(e) })
    expect(events.map((e) => e.type)).toEqual(['deciding', 'large-request', 'decided'])
    expect(events.find((e) => e.type === 'decided')).toMatchObject({ decision: { step: 1, done: 0.9, chosen: { key: 'done' }, next: [{ key: 'none', p: 0.9 }] } })
  })
})

describe('one look at the page per step', () => {
  it('the settled page a step ends on is the next step\'s page: the wait is not paid twice', async () => {
    const { page, app } = fakePage()
    let looks = 0
    const observe = page.observe
    page.observe = async (signal) => (looks++, observe(signal))
    const result = await agent({ query: 'open settings', page, decide: async (req) => (app.path === '/settings' ? done(req) : step(req, "link 'Settings'")) })
    expect(result.status).toBe('done')
    // the first page, and the page after the one step (before: once more, for the second decision)
    expect(looks).toBe(2)
  })
})

// A sign-up form: the form page of a small app, for filling in one step and for secrets.
type Form = { first: string; email: string; access: string; digest: boolean; password: string; sent: boolean }

/** `dropsPassword`: the app clears what's typed into the password field (the field holds nothing after). */
function formApp(start: Partial<Form> = {}, { dropsPassword = false } = {}) {
  const f: Form = { first: '', email: '', access: '', digest: false, password: '', sent: false, ...start }
  const invalid = f.email !== '' && !f.email.includes('@')
  const render = (): SemanticState => {
    const bad = f.email !== '' && !f.email.includes('@')
    const radio = (name: string): SemanticNode => ({ id: `access.${name}`, role: 'radio', name, form: 'invite', state: { checked: f.access === name } })
    return {
      revision: 1,
      timestamp: 0,
      context: { url: 'https://app.test/invite', path: '/invite', query: {}, title: 'Invite' },
      root: {
        id: 'root',
        role: 'document',
        children: [
          {
            id: 'invite',
            role: 'form',
            name: 'Invite contact',
            children: [
              { id: 'first', role: 'textbox', name: 'First name', form: 'invite', state: { required: true }, ...(f.first ? { value: f.first } : {}) },
              { id: 'email', role: 'textbox', name: 'Email', form: 'invite', inputType: 'email', state: { required: true, ...(bad ? { invalid: true } : {}) }, ...(bad ? { errorMessage: 'email.error' } : {}), ...(f.email ? { value: f.email } : {}) },
              ...(bad ? [{ id: 'email.error', role: 'generic', text: 'Enter a valid email' }] : []),
              { id: 'access', role: 'radiogroup', name: 'Access', children: [radio('View reports'), radio('Edit reports')] },
              { id: 'digest', role: 'checkbox', name: 'Weekly digest', form: 'invite', state: { checked: f.digest } },
              { id: 'password', role: 'textbox', name: 'Password', form: 'invite', inputType: 'password', ...(f.password ? { redacted: true } : {}) },
              { id: 'send', role: 'button', name: 'Send invite', form: 'invite' },
            ],
          },
          ...(f.sent ? [{ id: 'sent', role: 'status', text: 'Invite sent' }] : []),
        ],
      },
    }
  }
  const acted: ActionStep[] = []
  const page: AgentPage = {
    observe: async () => render(),
    snapshot: async () => render(),
    async act(s) {
      acted.push(s)
      const t = 'target' in s ? String(s.target) : ''
      if (s.type === 'input') (f as Record<string, unknown>)[t] = dropsPassword && t === 'password' ? '' : s.value
      else if (s.type === 'toggle' && t === 'digest') f.digest = !!s.on
      else if (s.type === 'click' && t.startsWith('access.')) f.access = t.slice('access.'.length)
      else if (s.type === 'click' && t === 'send') f.sent = true
    },
    scroll: async () => {},
  }
  void invalid
  return { f, page, acted }
}

const formWriter = (values: Record<string, unknown>, asked: FormRequest[] = []): Writer => ({
  field: async () => null,
  answer: async () => 'ok',
  form: async (r) => (asked.push(r), values as Record<string, string>),
})

describe('filling a form in one step', () => {
  it('the writer gives every field its value in one call; the fields are set in page order and the form read back', async () => {
    const { f, page, acted } = formApp()
    const asked: FormRequest[] = []
    const sent: DecideRequest[] = []
    const writer = formWriter({ f1: 'Ana', f2: 'ana@x.test', f3: 'Edit reports', f4: true }, asked)
    const result = await agent({
      query: 'invite Ana (ana@x.test) with edit access and the weekly digest',
      page,
      writer,
      decide: async (req) => (sent.push(req), f.sent ? done(req) : f.first ? step(req, "button 'Send invite'") : step(req, "fill form 'Invite contact'")),
    })
    expect(result.status).toBe('done')
    expect(asked).toHaveLength(1)
    // a secret field is no field of a fill: the user enters it
    expect(asked[0].form.fields.map((x) => x.label)).toEqual(['First name', 'Email', 'Access', 'Weekly digest'])
    // the fill is one step of four actions, the submit a step of its own
    expect(acted.map((s) => s.type)).toEqual(['input', 'input', 'click', 'toggle', 'click'])
    expect(f).toMatchObject({ first: 'Ana', email: 'ana@x.test', access: 'Edit reports', digest: true, sent: true })
    expect(historyOf(sent[1])).toEqual(["1. filled form 'Invite contact': First name \"Ana\", Email \"ana@x.test\", Access 'Edit reports', Weekly digest on"])
  })

  it('says what a fill left wrong: a required field still empty, a field now invalid with its error', async () => {
    const { page } = formApp()
    const sent: DecideRequest[] = []
    await agent({
      query: 'invite Ana',
      page,
      writer: formWriter({ f1: 'Ana', f2: 'ana-at-x', f3: null, f4: null }),
      maxSteps: 1,
      decide: async (req) => (sent.push(req), sent.length === 1 ? step(req, "fill form 'Invite contact'") : done(req)),
    })
    expect(historyOf(sent[1])).toEqual([
      "1. filled form 'Invite contact': First name \"Ana\", Email \"ana-at-x\"; left alone: Access, Weekly digest; now invalid: Email ('Enter a valid email')",
    ])
  })

  it('a fill that sets nothing changed nothing, said so', async () => {
    const { page, acted } = formApp()
    const sent: DecideRequest[] = []
    await agent({
      query: 'invite someone',
      page,
      writer: formWriter({ f1: null, f2: null, f3: null, f4: null }),
      decide: async (req) => (sent.push(req), sent.length === 1 ? step(req, "fill form 'Invite contact'") : done(req)),
    })
    expect(acted).toEqual([])
    expect(historyOf(sent[1])).toEqual(["1. nothing to fill in form 'Invite contact': nothing in the goal or on the page gives a value"])
  })

  it('is offered only with a writer that fills forms; the fields stay offered one by one', async () => {
    const offered = async (writer?: Writer) => {
      const sent: DecideRequest[] = []
      await agent({ query: 'x', page: formApp().page, writer, decide: async (req) => (sent.push(req), done(req)) })
      return Object.values((sent[0].questions.next as ChoiceQuestion).criteria)
    }
    expect(await offered(formWriter({}))).toEqual(expect.arrayContaining(["fill form 'Invite contact': First name, Email, Access, Weekly digest (2 required, empty)", "type into textbox 'First name' (required)"]))
    expect((await offered()).some((d) => d.startsWith('fill '))).toBe(false)
    expect((await offered({ field: async () => null, answer: async () => 'ok' })).some((d) => d.startsWith('fill '))).toBe(false)
  })
})

describe('secrets', () => {
  /** What every model and the host were given, as one string: a secret the user entered must be in none of it. */
  const seen = (sent: DecideRequest[], events: AgentEvent[], written: unknown[]) => JSON.stringify({ sent, events, written })

  it('a secret field is filled with what the user enters: no model sees it, and the history says only that it was filled', async () => {
    const { f, page } = formApp()
    const sent: DecideRequest[] = []
    const events: AgentEvent[] = []
    const written: unknown[] = []
    const asked: string[] = []
    const result = await agent({
      query: 'set my password',
      page,
      writer: { field: async (r) => (written.push(r), null), answer: async (r) => (written.push(r), 'ok'), form: async (r) => (written.push(r), {}) },
      askSecret: async (field) => (asked.push(field), 'hunter2'),
      onEvent: (e) => events.push(e),
      decide: async (req) => (sent.push(req), f.password ? done(req) : step(req, "fill textbox 'Password' with a secret the user enters")),
    })
    expect(result.status).toBe('done')
    expect(f.password).toBe('hunter2')
    expect(asked).toEqual(["textbox 'Password'"])
    // it held no secret before and holds one now: the change the history reports
    expect(historyOf(sent[1])).toEqual(["1. filled textbox 'Password' with a secret the user entered → textbox 'Password' now holds a secret"])
    expect(seen(sent, events, written)).not.toContain('hunter2')
  })

  it('declining to enter it stops the run, and nothing is typed', async () => {
    const { f, page } = formApp()
    const result = await agent({
      query: 'set my password',
      page,
      askSecret: async () => null,
      decide: async (req) => step(req, "fill textbox 'Password' with a secret the user enters"),
    })
    expect(result).toEqual({ status: 'stopped', message: 'Cancelled.' })
    expect(f.password).toBe('')
  })

  it('says it was not filled when the field holds nothing after', async () => {
    const { page } = formApp({}, { dropsPassword: true })
    const sent: DecideRequest[] = []
    const events: AgentEvent[] = []
    await agent({
      query: 'set my password',
      page,
      maxSteps: 1,
      askSecret: async () => 'hunter2',
      onEvent: (e) => events.push(e),
      decide: async (req) => (sent.push(req), sent.length === 1 ? step(req, "fill textbox 'Password' with a secret the user enters") : done(req)),
    })
    expect(historyOf(sent[1])).toEqual(["1. filled textbox 'Password' with a secret the user entered → not filled: it holds nothing"])
    expect(events).toContainEqual({ type: 'result', step: 1, ok: false, detail: 'not filled: it holds nothing' })
  })

  it('without a way to ask the user, a secret field is not offered: a model never types into one', async () => {
    const sent: DecideRequest[] = []
    await agent({ query: 'set my password to hunter2', page: formApp().page, writer: formWriter({}), decide: async (req) => (sent.push(req), done(req)) })
    const options = Object.values((sent[0].questions.next as ChoiceQuestion).criteria)
    expect(options.filter((d) => d.includes("'Password'"))).toEqual([])
    expect(options).toContain("type into textbox 'First name' (required)")
  })
})
