import { ACTIONABLE_ROLES, type SemanticNode, type SemanticState } from '@agent-om/core'
import type { SitemapNode } from '@agent-om/core/sitemap'
import { contentOf, describedContainer, earlierNote, indexNodes, isSet, looseText, nameOf, outlinedList, stateOf, tableOf, valueOf, whatOf, type EarlierMessages } from './describe'
import { PAGE, PAGE_LINES, PAGE_LINES_READ, revealed, type Reading } from './reveal'
import { siteOutline } from './site-outline'

// The `state` sent with every decision: the goal, where we are, what the page
// shows and what has been done. Details of individual controls live in the
// option descriptions; this is the context to judge them and "done" against.
// With a sitemap, it also says what pages exist beyond this one; with reads,
// the content the model chose to see of what the outline holds back.

export type ModelState = {
  goal: string
  screen?: string
  path: string
  title: string
  /** the app's pages, one line each, the current one marked (when the app has a sitemap) */
  sitemap?: string[]
  /** one line per notable thing on the page */
  page: string[]
  /** what the model chose to read of what `page` holds back, current (reveal.ts) */
  reading?: Reading[]
  /** what was done so far and what came of it */
  history: string[]
}

/** How the page is shown: what to leave out, and what the run knows beyond the page. */
export type ModelView = {
  /** node ids (with their subtrees) never shown, e.g. the agent's own search box */
  exclude: ReadonlySet<string>
  /** the app's sitemap, if it has one */
  sitemap?: SitemapNode
  /** messages already showing when the task began (marked while unchanged) */
  earlier?: EarlierMessages
  /** elements the model has read (reveal.ts): their content is sent in full */
  expanded?: ReadonlySet<string>
}

export function modelState(goal: string, state: SemanticState, history: string[], view: ModelView): ModelState {
  const { sitemap, expanded } = view
  const page = outlineOf(state, view.exclude, view.earlier)
  const reading = expanded?.size ? revealed(state, expanded) : []
  return {
    goal,
    ...(typeof state.context.screen === 'string' ? { screen: state.context.screen } : {}),
    path: state.context.path,
    title: state.context.title,
    ...(sitemap ? { sitemap: siteOutline(sitemap, state.context.path, state.context.query) } : {}),
    page: page.slice(0, expanded?.has(PAGE) ? PAGE_LINES_READ : PAGE_LINES),
    ...(reading.length ? { reading } : {}),
    history: [...history], // a snapshot: the loop goes on appending to its own array
  }
}

/**
 * Every line of the page outline, uncut (modelState sends the first PAGE_LINES
 * unless they're read). The outline names things, it doesn't repeat them:
 * content by its name ("metric 'Visitors'"; what it shows is the answer the
 * agent points at), a table by its columns and size, a control that's set by
 * its value ("filter 'Date range': 30d"); its choices are in its option.
 */
export function outlineOf(state: SemanticState, exclude: ReadonlySet<string>, earlier?: EarlierMessages): string[] {
  return outlineEntries(state, exclude, earlier).map((e) => e.line)
}

/** The open popup's line in the outline, by the id outlineEntries gives it. */
export const POPUP_LINE = '(popup)'

/** The outline's lines with the node each is about (POPUP_LINE for the open popup's). */
export function outlineEntries(state: SemanticState, exclude: ReadonlySet<string>, earlier?: EarlierMessages): { id: string; line: string }[] {
  const index = indexNodes(state.root)
  const page: { id: string; line: string }[] = []
  const push = (node: SemanticNode, line: string) => page.push({ id: node.id, line })

  for (const { node, parents } of index.values()) {
    if (exclude.has(node.id) || parents.some((p) => exclude.has(p.id))) continue
    if (node.role === 'heading' && (node.state?.level ?? 9) <= 2 && !parents.some((p) => p.kind)) {
      push(node, `heading '${node.name}'`)
    } else if (node.kind && !parents.some((p) => p.kind)) {
      // a control (a filter): what the app says it's set to ("Current: Acme Store · …", where the
      // page is; its option doesn't repeat it), else its value; content: its name and any table it
      // shows (a chart in table view; what it shows is read on demand, reveal.ts), or what it shows
      // if it has no name
      const set = ACTIONABLE_ROLES.has(node.role)
        ? node.description ? [`'${node.description}'`, ...stateOf(node)].join(', ') : setTo(node)
        : node.name ? tablesIn(node) : contentOf(node)
      push(node, `${nameOf(node)}${set ? `: ${set}` : ''}`)
    } else if (node.table && !parents.some((p) => p.kind)) {
      // A table on its own; one inside content is part of that content.
      push(node, `${nameOf(node)}: ${tableOf(node.table)}`)
    } else if (outlinedList(node, parents)) {
      // its first items (the rest is read on demand, reveal.ts)
      const items = contentOf(node)
      push(node, `${nameOf(node)}${items ? `: ${items}` : ''}`)
    } else if ((node.role === 'status' || node.role === 'alert') && node.text) {
      push(node, `${node.role}: ${node.text}${earlierNote(node, earlier)}`)
    } else if (isSet(node)) {
      const set = setTo(node)
      push(node, `${whatOf(node, parents)}${set ? `: ${set}` : ''}`)
    } else if (looseText(node, parents)) {
      // text that's no named content's: a paragraph in a page's header, a policy's
      // words (the projector caps it); without it, what a page says in prose is nowhere
      push(node, `${nameOf(node)}: ${node.text}`)
    } else if (describedContainer(node, parents)) {
      // what the app says of an area as a whole (whether its changes are saved, a group's error);
      // a container has no line of its own otherwise, so its description would be nowhere
      push(node, `${nameOf(node)}: ${node.description}`)
    }
  }
  if (state.context.modalId) {
    const modal = index.get(state.context.modalId)?.node
    if (modal) page.unshift({ id: POPUP_LINE, line: `open popup: ${nameOf(modal)} (only it can be used until it closes)` })
  }
  return page
}

/** The tables inside content, by columns and size: "table: Date, United States, …; 30 rows". */
function tablesIn(node: SemanticNode): string {
  const tables: string[] = []
  const walk = (n: SemanticNode) => {
    if (n.table) tables.push(`table: ${tableOf(n.table)}`)
    n.children?.forEach(walk)
  }
  walk(node)
  return tables.join(' · ')
}

/** What a control is set to: "'Alex Morgan', required", "on", "selected". */
function setTo(node: SemanticNode) {
  const value = valueOf(node)
  // a radio in the outline is the chosen one: its name says it
  const notes = stateOf(node).filter((n) => !(node.role === 'radio' && n === 'on'))
  return [value !== undefined && value !== '' && !node.redacted ? `'${value}'` : '', ...notes].filter(Boolean).join(', ')
}

