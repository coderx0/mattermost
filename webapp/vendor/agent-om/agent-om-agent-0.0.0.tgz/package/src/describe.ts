import { ACTIONABLE_ROLES, type SemanticNode } from '@agent-om/core'

// Plain-language descriptions of projection nodes. These lines are all the
// decision model sees of the page, so they carry what a person would use to
// pick a control: what it is, what it says, its state and where it sits.
// Only generic projection fields are read (name, role, kind, value, valueText,
// min, max, description, text, state, items, table, row, action, purpose, requires, reveals): never an
// app's `data` shape. What
// the projection doesn't say is the app's to add (docs/guidelines.md).

export type Located = { node: SemanticNode; parents: SemanticNode[] }

/** Every node by id, with its ancestors (nearest last). */
export function indexNodes(root: SemanticNode) {
  const index = new Map<string, Located>()
  const walk = (node: SemanticNode, parents: SemanticNode[]) => {
    index.set(node.id, { node, parents })
    node.children?.forEach((c) => walk(c, [...parents, node]))
  }
  walk(root, [])
  return index
}

/** What the node is called: its accessible name. */
export function labelOf(node: SemanticNode): string | undefined {
  return node.name
}

/** The value as exposed: aria-valuetext if given, else the value itself. */
export function valueOf(node: SemanticNode): string | undefined {
  if (node.valueText) return node.valueText
  return node.value === undefined ? undefined : String(node.value)
}

const ROLE_WORD: Record<string, string> = { generic: 'section', banner: 'page header', contentinfo: 'page footer' }

/** e.g. "combobox 'Date range'" or "metric 'Bounce rate'". */
export function nameOf(node: SemanticNode) {
  const label = labelOf(node)
  const what = node.kind ?? ROLE_WORD[node.role] ?? node.role
  return label ? `${what} '${label}'` : what
}

const CONTAINERS = new Set([
  'navigation',
  'banner',
  'contentinfo',
  'complementary',
  'region',
  'form',
  'search',
  'dialog',
  'alertdialog',
  'listbox',
  'menu',
  'menubar',
  'tablist',
  'tree',
  'table',
  'grid',
  'list',
  'toolbar',
  'radiogroup',
  'group',
])

/** Popups are worth naming even without a label: "in listbox" says it's the open list. */
const POPUPS = new Set(['listbox', 'menu', 'menubar', 'dialog', 'alertdialog', 'tree'])

/** "in navigation 'Primary'": the nearest named container, open popup or landmark. */
export function whereOf(parents: SemanticNode[]) {
  return wheresOf(parents)[0] ?? ''
}

/**
 * Every container whereOf would name, the nearest first: twins whose nearest
 * containers read the same (a day in each of two calendars, both "October")
 * are told apart further out ("in group 'End date'").
 */
export function wheresOf(parents: SemanticNode[]) {
  const wheres: string[] = []
  for (let i = parents.length - 1; i >= 0; i--) {
    const p = parents[i]
    if (p.role === 'root' || p.role === 'document' || p.role === 'main') continue
    if (p.kind || POPUPS.has(p.role) || (CONTAINERS.has(p.role) && (labelOf(p) || ROLE_WORD[p.role])))
      wheres.push(`in ${nameOf(p)}`)
  }
  return wheres
}

/** Short state notes worth reading when choosing, e.g. "currently on", "you are here". */
export function stateOf(node: SemanticNode) {
  const notes: string[] = []
  const s = node.state ?? {}
  if (s.current) notes.push(s.current === 'page' ? 'current page' : s.current === 'true' ? 'current' : `current ${s.current}`)
  if (s.selected) notes.push('selected')
  if (s.checked === true || s.pressed === true) notes.push('on')
  if (s.checked === false || s.pressed === false) notes.push('off')
  if (s.expanded === true) notes.push('open')
  if (s.invalid) notes.push('invalid')
  if (s.required) notes.push('required')
  return notes
}

/**
 * What the app says about a control beyond its name, as a suffix: the pages a
 * section holds, what a search matches. Empty when it says nothing.
 */
export const describedOf = (node: SemanticNode) => (node.description ? `; '${node.description}'` : '')

const words = (kebab: string) => kebab.replace(/-+/g, ' ')

/** Roles that hold a value, so having none is worth saying ("empty"). */
const VALUE_ROLES = new Set(['textbox', 'searchbox', 'spinbutton', 'combobox', 'listbox', 'slider'])

/**
 * What the app declares a control does and needs, as a suffix: its action
 * ("does 'save campaign'", unless its name already says it), its purpose, and
 * what it requires first, each by name with its current value or state. Empty
 * when it declares nothing (or nothing the name doesn't say).
 */
export function declaredOf(node: SemanticNode, index: ReadonlyMap<string, Located>) {
  const parts: string[] = []
  // both are kebab-case verb phrases (`save-campaign`): read as words
  if (node.action && !saysAction(node, node.action)) parts.push(`does '${words(node.action)}'`)
  if (node.purpose) parts.push(`purpose '${words(node.purpose)}'`)
  if (node.requires?.length) {
    const needs = node.requires.map((id) => {
      const req = index.get(id)?.node
      if (!req) return 'something not on this page'
      const value = valueOf(req)
      const filled = value !== undefined && value !== ''
      const notes = [filled ? `'${value}'` : VALUE_ROLES.has(req.role) ? 'empty' : '', ...stateOf(req)].filter(Boolean)
      return `${nameOf(req)} (${notes.join(', ')})`
    })
    parts.push(`requires ${needs.join(', ')}`)
  }
  return parts.length ? `; ${parts.join('; ')}` : ''
}

/**
 * Whether the control's name or description already says what its declared
 * action does, so "does '…'" would add nothing: every word of it, the verb
 * too, is there ("Filter by Status" for `filter`, "Add filter" for
 * `add-filter`). Not "Website" for `switch-website`: the verb was the cue
 * that matched "Pulse App's visitors" to the website filter.
 */
function saysAction(node: SemanticNode, action: string) {
  const said = `${node.name ?? ''} ${node.description ?? ''}`.toLowerCase()
  return words(action).toLowerCase().split(' ').filter(Boolean).every((w) => said.includes(w))
}

/** A radio by its group: "Chart metric: 'Sessions'". */
function radioName(node: SemanticNode, parents: SemanticNode[]) {
  const group = parents.at(-1)
  return node.role === 'radio' && node.name && group && (group.role === 'radiogroup' || group.role === 'group') && group.name
    ? `${group.name}: '${node.name}'`
    : undefined
}

/**
 * What a control is, in a few words: "link 'Acquisition'", "Chart metric:
 * 'Sessions'", "button 'Edit' in row 'Spring Sale'" (a control in a table row
 * says which row, unless its name already does: "Actions for Spring Sale").
 * Its container is left out (whereOf: added only where two options would read
 * the same, candidates.ts).
 */
export function whatOf(node: SemanticNode, parents: SemanticNode[]) {
  const name = radioName(node, parents) ?? nameOf(node)
  return node.row && !node.name?.includes(node.row) ? `${name} in row '${node.row}'` : name
}

/**
 * A named list not inside other content, which the outline shows with its
 * first items ("list 'Active report filters': Device is Mobile"): often where
 * the page is, not an answer to read on demand.
 */
export const outlinedList = (node: SemanticNode, parents: SemanticNode[]) =>
  node.role === 'list' && !!node.name && !node.kind && !parents.some((p) => p.kind)

/** A control whose current setting says something about the page (a pressed toggle, the current tab, a value). */
export function isSet(node: SemanticNode) {
  const s = node.state ?? {}
  if (node.kind) return false
  if (s.pressed === true || s.checked === true || s.expanded === true) return true
  if (node.role === 'tab' && s.selected) return true
  return node.value !== undefined && node.value !== '' && !node.redacted
}

/**
 * Whether the page outline shows a control's setting (state.ts): a control
 * that's set, or an annotated control such as a filter. Its option then
 * doesn't say it again: the decision model's "done?" question sees the state,
 * not the options, while "next" sees both. What the app says of the control
 * stays in the option all the same: "next" chooses by the option's own words
 * ("Choices: … Pulse App …" for "Pulse App's visitors").
 */
export const settingOutlined = (node: SemanticNode, parents: SemanticNode[]) =>
  isSet(node) || (!!node.kind && ACTIONABLE_ROLES.has(node.role) && !parents.some((p) => p.kind))

/** Its value and state, as a suffix: " (currently '30d', required)"; empty when there's nothing. */
export function notesOf(node: SemanticNode, skip: string[] = []) {
  const v = valueOf(node)
  const notes = [v !== undefined && v !== '' ? `currently '${v}'` : '', ...stateOf(node).filter((n) => !skip.includes(n))].filter(Boolean)
  return notes.length ? ` (${notes.join(', ')})` : ''
}

/** A link's address as read: percent-encoding decoded once ("/engagement/pages//cart"). */
export function hrefOf(href: string) {
  try {
    return decodeURIComponent(href)
  } catch {
    return href
  }
}

/** What the outline shows of a node's content before it's cut (the rest is read on demand: reveal.ts). */
export const MAX_CONTENT = 300
/** List items the outline shows before the rest are held back. */
export const LIST_SHOWN = 6

/**
 * Status and alert messages showing when the task began, by node id. While one
 * still shows unchanged it isn't news: a confirmation from before the task (a
 * toast that outlived its screen) says nothing about what the task did.
 */
export type EarlierMessages = ReadonlyMap<string, string>

/** The status and alert messages a page shows, by node id. */
export function messagesOf(root: SemanticNode): Map<string, string> {
  const out = new Map<string, string>()
  for (const [id, { node }] of indexNodes(root)) {
    if ((node.role === 'status' || node.role === 'alert') && node.text) out.set(id, node.text)
  }
  return out
}

/** " (already shown when the task began)" for a message from before the task, still unchanged. */
export const earlierNote = (node: SemanticNode, earlier?: EarlierMessages) =>
  earlier && node.text !== undefined && earlier.get(node.id) === node.text ? ' (already shown when the task began)' : ''

/** A table in one line: its columns and size, never its rows. */
export function tableOf(table: NonNullable<SemanticNode['table']>) {
  return `${table.columns.filter(Boolean).join(', ')}; ${table.totalRows} rows`
}

/**
 * What a content node shows, for answering a question by pointing at it: its
 * description, value and text, then those of the non-actionable parts inside
 * it (a chart's figure summary, a list's items), without repeats. Capped, with
 * a list's first items only; `full` for all of it (once the model reads it).
 */
export function contentOf(node: SemanticNode, full = false): string {
  const parts: string[] = []
  const add = (s: string | undefined) => {
    if (s && !parts.includes(s)) parts.push(s)
  }
  const walk = (n: SemanticNode, own: boolean) => {
    if (!own && ACTIONABLE_ROLES.has(n.role)) return
    add(n.description)
    add(valueOf(n))
    add(n.text)
    if (n.table) add(`table: ${tableOf(n.table)}`)
    if (n.items) add((full ? n.items : n.items.slice(0, LIST_SHOWN)).join(', '))
    n.children?.forEach((c) => walk(c, false))
  }
  walk(node, true)
  const text = parts.join(' · ')
  return !full && text.length > MAX_CONTENT ? `${text.slice(0, MAX_CONTENT - 1)}…` : text
}

/** A node's own loose text, when no other line or option carries it: not a control's, nor named content's or inside it. */
export const looseText = (node: SemanticNode, parents: SemanticNode[]) =>
  !!node.text && !ACTIONABLE_ROLES.has(node.role) && !node.kind && !parents.some((p) => p.kind)

/**
 * A named container's description, when no other line or option carries it:
 * what the app says of an area as a whole ("Unsaved changes: …", a group's
 * error). Containers otherwise have no line; their contents do.
 */
export const describedContainer = (node: SemanticNode, parents: SemanticNode[]) =>
  !!node.name && !!node.description && CONTAINERS.has(node.role) && !ACTIONABLE_ROLES.has(node.role) && !node.kind && !parents.some((p) => p.kind)
