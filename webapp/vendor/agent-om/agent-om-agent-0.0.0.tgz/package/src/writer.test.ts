import { describe, expect, it } from 'vitest'
import type { Chat, ChatRequest } from './chat'
import type { FormField } from './form'
import { chatWriter } from './writer'

// The writer over a scripted chat model: what it sends, what it makes of the replies.

function chatting(reply: unknown) {
  const sent: ChatRequest[] = []
  const chat = (async (request: ChatRequest) => (sent.push(request), reply)) as Chat
  return { chat, sent }
}

describe('the writer', () => {
  it('asks with reasoning off by default (a model that reasons by default spent ~1,000 hidden tokens a reply)', async () => {
    const { chat, sent } = chatting({ text: 'reddit.com', answer: 'ok' })
    const writer = chatWriter(chat)
    await writer.field({ state: { goal: 'x' } })
    await writer.answer({ state: { goal: 'x' } })
    expect(sent.map((r) => r.reasoning)).toEqual(['none', 'none'])
    const reasoning = chatting({ answer: 'ok' })
    await chatWriter(reasoning.chat, { reasoning: 'low' }).answer({ state: {} })
    expect(reasoning.sent[0].reasoning).toBe('low')
  })

  it('a field it has no value for is null; a reply in the wrong shape is an error', async () => {
    expect(await chatWriter(chatting({ text: null }).chat).field({ state: {} })).toBeNull()
    expect(await chatWriter(chatting({ text: '  sale ' }).chat).field({ state: {} })).toBe('sale')
    await expect(chatWriter(chatting({}).chat).answer({ state: {} })).rejects.toThrow('Chat API: no answer')
  })

  const fields: FormField[] = [
    { key: 'f1', nodeId: 'first', label: 'First name', kind: 'text', required: true },
    { key: 'f2', nodeId: 'access', label: 'Access', kind: 'radio', choices: ['View', 'Edit'], radios: [] },
  ]
  const form = { state: { goal: 'invite Ana' }, form: { name: "form 'Invite'", fields } }

  it('fills a form in one call: every field asked for, the reply by key', async () => {
    const { chat, sent } = chatting({ f1: '  Ana ', f2: 'Edit' })
    const values = await chatWriter(chat).form!(form)
    // text trimmed as a field's is
    expect(values).toEqual({ f1: 'Ana', f2: 'Edit' })
    expect(sent[0]).toMatchObject({ reasoning: 'none', schema: { required: ['f1', 'f2'] } })
    expect(sent[0].user).toMatchObject({ goal: 'invite Ana', form: { name: "form 'Invite'", fields: [{ key: 'f1', label: 'First name', required: true }, { key: 'f2' }] } })
    // a key it left out is a field left alone
    expect(await chatWriter(chatting({ f1: 'Ana' }).chat).form!(form)).toEqual({ f1: 'Ana', f2: null })
  })
})

