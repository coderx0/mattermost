import { ACTIONABLE_ROLES, actionableNodes, type SemanticNode, type SemanticState } from '@agent-om/core'
import type { ActionStep } from '@agent-om/actions'
import { MAX_CRITERIA } from './decide'
import { contentOf, declaredOf, looseText, describedOf, earlierNote, hrefOf, indexNodes, nameOf, notesOf, settingOutlined, whatOf, wheresOf, type EarlierMessages, type Located } from './describe'
import { fillRest, formFills, formName, type FormFill } from './form'
import { isSecretField } from './secret'

// The options the decision model chooses from. Each option is one complete
// decision (action + target + any small parameter), because the model can't
// pick an action and then a target: questions in a request can't see each
// other's answers.

export const NONE = 'none'

export type ActionCandidate = {
  /** the option's own name (`click:<id>`, `select:<id>=<choice>`…); the models see a short key for it (keys.ts) */
  key: string
  description: string
  /** what it acts on, in a few words ("link 'Acquisition'"), for the history */
  what: string
  nodeId: string
  /**
   * the step to run; `input` gets its text from a second decision; `read` acts
   * on nothing, it shows the model content the outline held back (reveal.ts);
   * `fill` gets every field's value from the writer and sets them (form.ts);
   * `secret` fills a secret field with what the user enters (secret.ts)
   */
  step:
    | ActionStep
    | { type: 'input'; target: string; value?: undefined }
    | { type: 'read'; target: string }
    | { type: 'fill'; target: string; fill: FormFill }
    | { type: 'secret'; target: string }
}

export type AnswerCandidate = {
  key: string
  description: string
  nodeId: string
  text: string
  /** what to call the answer when shown, if not its node's name (a table row: its first cell) */
  label?: string
}

const TOGGLE_ROLES = new Set(['checkbox', 'switch', 'menuitemcheckbox'])
const TEXT_ROLES = new Set(['textbox', 'searchbox', 'spinbutton'])
/** Actionable roles with no step of their own: a scrollbar (scrolling is the executor's, not a choice). */
const SKIP_ROLES = new Set(['scrollbar'])

/** A slider's bounds, if it has them: " from 0.05 to 1". */
const rangeOf = (node: SemanticNode) =>
  node.min !== undefined && node.max !== undefined ? ` from ${node.min} to ${node.max}` : node.min !== undefined ? ` from ${node.min}` : node.max !== undefined ? ` up to ${node.max}` : ''

/** A slider's raw value, and what it shows when that differs: " (now 0.15, shown as 15%)". */
const nowOf = (node: SemanticNode) => {
  if (node.value === undefined || node.value === '') return ''
  const shown = node.valueText && node.valueText !== String(node.value) ? `, shown as ${node.valueText}` : ''
  return ` (now ${node.value}${shown})`
}

const inside = (loc: Located, scopes: ReadonlySet<string>) =>
  scopes.has(loc.node.id) || loc.parents.some((p) => scopes.has(p.id))

/** An option while it's built: `what` it acts on, the rest of its description, and where it sits, the nearest container first (for telling twins apart). */
type Draft = Omit<ActionCandidate, 'description'> & { verb: string; rest: string; wheres: string[]; row: boolean }

/**
 * Every action that can be taken now, one option each, plus "none". Options
 * under `exclude` ids are left out. Each is described in a few words: what it
 * acts on and what it does ("link 'Acquisition' → /acquisition"); its
 * container only where two options would otherwise read the same. With
 * `fill` (there's a writer to give the values), each form with two fields or
 * more can also be filled in one step (form.ts), a large one by section. A
 * secret field is never typed into: with `secrets` (the host can ask the user
 * for one, secret.ts) it's filled with what the user enters; without, it isn't
 * offered.
 */
export function actionCandidates(
  state: SemanticState,
  exclude: ReadonlySet<string> = new Set(),
  { fill = false, secrets = false }: { fill?: boolean; secrets?: boolean } = {},
): ActionCandidate[] {
  const index = indexNodes(state.root)
  const out: Draft[] = []
  const forms = new Set<string>()
  /** forms with a field on the page, for filling in one step */
  const fillable = new Set<string>()
  // Links to the same place are the same action; offering both splits the model's vote.
  const hrefs = new Set<string>()

  for (const { id } of actionableNodes(state)) {
    const loc = index.get(id)!
    if (inside(loc, exclude) || SKIP_ROLES.has(loc.node.role)) continue
    const { node, parents } = loc
    if (node.form) fillable.add(node.form)
    const base = { what: whatOf(node, parents), nodeId: id, wheres: wheresOf(parents), row: !!node.row && !node.name?.includes(node.row) }
    // its setting, if the outline shows it: not said again
    const shown = settingOutlined(node, parents)
    // what the app declares it does and needs (guidelines 3.3, 3.7)
    const declared = declaredOf(node, index)

    const on = node.state?.checked ?? node.state?.pressed
    if (TOGGLE_ROLES.has(node.role) || node.state?.pressed !== undefined) {
      const want = on !== true
      out.push({
        ...base,
        key: `${want ? 'toggle-on' : 'toggle-off'}:${id}`,
        verb: `turn ${want ? 'on' : 'off'} `,
        // one that's off says so: the outline shows only those that are on
        rest: (shown ? '' : notesOf(node, ['on'])) + describedOf(node) + declared,
        step: { type: 'toggle', target: id, on: want },
      })
    } else if (node.role === 'slider') {
      // a number within its range, set as a field's value is (the browser keeps it in range and on
      // its steps); its raw value beside what it shows, which can be on another scale (15% for 0.15)
      if (node.state?.readonly) continue
      out.push({ ...base, key: `input:${id}`, verb: 'set ', rest: ` to a number${rangeOf(node)}${nowOf(node)}` + describedOf(node) + declared, step: { type: 'input', target: id } })
    } else if (TEXT_ROLES.has(node.role)) {
      // nothing to type into a read-only field; its value is in the outline
      if (node.state?.readonly) continue
      if (node.form) forms.add(node.form)
      if (isSecretField(node)) {
        if (secrets) out.push({ ...base, key: `secret:${id}`, verb: 'fill ', rest: (shown ? '' : notesOf(node)) + ' with a secret the user enters' + declared, step: { type: 'secret', target: id } })
        continue
      }
      // with what the field matches, if the app says (a search's rule decides what's worth typing)
      out.push({ ...base, key: `input:${id}`, verb: 'type into ', rest: (shown ? '' : notesOf(node)) + describedOf(node) + declared, step: { type: 'input', target: id } })
    } else if (node.items && (node.role === 'combobox' || node.role === 'listbox')) {
      // native <select>: one option per choice it offers (its current value is in the outline)
      for (const item of node.items) {
        if (item === node.value) continue
        out.push({
          ...base,
          key: `select:${id}=${item}`,
          verb: '',
          rest: ` → '${item}'${declared}`,
          step: { type: 'select', target: id, value: item },
        })
      }
    } else {
      if (node.role === 'link' && node.href) {
        if (hrefs.has(node.href)) continue
        hrefs.add(node.href)
      }
      out.push({ ...base, key: `click:${id}`, verb: '', rest: clickRest(node, shown) + declared, step: { type: 'click', target: id } })
    }
  }

  // A form filled in one step (with a writer): each chunk its own option.
  if (fill) {
    for (const formId of fillable) {
      const loc = index.get(formId)
      if (!loc || inside(loc, exclude)) continue
      const fills = formFills(state, formId, exclude)
      if (fills.reduce((n, f) => n + f.fields.length, 0) < 2) continue
      const { name, byFields } = formName(state, formId, fills.flatMap((f) => f.fields))
      for (const f of fills) {
        out.push({
          key: `fill:${formId}#${f.chunk}`,
          what: name,
          nodeId: formId,
          verb: 'fill ',
          rest: fillRest(f, byFields),
          wheres: [],
          row: false,
          step: { type: 'fill', target: formId, fill: f },
        })
      }
    }
  }

  // Forms with a field on offer can be submitted.
  for (const formId of forms) {
    const loc = index.get(formId)
    if (!loc || inside(loc, exclude)) continue
    out.push({
      key: `submit:${formId}`,
      what: whatOf(loc.node, loc.parents),
      nodeId: formId,
      verb: 'submit ',
      rest: '',
      wheres: wheresOf(loc.parents),
      row: false,
      step: { type: 'submit', target: formId },
    })
  }

  // What the page shows only on hover: an element that says what hovering over
  // it shows (data-agentom-reveals), and a menu item whose submenu opens on
  // hover. Last, after what's shown: offered while what they'd show is closed.
  for (const [id, { node, parents }] of index) {
    if (inside({ node, parents }, exclude)) continue
    const submenu = node.role === 'menuitem' && node.haspopup === 'menu' && !node.state?.expanded
    if (!node.reveals?.length && !submenu) continue
    out.push({
      key: `hover:${id}`,
      what: whatOf(node, parents),
      nodeId: id,
      verb: 'hover over ',
      rest: node.reveals?.length ? ` (shows: ${node.reveals.join(', ')})` : ' (opens its menu)',
      wheres: wheresOf(parents),
      row: !!node.row && !node.name?.includes(node.row),
      step: { type: 'hover', target: id },
    })
  }

  // Twins (a "Filter by Source" in two tables) say where each one is: by the
  // nearest container where they differ, so a day in each of two calendars,
  // both "October", says which calendar.
  const twins = new Map<string, Draft[]>()
  const plain = (d: Draft) => d.verb + d.what + d.rest
  for (const d of out) twins.set(plain(d), [...(twins.get(plain(d)) ?? []), d])
  const levelOf = new Map<string, number>()
  for (const [key, group] of twins) {
    if (group.length < 2) continue
    const depth = Math.max(...group.map((d) => d.wheres.length))
    let level = 0
    while (level < depth && new Set(group.map((d) => d.wheres[level])).size === 1) level++
    levelOf.set(key, level < depth ? level : 0)
  }
  return out.slice(0, MAX_CRITERIA - 1).map((draft) => {
    const { verb, rest, wheres, row, ...d } = draft
    const level = levelOf.get(plain(draft))
    const where = level === undefined ? '' : (wheres[level] ?? wheres[0] ?? '')
    const what = where ? `${d.what} ${row ? `of ${where.slice('in '.length)}` : where}` : d.what
    return { ...d, what, description: verb + what + rest }
  })
}

/**
 * What a click does, after its target: where a link goes, what it opens, its
 * state unless the outline shows it (`shown`); then what the app says about it.
 */
function clickRest(node: SemanticNode, shown: boolean) {
  const hints: string[] = []
  let skip: string[] = []
  // a link within the page goes nowhere: say so, or "→ #set-it-up" reads like a step of the task
  if (node.href) hints.push(node.href.startsWith('#') ? `jumps to the section ${hrefOf(node.href)} of this page` : `→ ${hrefOf(node.href)}`)
  if (node.haspopup === 'dialog') {
    hints.push(node.state?.expanded ? 'closes its dialog' : 'opens a dialog')
    skip = ['open']
  } else if (node.haspopup || node.role === 'combobox') {
    hints.push(node.state?.expanded ? 'closes its list' : `opens its ${node.haspopup === 'menu' ? 'menu' : 'list'}`)
    skip = ['open']
  } else if (node.state?.expanded !== undefined) {
    hints.push(node.state.expanded ? 'collapses it' : 'expands it')
    skip = ['open']
  }
  // an open section, a filled field: the outline says so. A chosen radio and the
  // open tab say so here too: clicking them changes nothing, and the outline's
  // "Role: 'Admin'" reads just like the option
  const unchanged = node.role === 'radio' && node.state?.checked === true ? 'chosen' : node.role === 'tab' && node.state?.selected ? 'selected' : undefined
  const notes = unchanged ? ` (${unchanged})` : shown ? '' : notesOf(node, [...skip, 'off'])
  // what the app says about the control beyond its name (e.g. the pages a section holds)
  return `${notes}${hints.length ? ` ${hints.join(', ')}` : ''}${describedOf(node)}`
}

const ANSWER_ROLES = new Set(['table', 'grid', 'treegrid', 'list', 'status', 'alert', 'meter', 'progressbar', 'timer'])

/**
 * Nodes that can answer a question: annotated content (metrics, charts) and
 * tables, lists, status and meters not already inside one. Plus "none". Each
 * is offered by its name ("metric 'Visitors'"); one without a name by what it
 * shows (a status message).
 */
export function answerCandidates(
  state: SemanticState,
  exclude: ReadonlySet<string> = new Set(),
  /** messages already showing when the task began: said so, so they aren't taken as its result */
  earlier?: EarlierMessages,
): AnswerCandidate[] {
  const out: AnswerCandidate[] = []
  const walk = (node: SemanticNode, parents: SemanticNode[]) => {
    if (exclude.has(node.id)) return
    const content =
      (node.kind && !ACTIONABLE_ROLES.has(node.role)) || (ANSWER_ROLES.has(node.role) && (node.name || node.text))
    if (content) {
      const text = contentOf(node)
      const shown = node.name || !text ? nameOf(node) : `${nameOf(node)}: ${text}`
      out.push({ key: node.id, description: shown + earlierNote(node, earlier), nodeId: node.id, text })
      return // its parts are covered by it
    }
    // what a node says in prose (its loose text) can answer too; its parts are offered on their own
    if (looseText(node, parents)) out.push({ key: node.id, description: `${nameOf(node)}: ${node.text}`, nodeId: node.id, text: node.text! })
    node.children?.forEach((c) => walk(c, [...parents, node]))
  }
  walk(state.root, [])
  return out.slice(0, MAX_CRITERIA - 1)
}

const STOPWORDS = new Set(
  'a an the to of in on at by for from with and or is are be it its this that me my i you your please show find search filter open go get set type enter put what whats which how'.split(
    ' ',
  ),
)

export const EMPTY_TEXT = '(empty)'

/**
 * The texts an input could get: runs of up to 5 consecutive words from the
 * query (the model can't write text, only pick it), skipping runs made of
 * filler words only. Plus "(empty)" to clear the field.
 */
export function textCandidates(query: string): string[] {
  const words = query
    .split(/\s+/)
    .map((w) => w.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, ''))
    .filter(Boolean)
  const spans = new Set<string>()
  for (let i = 0; i < words.length; i++) {
    for (let j = i + 1; j <= Math.min(words.length, i + 5); j++) {
      const run = words.slice(i, j)
      if (run.every((w) => STOPWORDS.has(w.toLowerCase().replace(/'/g, '')))) continue
      spans.add(run.join(' '))
    }
  }
  return [...spans].slice(0, MAX_CRITERIA - 1).concat(EMPTY_TEXT)
}
