/**
 * An agent that carries out a goal on a page through the Semantic UI
 * Projection. No DOM in its code: it reads projection snapshots and acts
 * through the executor's steps, on a page given as an interface (page.ts).
 */
export * from './candidates'
export * from './change'
export * from './chat'
export * from './decide'
export * from './describe'
export * from './form'
export * from './keys'
export * from './loop'
export * from './page'
export * from './policy'
export * from './reveal'
export * from './secret'
export * from './settle'
export * from './site-outline'
export * from './state'
export * from './step'
export * from './util'
export * from './writer'
