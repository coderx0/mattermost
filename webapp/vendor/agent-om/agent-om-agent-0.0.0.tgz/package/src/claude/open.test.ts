import { describe, expect, it } from 'vitest'
import type { SemanticNode, SemanticState } from '@agent-om/core'
import type { AgentEvent } from '../loop'
import { claudePrompt } from './loop'
import { ProjectionTools } from './tools'
import { projectionView, type ActResult, type ViewSource } from './view'

// Opening a page by its path (`open`): offered only by a host that can load
// one (from Node, where a load doesn't end the loop), only for a path on the
// same site, and the page it opens is shown whole.

const state = (path: string, children: SemanticNode[]): SemanticState => ({
  revision: 1,
  timestamp: 0,
  context: { url: `https://app.test${path}`, path, query: {}, title: path === '/' ? 'Home' : 'Reports' },
  root: { id: 'root', role: 'document', children },
})

const home = state('/', [{ id: 'h', role: 'heading', name: 'Home', state: { level: 1 } }, { id: 'nav.reports', role: 'link', name: 'Reports', href: '/reports' }])
const reports = state('/reports', [{ id: 'h', role: 'heading', name: 'Reports', state: { level: 1 } }])

/** A page that `open` moves to the state at a path; `fails` makes it not load. */
function site(o: { fails?: string } = {}) {
  let at = home
  const opened: string[] = []
  const events: AgentEvent[] = []
  const source: ViewSource = {
    snapshot: () => at,
    run: async () => ({ ok: true }),
    exclude: new Set(),
    onEvent: (e) => events.push(e),
    async open(path): Promise<ActResult> {
      opened.push(path)
      if (o.fails) return { ok: false, reason: 'not-loaded', message: o.fails }
      at = path === '/reports' ? reports : home
      return { ok: true }
    },
  }
  return { source, opened, events }
}

type RunnableTool = { name: string; run(input: unknown): Promise<string> }
const toolsOf = (t: ProjectionTools) => t.tools as unknown as RunnableTool[]
const named = (t: ProjectionTools, name: string) => toolsOf(t).find((x) => x.name === name)!

describe('open', () => {
  it('is a tool only when the host can load a page by its path', () => {
    const { source } = site()
    const { open: _, ...inPage } = source
    expect(toolsOf(new ProjectionTools({ hooks: projectionView(inPage) })).map((t) => t.name)).not.toContain('open')
    expect(toolsOf(new ProjectionTools({ hooks: projectionView(source) })).map((t) => t.name)).toContain('open')
    // and the prompt counts it as an action only then
    expect(claudePrompt({ actions: 30, modelCalls: 60 })).not.toContain('opening a page')
    expect(claudePrompt({ actions: 30, modelCalls: 60 }, { open: true })).toContain('submitting, opening a page)')
  })

  it("takes only a path on this site, never another site's address", async () => {
    const { source, opened } = site()
    const open = named(new ProjectionTools({ hooks: projectionView(source) }), 'open')
    for (const path of ['https://other.test/', '//other.test/x', 'reports', 'javascript:alert(1)'])
      await expect(open.run({ path })).rejects.toThrow('path must be a path on this site, starting with /.')
    expect(opened).toEqual([])
    await expect(open.run({ path: '/reports?tab=all' })).resolves.toBe('Opened.')
    expect(opened).toEqual(['/reports?tab=all'])
  })

  it('shows the page it opened whole, even at the same path, and tells the step in our words', async () => {
    const { source, events } = site()
    const tools = new ProjectionTools({ hooks: projectionView(source) })
    const read = named(tools, 'read_page')
    await read.run({})
    // the same page again: only what changed
    expect(await read.run({})).toContain('nothing changed since your last read_page')
    await named(tools, 'open').run({ path: '/' })
    // loaded anew at the same path: whole
    expect((await read.run({})).split('\n')[0]).toBe('Page: Home (/)')
    await named(tools, 'open').run({ path: '/reports' })
    expect((await read.run({})).split('\n')).toContain("heading 'Reports'")
    expect(events.filter((e) => e.type === 'acting').map((e) => (e as { description: string }).description)).toEqual(['opened /', 'opened /reports'])
  })

  it("says a page that didn't load didn't, as the model's error", async () => {
    const { source } = site({ fails: 'net::ERR_CONNECTION_REFUSED' })
    await expect(named(new ProjectionTools({ hooks: projectionView(source) }), 'open').run({ path: '/reports' })).rejects.toThrow(
      "Error: /reports didn't load: net::ERR_CONNECTION_REFUSED.",
    )
  })
})
