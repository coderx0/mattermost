import { betaTool } from '@anthropic-ai/sdk/helpers/beta/json-schema'
import { ToolError } from '@anthropic-ai/sdk/helpers/beta/toolsets'
import type { BetaToolUseBlock } from '@anthropic-ai/sdk/resources/beta/messages/messages'
import type { FindQuery } from './find'
import { BEHIND_POPUP, DECLINED, NOT_FILLED, NOT_SECRET, SECRET_FIELD, type ActResult, type ProjectionHooks, type ProjectionStep, type ReadResult } from './view'

// Claude's tools on the projection: a standard Claude agent reads our agent's
// view of the page (read_page, read) and acts through our executor by node id
// (click, hover, toggle, type, select, submit), the steps our agent can take; with a
// host that asks its user for secrets, fill_secret too; with a host that can
// load a page by its path, open, as typing an address (view.ts). View and
// steps are the host's (view.ts: in a page, or in Node over another app's).
//
// They are custom tools, which the SDK's runner runs side by side and whose
// every error it hands the model. Held to the toolsets' rules instead: a
// turn's calls run in the order the model wrote them, the first failure
// stops the rest (with the toolsets' words), and a failure of the host's
// machinery ends the run (the loop's `turn`) instead of reaching the model.
//
// Each call's input is checked first (refused with a fixed phrase the model
// reads). A host can pass every call through its own pipeline instead (the
// benchmark's: inputs checked, actions counted, the page settled), and say
// which of its errors end the run.

const NOT_EXECUTED = 'Not executed: an earlier action in this turn failed.'

/** The calls that act on the page; reading doesn't count. */
export const ACTIONS: ReadonlySet<string> = new Set(['click', 'hover', 'toggle', 'type', 'select', 'submit', 'fill_secret', 'open', 'find_items'])

/** A refusal of the model's own input: the model reads its (fixed) text. */
export class InputRefused extends ToolError {}

/** The user declined a step they were asked to confirm: the run ends. */
export class Declined extends Error {
  constructor() {
    super('Cancelled.')
    this.name = 'Declined'
  }
}

const refuse = (message: string): never => {
  throw new InputRefused(message)
}

/** The fields each tool takes; `!` marks a required one. */
const FIELDS: Record<string, string[]> = {
  read_page: ['full'],
  read: ['id!'],
  click: ['id!'],
  hover: ['id!'],
  toggle: ['id!', 'on!'],
  type: ['id!', 'text!'],
  select: ['id!', 'value!'],
  submit: ['id!'],
  fill_secret: ['id!'],
  open: ['path!'],
  find_items: ['collection!', 'text', 'has', 'direction', 'count', 'limit'],
}

/** A call's input, checked: its fields as the tool takes them, or a refusal (InputRefused). */
export function checkInput(name: string, input: Record<string, unknown>): Record<string, unknown> {
  const fields = FIELDS[name] ?? refuse(`Unknown tool: ${name}.`)
  const allowed = new Set(fields.map((f) => f.replace('!', '')))
  const out: Record<string, unknown> = {}
  for (const [key, value] of Object.entries(input ?? {})) {
    if (value === undefined || value === null) continue
    if (!allowed.has(key)) refuse(`${key} is not accepted for ${name}.`)
    out[key] = value
  }
  for (const f of fields.filter((f) => f.endsWith('!')).map((f) => f.slice(0, -1))) {
    if (out[f] === undefined) refuse(`${f} is required for ${name}.`)
  }
  for (const f of ['id', 'text', 'value', 'path', 'collection', 'has']) if (out[f] !== undefined && typeof out[f] !== 'string') refuse(`${f} must be a string.`)
  if (out.direction !== undefined && out.direction !== 'up' && out.direction !== 'down') refuse('direction must be up or down.')
  if (out.count !== undefined && typeof out.count !== 'boolean') refuse('count must be true or false.')
  if (out.limit !== undefined && !(Number.isInteger(out.limit) && (out.limit as number) > 0)) refuse('limit must be a whole number above 0.')
  // a path on this site: not an address of another one
  if (out.path !== undefined && !/^\/(?!\/)/.test(out.path as string)) refuse('path must be a path on this site, starting with /.')
  if (out.id !== undefined && !(out.id as string).trim()) refuse('id must name a node.')
  if (out.on !== undefined && typeof out.on !== 'boolean') refuse('on must be true or false.')
  if (out.full !== undefined && typeof out.full !== 'boolean') refuse('full must be true or false.')
  return out
}

/** The executor's reasons, in words (its failure kinds, @agent-om/actions), and the view's own. `secrets`: fill_secret is offered. */
function failure(step: ProjectionStep, r: Extract<ActResult, { ok: false }>, secrets: boolean): string {
  const id = step.id
  switch (r.reason) {
    case SECRET_FIELD: return `Error: ${id} is a secret field: you never type a secret.${secrets ? ' fill_secret asks the user to fill it.' : ''}`
    case NOT_SECRET: return `Error: ${id} is not a secret field: fill_secret fills only a password field (or another field the page keeps secret).`
    case NOT_FILLED: return `Error: ${id} holds nothing after filling it.`
    case BEHIND_POPUP: return `Not run: ${id} is outside a popup that opened since your last read_page; only the popup can be used until it closes. Read the page to see what it offers.`
    case 'not-found': return `Error: ${id} is not on the page now. Read the page again to see what is.`
    case 'not-rendered': return `Error: ${id} is not shown on the page.`
    case 'inert': return `Error: ${id} can't be used while something else on the page is open.`
    case 'disabled': return `Error: ${id} is disabled.`
    case 'covered': return `Error: something on the page is covering ${id}.`
    case 'not-editable': return `Error: ${id} is not a text field.`
    case 'readonly': return `Error: ${id} is read-only.`
    case 'not-selectable': return `Error: ${id} is not a drop-down to choose from.`
    case 'no-option': return `Error: ${id} has no option ${JSON.stringify(step.type === 'select' ? step.value : '')}.`
    case 'not-toggleable': return `Error: ${id} can't be turned on or off.`
    case 'unchanged': return `Error: ${id} didn't change.`
    case 'no-form': return `Error: ${id} is not in a form.`
    case 'invalid': return `Error: the form isn't filled in validly, so it wasn't submitted.`
    case 'timeout': return `Error: ${id} didn't become usable in time.`
    case DECLINED: throw new Declined()
    // aborted, no resolver: ours, not the model's
    default: throw new Error(`the executor failed: ${r.reason}: ${r.message}`)
  }
}

/** The plain acknowledgement of a step that ran (no observation attached). */
const done = (s: ProjectionStep) =>
  s.type === 'toggle' ? (s.on ? 'Turned on.' : 'Turned off.') : { click: 'Clicked.', hover: 'Hovered.', type: 'Typed.', select: 'Selected.', submit: 'Submitted.', fill_secret: 'Filled.' }[s.type]

type Turn = { order: string[]; finished: Promise<void>[]; finish: (() => void)[]; failed: boolean; stop?: unknown }

/** How a host runs one call: `run` gets the checked input. Default: checkInput, then run. */
export type ToolCall = (name: string, input: Record<string, unknown>, run: (checked: Record<string, unknown>) => Promise<string>) => Promise<string>

export type ProjectionToolsOptions = {
  hooks: ProjectionHooks
  /** an action read_page's description shows, as its tool call (default: `click <id>`) */
  example?: string
  /** every call through the host's pipeline (default: checkInput, then run) */
  call?: ToolCall
  /** which errors of a call end the run instead of reaching the model (default: all but the SDK's ToolError) */
  stops?: (error: unknown) => boolean
  /** the host asks its user for secrets (the view's `askSecret`): fill_secret is offered */
  secrets?: boolean
}

export class ProjectionTools {
  readonly #hooks: ProjectionHooks
  readonly #example: string
  readonly #call: ToolCall
  readonly #stops: (error: unknown) => boolean
  readonly #secrets: boolean
  #turn: Turn | undefined

  constructor(o: ProjectionToolsOptions) {
    this.#hooks = o.hooks
    this.#example = o.example ?? 'click <id>'
    this.#call = o.call ?? ((name, input, run) => run(checkInput(name, input)))
    this.#stops = o.stops ?? ((e) => !(e instanceof ToolError))
    this.#secrets = !!o.secrets
  }

  /** Whether a call is an action. */
  static isAction(call: BetaToolUseBlock): boolean {
    return !(call as { toolset_name?: string }).toolset_name && ACTIONS.has(call.name)
  }

  /** The loop's hook (loop.ts): a turn's calls, in order, then the end of the turn. */
  readonly turn = {
    start: (calls: BetaToolUseBlock[]) => {
      const order = calls.filter((c) => c.name in FIELDS).map((c) => c.id)
      const finish: (() => void)[] = []
      const finished = order.map(() => new Promise<void>((r) => finish.push(r)))
      this.#turn = { order, finished, finish, failed: false }
    },
    end: () => {
      const turn = this.#turn
      this.#turn = undefined
      if (turn && 'stop' in turn) throw turn.stop
    },
  }

  /** Run a call after the turn's calls before it, unless one of them failed. */
  async #inTurn(id: string, run: () => Promise<string>): Promise<string> {
    const turn = this.#turn
    const i = turn?.order.indexOf(id) ?? -1
    if (!turn || i < 0) return run()
    if (i > 0) await turn.finished[i - 1]
    try {
      if (turn.failed) throw new ToolError(NOT_EXECUTED)
      return await run()
    } catch (e) {
      turn.failed = true
      if (this.#stops(e) && !('stop' in turn)) turn.stop = e
      throw e
    } finally {
      turn.finish[i]()
    }
  }

  #tool(name: string, run: (input: Record<string, unknown>) => Promise<string>) {
    return (input: unknown, context?: { toolUse?: { id: string } }) =>
      this.#inTurn(context?.toolUse?.id ?? '', () => this.#call(name, (input ?? {}) as Record<string, unknown>, run))
  }

  async #open(path: string): Promise<string> {
    const r = await this.#hooks.open!(path)
    if (!r.ok) throw new ToolError(`Error: ${path} didn't load: ${r.message}.`)
    return 'Opened.'
  }

  async #act(step: ProjectionStep): Promise<string> {
    const r = await this.#hooks.act(step)
    if (!r.ok) throw new ToolError(failure(step, r, this.#secrets))
    return done(step)
  }

  /** The conversation's old tool results were cleared (context editing): the next read_page shows the whole page. */
  async cleared(): Promise<void> {
    await this.#hooks.forget()
  }

  /** The tools, as the loop takes them. */
  get tools() {
    const id = { type: 'string', description: 'The node id, as read_page shows it.' } as const
    const tool = (name: string, description: string, properties: Record<string, unknown>, run: (input: Record<string, unknown>) => Promise<string>, optional: string[] = []) =>
      betaTool({
        name,
        description,
        inputSchema: { type: 'object', properties, required: Object.keys(properties).filter((k) => !optional.includes(k)), additionalProperties: false } as never,
        run: this.#tool(name, run) as never,
      }) as unknown as ReturnType<typeof betaTool>
    return [
      tool(
        'read_page',
        `Read the page: where you are, an outline of what it shows, and every action you can take on it, each written as the tool call that takes it (such as [${this.#example}]) followed by what it does. Read it again after acting to see what changed: on the same page it shows only what changed since your last read_page.`,
        { full: { type: 'boolean', description: 'true to show the whole page even when it is the same page.' } },
        (input) => this.#hooks.view(input.full === true),
        ['full'],
      ),
      tool(
        'read',
        "Read content the page's outline holds back (a table's rows, a long list, the rest of the outline), named by the id in its [read …] action. From then on read_page shows it too.",
        { id },
        async (input) => {
          const r: ReadResult = await this.#hooks.read(input.id as string)
          if (!r.ok) throw new ToolError(`Error: ${String(input.id)} holds nothing back. read_page lists what can be read.`)
          return r.lines.join('\n')
        },
      ),
      tool('click', 'Click the element with this node id.', { id }, (input) => this.#act({ type: 'click', id: input.id as string })),
      tool(
        'hover',
        "Move the pointer onto the element with this node id, to show what the page shows only while the pointer is over it (such as a row's buttons, or a submenu). The pointer stays there while you click what it showed.",
        { id },
        (input) => this.#act({ type: 'hover', id: input.id as string }),
      ),
      tool(
        'toggle',
        'Turn a checkbox, switch or other on/off control on (true) or off (false).',
        { id, on: { type: 'boolean', description: 'true to turn it on, false to turn it off.' } },
        (input) => this.#act({ type: 'toggle', id: input.id as string, on: input.on as boolean }),
      ),
      tool(
        'type',
        "Replace the text in a text field with this text (an empty text clears it).",
        { id, text: { type: 'string', description: 'The text the field should hold.' } },
        (input) => this.#act({ type: 'type', id: input.id as string, text: input.text as string }),
      ),
      tool(
        'select',
        'Choose an option in a drop-down, by its value or its text.',
        { id, value: { type: 'string', description: "The option's value or text." } },
        (input) => this.#act({ type: 'select', id: input.id as string, value: input.value as string }),
      ),
      tool('submit', 'Submit the form this element belongs to (or the form itself).', { id }, (input) => this.#act({ type: 'submit', id: input.id as string })),
      ...(this.#hooks.find ? [tool(
        'find_items',
        "Find items of a list read_page shows as a kind of item (its line 'each item …'), or rows of a table, without reading them all: the items or rows whose line holds a text, or (a list's items) that have a control. With a direction it scrolls a list for more (older messages above, more products below) until it finds enough, the list goes no further, or 20 scrolls; a table is searched as it is on the page. Gives back only the matching lines, with a row's controls, or with count only how many match.",
        {
          collection: { type: 'string', description: "The list's or the table's id, as read_page shows it." },
          text: { type: 'string', description: "Text the item's line holds (ignoring case): words of a message, an author, a name." },
          has: { type: 'string', description: 'A control the item has, by its key in the list\'s kind, such as .replies.' },
          direction: { type: 'string', enum: ['up', 'down'], description: 'Scroll the list up (towards its start) or down (towards its end) for more items; without it, only the items on the page are searched.' },
          count: { type: 'boolean', description: 'true for only how many items match, searching as far as the list goes.' },
          limit: { type: 'integer', description: 'How many matches to find before stopping (default 1).' },
        },
        async (input) => {
          const r = await this.#hooks.find!(input as unknown as FindQuery)
          if (!r.ok) throw new ToolError(`Error: ${r.message}. find_items searches a list read_page shows as a kind of item (its line 'each item …'), by the id its own line gives ('(15 items; id …)'), or a table, by its id.`)
          if (input.count) return `${r.count} item${r.count === 1 ? '' : 's'} match. ${r.summary}`
          return [r.lines.length ? r.lines.join('\n') : 'No item matches.', r.summary].join('\n')
        },
        ['text', 'has', 'direction', 'count', 'limit'],
      )] : []),
      ...(this.#hooks.open
        ? [
            tool(
              'open',
              "Open this site's page at a path (such as /campaigns/c-12), as typing its address. The page loads anew, so what it held unsaved (text typed, a choice not applied) is gone. When the page has a link to where you're going, click it instead. Fill in a path's {placeholders} from the site's pages with ids from links you have read.",
              { path: { type: 'string', description: 'The path on this site, starting with /, with its query if it needs one.' } },
              (input) => this.#open(input.path as string),
            ),
          ]
        : []),
      ...(this.#secrets
        ? [
            tool(
              'fill_secret',
              'Fill a secret field (a password) with a secret the user enters: the user is asked for it, and you never see it. Says whether the field is filled.',
              { id },
              (input) => this.#act({ type: 'fill_secret', id: input.id as string }),
            ),
          ]
        : []),
    ]
  }
}
