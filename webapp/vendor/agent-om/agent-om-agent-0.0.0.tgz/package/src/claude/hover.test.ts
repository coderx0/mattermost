import { describe, expect, it } from 'vitest'
import type { ActionStep } from '@agent-om/actions'
import type { SemanticNode, SemanticState } from '@agent-om/core'
import type { AgentEvent } from '../loop'
import { ProjectionTools } from './tools'
import { projectionView, type ViewSource } from './view'

// Hovering (`hover`): the view offers it on what says it shows controls on
// hover, the tool takes it on any node, and it's never confirmed.

/** A message whose Reply shows only while the pointer is over it; deleting it is destructive. */
function channel() {
  let hovered = ''
  const ran: ActionStep[] = []
  const prompts: string[] = []
  const events: AgentEvent[] = []
  const post: () => SemanticNode = () => ({
    id: 'post.1',
    role: 'article',
    name: 'Message from Ada',
    reveals: ['Reply'],
    risk: 'destructive',
    children: hovered === 'post.1' ? [{ id: 'post.1.reply', role: 'button', name: 'Reply' }] : [],
  })
  const snapshot = (): SemanticState => ({
    revision: 1,
    timestamp: 0,
    context: { url: 'https://app.test/channel', path: '/channel', query: {}, title: 'Channel' },
    root: { id: 'root', role: 'document', children: [{ id: 'h', role: 'heading', name: 'Town Square', state: { level: 1 } }, post()] },
  })
  const source: ViewSource = {
    snapshot,
    async run(step) {
      ran.push(step)
      if (step.type === 'hover') hovered = String(step.target)
      return { ok: true }
    },
    exclude: new Set(),
    confirm: async (p) => (prompts.push(p), false),
    onEvent: (e) => events.push(e),
  }
  return { source, ran, prompts, events }
}

type RunnableTool = { name: string; run(input: unknown): Promise<string> }
const named = (t: ProjectionTools, name: string) => (t.tools as unknown as RunnableTool[]).find((x) => x.name === name)!

describe('hover', () => {
  it('is offered on what says what hovering shows; once hovered, the view has what it showed', async () => {
    const { source, ran, prompts, events } = channel()
    const tools = new ProjectionTools({ hooks: projectionView(source) })
    const read = named(tools, 'read_page')
    expect((await read.run({})).split('\n')).toContain("[hover post.1] hover over article 'Message from Ada' (shows: Reply)")
    await expect(named(tools, 'hover').run({ id: 'post.1' })).resolves.toBe('Hovered.')
    expect(ran).toEqual([{ type: 'hover', target: 'post.1' }])
    expect(await read.run({})).toContain("[click post.1.reply] button 'Reply'")
    // a destructive element is hovered without asking: hovering only shows things
    expect(prompts).toEqual([])
    expect(events.filter((e) => e.type === 'acting').map((e) => (e as { description: string }).description)).toEqual([
      "hovered over article 'Message from Ada'",
    ])
  })

  it('counts as an action, and takes any node, as a pointer can go anywhere', async () => {
    const { source, ran } = channel()
    const tools = new ProjectionTools({ hooks: projectionView(source) })
    await named(tools, 'hover').run({ id: 'h' })
    expect(ran).toEqual([{ type: 'hover', target: 'h' }])
    expect(ProjectionTools.isAction({ type: 'tool_use', id: 't', name: 'hover', input: {} } as never)).toBe(true)
  })
})
