import { describe, expect, it } from 'vitest'
import type { ActionStep } from '@agent-om/actions'
import type { SemanticNode, SemanticState } from '@agent-om/core'
import { PAGE } from '../reveal'
import { declaredId, ITEM_CONTENT } from './collections'
import { projectionView, type ViewSource } from './view'

// Repeated items in Claude's view (guideline 2.6): a feed whose items have ids
// the app gave them, and controls with ids relative to their item, is shown
// once as a kind and then as one line per item.

const HOVER = ['Add Reaction', 'save message', 'reply', 'more']

/** A message: its author's button, save, and what else it's given (`mention`: a button in its text with no key of its own). */
function post(id: string, author: string, text: string, more: { saved?: boolean; replies?: number; edit?: boolean; reveals?: string[]; declared?: boolean; mention?: string } = {}): SemanticNode {
  const own = (key: string, role: string, name: string, state?: SemanticNode['state']): SemanticNode => ({ id: `${id}.${key}`, role, name, ...(state ? { state } : {}) })
  return {
    id: more.declared === false ? `article:${author}` : id,
    role: 'article',
    name: `At 1:00 PM, ${author} wrote, ${text}`,
    text,
    reveals: more.reveals ?? HOVER,
    children: [
      own('author', 'button', author),
      ...(more.mention ? [{ id: `${id}/button:${more.mention}`, role: 'button', name: `@${more.mention}` }] : []),
      own('save', 'button', more.saved ? 'remove from saved' : 'save message'),
      ...(more.replies ? [own('replies', 'button', `${more.replies} replies`)] : []),
      ...(more.edit ? [own('edit', 'button', 'Edit')] : []),
    ],
  }
}

function page(posts: SemanticNode[], extra: SemanticNode[] = []) {
  let current = posts
  const ran: ActionStep[] = []
  const snapshot = (): SemanticState => ({
    revision: 1,
    timestamp: 0,
    context: { url: 'https://chat.test/town', path: '/town', query: {}, title: 'Town' },
    root: {
      id: 'root',
      role: 'document',
      children: [
        { id: 'h', role: 'heading', name: 'Town', state: { level: 1 } },
        { id: 'messages', role: 'feed', name: 'Messages', description: 'Oldest first. Older messages load as you scroll up.', children: current },
        ...extra,
      ],
    },
  })
  const source: ViewSource = {
    snapshot,
    async run(step) {
      ran.push(step)
      return { ok: true }
    },
    exclude: new Set(),
  }
  return { view: projectionView(source), ran, set: (p: SemanticNode[]) => (current = p) }
}

const three = () => [
  post('post.a', 'ann', 'hello there', { replies: 3 }),
  post('post.b', 'bob', 'hi', { saved: true }),
  post('post.c', 'carl', 'my own words', { edit: true, reveals: [...HOVER, 'edit'] }),
]

describe('collections', () => {
  it('shows a feed once as a kind, then one line per item with what it has', async () => {
    const lines = (await page(three()).view.view(true)).split('\n')
    expect(lines).toContain("feed 'Messages': Oldest first. Older messages load as you scroll up. (3 items; id messages)")
    const kind = lines.find((l) => l.startsWith('  each item'))!
    expect(kind).toContain("[click {id}.author] button (its label is on each item)")
    expect(kind).toContain("[click {id}.save] button 'save message'")
    expect(kind).toContain("[click {id}.replies] button '3 replies' (some items)")
    expect(kind).toContain("[click {id}.edit] button 'Edit' (some items)")
    expect(kind).toContain('[hover {id}] shows: Add Reaction, save message, reply, more')
    // the name holds the text: said once
    expect(lines).toContain("  post.a: At 1:00 PM, ann wrote, hello there · .replies")
    expect(lines).toContain("  post.b: At 1:00 PM, bob wrote, hi · .save 'remove from saved'")
    expect(lines).toContain("  post.c: At 1:00 PM, carl wrote, my own words · .edit · hover shows: Add Reaction, save message, reply, more, edit")
  })

  it("keeps the items' controls out of the actions: an item's control with no key of its own is on its line, and runs by its id", async () => {
    const posts = three()
    posts[0] = post('post.a', 'ann', 'hello there', { replies: 3, mention: 'bob' })
    const { view, ran } = page(posts)
    const all = await view.view(true)
    const actions = all.slice(all.indexOf('Actions'))
    expect(actions).not.toContain('post.a')
    expect(all).toContain("  post.a: At 1:00 PM, ann wrote, hello there · .replies · [click post.a/button:bob] button '@bob'")
    const read = await view.read('messages')
    expect(read.ok && read.lines[0]).toContain("[click post.a/button:bob] button '@bob'")
    expect(await view.act({ type: 'click', id: 'post.a/button:bob' })).toEqual({ ok: true })
    expect(ran).toEqual([{ type: 'click', target: 'post.a/button:bob' }])
  })

  it('still acts on an item control by its id', async () => {
    const { view, ran } = page(three())
    await view.view(true)
    expect(await view.act({ type: 'click', id: 'post.b.save' })).toEqual({ ok: true })
    expect(ran).toEqual([{ type: 'click', target: 'post.b.save' }])
  })

  it('shows a list whose items lack declared ids as before', async () => {
    const posts = [post('post.a', 'ann', 'hello', { declared: false }), post('post.b', 'bob', 'hi', { declared: false })]
    const all = await page(posts).view.view(true)
    expect(all).not.toContain('each item')
    expect(all).toContain('[click post.a.save]')
  })

  it('holds back the middle of a long collection, and reading it shows every item from then on', async () => {
    const many = Array.from({ length: 25 }, (_, i) => post(`post.${i}`, `user${i}`, `message ${i}`))
    const { view } = page(many)
    const first = await view.view(true)
    expect(first).toContain('  … 10 more items (read messages shows them all)')
    expect(first).toContain('[read messages] read all 25 items of feed')
    expect(first).toContain('  post.4:')
    expect(first).not.toContain('  post.5:')
    expect(first).toContain('  post.15:')
    const read = await view.read('messages')
    expect(read.ok && read.lines).toHaveLength(25)
    const after = await view.view(true)
    expect(after).toContain('  post.5:')
    expect(after).not.toContain('more items')
  })

  it('tells what changed of an item, per item', async () => {
    const p = page(three())
    await p.view.view()
    p.set([three()[0], post('post.b', 'bob', 'hi'), three()[2]])
    const diff = await p.view.view()
    expect(diff).toContain("~   post.b: At 1:00 PM, bob wrote, hi")
    expect(diff).not.toContain('post.a:')
  })

  it("puts a named toolbar's plain buttons on one line, and writes a long note shared by actions once", async () => {
    const hint = 'Press space bar to start a drag. When dragging you can use the arrow keys to move the item around and escape to cancel.'
    const all = await page(three(), [
      { id: 'toolbar:formatting', role: 'toolbar', name: 'Formatting', children: [
        { id: 'button:bold', role: 'button', name: 'bold' },
        { id: 'button:italic', role: 'button', name: 'italic' },
      ] },
      { id: 'team.a', role: 'link', name: 'Team A', href: '/a', description: hint },
      { id: 'team.b', role: 'link', name: 'Team B', href: '/b', description: hint },
    ]).view.view(true)
    expect(all).toContain("toolbar 'Formatting': [click button:bold] bold · [click button:italic] italic")
    expect(all).not.toContain("[click button:bold] button 'bold'")
    expect(all).toContain(`[click team.a] link 'Team A' → /a; '${hint}'`)
    expect(all).toContain("[click team.b] link 'Team B' → /b; (the same note as [click team.a])")
  })
})

describe('item lines', () => {
  it("shows a family of controls (a message's reactions) once in the kind, and each item's by name", async () => {
    const react = (id: string, emoji: string, who: string, on = false): SemanticNode => ({ id: `${id}.reaction.${emoji}`, role: 'button', name: `${who} reacted with :${emoji}:`, state: { pressed: on } })
    const a = post('post.a', 'ann', 'hello')
    a.children!.push({ id: 'post.a/group:reactions', role: 'group', name: 'reactions', children: [react('post.a', 'plus1', 'bob'), react('post.a', 'heart', 'you', true)] })
    const b = post('post.b', 'bob', 'hi')
    b.children!.push({ id: 'post.b/group:reactions', role: 'group', name: 'reactions', children: [react('post.b', 'plus1', 'carl')] })
    const lines = (await page([a, b, post('post.c', 'carl', 'yo')]).view.view(true)).split('\n')
    const kind = lines.find((l) => l.startsWith('  each item'))!
    expect(kind).toContain('[toggle {id}.reaction.{name} on] button (one for each, named on each item) (some items)')
    expect(kind).not.toContain('plus1')
    expect(lines).toContain("  post.a: At 1:00 PM, ann wrote, hello · .reaction.plus1 'bob reacted with :plus1:' (off) · .reaction.heart 'you reacted with :heart:' (on)")
    expect(lines).toContain("  post.b: At 1:00 PM, bob wrote, hi · .reaction.plus1 'carl reacted with :plus1:' (off)")
  })

  it('names a family member by the rest of its key, dots and all, and leaves out a label that only names it', async () => {
    const who = (id: string, user: string): SemanticNode => ({ id: `${id}.participant.${user}`, role: 'button', name: `${user} profile image` })
    const a = post('post.a', 'ann', 'hello')
    a.children!.push(who('post.a', 'ashley.berry'), who('post.a', 'lois.harper'))
    const b = post('post.b', 'bob', 'hi')
    b.children!.push(who('post.b', 'ashley.berry'))
    const lines = (await page([a, b]).view.view(true)).split('\n')
    expect(lines.find((l) => l.startsWith('  each item'))).toContain('[click {id}.participant.{name}] button (one for each, named on each item)')
    expect(lines).toContain('  post.a: At 1:00 PM, ann wrote, hello · .participant.ashley.berry · .participant.lois.harper')
  })

  it("describes an item with no content of its own (a sidebar's row) by its first control's label, said once", async () => {
    const row = (id: string, name: string, current = false): SemanticNode => ({
      id,
      role: 'listitem',
      reveals: ['Channel options'],
      children: [{ id: `${id}.link`, role: 'link', name, href: `/${id}`, ...(current ? { state: { current: 'page' } } : {}) }],
    })
    const { view } = page([])
    const hint = 'Press space bar to start a drag.'
    const sidebar = page([], [{ id: 'list:channels', role: 'list', name: 'CHANNELS', children: [{ ...row('channel.town', 'town square public channel', true), description: hint }, { ...row('channel.dev', 'dev private channel'), description: hint }] }])
    void view
    const lines = (await sidebar.view.view(true)).split('\n')
    // its id, the projection's own (the app gave the list none): what find_items and read take
    expect(lines).toContain("list 'CHANNELS' (2 items; id list:channels)")
    // the drag hint every row has is the kind's, said once
    expect(lines.find((l) => l.includes('each item') && l.includes('.link'))).toContain("[click {id}.link] link (its label is on each item) · [hover {id}] shows: Channel options · each says 'Press space bar to start a drag.'")
    expect(lines).toContain('  channel.town: town square public channel · .link (current page)')
    expect(lines).toContain('  channel.dev: dev private channel')
  })

  it('says a long note once across the view: a second list with the same item description refers to the first', async () => {
    const hint = 'Press space bar to start a drag. When dragging you can use the arrow keys to move the item around and escape to cancel.'
    const row = (id: string, name: string): SemanticNode => ({ id, role: 'listitem', description: hint, children: [{ id: `${id}.link`, role: 'link', name, href: `/${id}` }] })
    const all = await page([], [
      { id: 'list:a', role: 'list', name: 'CHANNELS', children: [row('channel.a', 'a'), row('channel.b', 'b')] },
      { id: 'list:b', role: 'list', name: 'DIRECT MESSAGES', children: [row('dm.c', 'c'), row('dm.d', 'd')] },
      { id: 'team.x', role: 'link', name: 'Team X', href: '/x', description: hint },
    ]).view.view(true)
    expect(all.split(hint)).toHaveLength(2)
    expect(all).toContain("each says the same as each of list 'CHANNELS'")
    expect(all).toContain("[click team.x] link 'Team X' → /x; (the same note as list 'CHANNELS')")
  })

  it("gives the kind a label only when most items show it: an author who wrote twice of four isn't the kind's", async () => {
    const posts = [post('post.a', 'ann', 'one'), post('post.b', 'ann', 'two'), post('post.c', 'bob', 'three'), post('post.d', 'carl', 'four')]
    const lines = (await page(posts).view.view(true)).split('\n')
    expect(lines.find((l) => l.startsWith('  each item'))).toContain('[click {id}.author] button (its label is on each item)')
    expect(lines).toContain("  post.b: At 1:00 PM, ann wrote, two")
  })

  it('leaves out a repeat of the name inside the text, not only at its start', async () => {
    const a = post('post.a', 'ann', 'vel voluptatem est neque et quae')
    a.text = 'In aut, minus team vel voluptatem est neque et quae'
    const lines = (await page([a, post('post.b', 'bob', 'hi')]).view.view(true)).split('\n')
    expect(lines).toContain('  post.a: At 1:00 PM, ann wrote, vel voluptatem est neque et quae · In aut, minus team')
  })

  it('says what an item\'s text adds to its name, and nothing it repeats', async () => {
    const a = post('post.a', 'ann', 'hello there')
    a.text = ': hello there Last reply 5 hours ago'
    const b = post('post.b', 'bob', 'hi')
    b.text = ': hi'
    const lines = (await page([a, b]).view.view(true)).split('\n')
    expect(lines).toContain("  post.a: At 1:00 PM, ann wrote, hello there · Last reply 5 hours ago")
    expect(lines).toContain("  post.b: At 1:00 PM, bob wrote, hi")
  })
})

describe('the page apart from its data', () => {
  /** A channel of `n` messages, each with a mention, then a thread panel with its reply box; `popup`, a dialog open outside the list. */
  function channel(n: number, popup = false) {
    const ran: ActionStep[] = []
    const source: ViewSource = {
      snapshot: () => ({
        revision: 1,
        timestamp: 0,
        context: { url: 'https://chat.test/town', path: '/town', query: {}, title: 'Town', ...(popup ? { modalId: 'dialog' } : {}) },
        root: {
          id: 'root',
          role: 'document',
          children: [
            { id: 'messages', role: 'feed', name: 'Messages', children: Array.from({ length: n }, (_, i) => post(`post.${i}`, `user${i}`, `message ${i}`, { replies: 2, mention: `user${i + 1}` })) },
            { id: 'thread', role: 'region', name: 'Thread', children: [{ id: 'thread.reply-box', role: 'textbox', name: 'Reply to this thread...' }] },
            ...(popup ? [{ id: 'dialog', role: 'dialog', name: 'Settings', children: [{ id: 'dialog.close', role: 'button', name: 'Close' }] }] : []),
          ],
        },
      }),
      async run(step) {
        ran.push(step)
        return { ok: true }
      },
      exclude: new Set(),
    }
    return projectionView(source)
  }

  it("offers the page's own controls however many items a list holds: the items' controls never count against them", async () => {
    // 100 messages of 4 controls each: more than the page's actions may hold, were the items among them
    const all = await channel(100).view(true)
    const actions = all.slice(all.indexOf('Actions'))
    expect(actions).toContain("[type thread.reply-box] type into textbox 'Reply to this thread...'")
    expect(actions).not.toMatch(/post\.\d+/)
    expect(all).toContain("  post.99: At 1:00 PM, user99 wrote, message 99 · [click post.99/button:user100] button '@user100'")
  })

  it("gives an item's own controls with each match find_items returns", async () => {
    const found = await channel(30).find!({ collection: 'messages', text: 'message 7' })
    expect(found.ok && found.lines).toEqual(["post.7: At 1:00 PM, user7 wrote, message 7 · [click post.7/button:user8] button '@user8'"])
  })

  it('offers no item controls while a popup outside the list is open', async () => {
    const all = await channel(3, true).view(true)
    expect(all).not.toContain('[click post.0/button:user1]')
    expect(all.slice(all.indexOf('Actions'))).toContain('[click dialog.close]')
  })
})

describe('long pages and long items', () => {
  /** A page whose outline reaches its cap inside a list: `before` headings, a feed of `items` messages, then `after` headings. */
  function crowded(before: number, items: number, after: number) {
    const heading = (k: string): SemanticNode => ({ id: `h.${k}`, role: 'heading', name: `Section ${k}`, state: { level: 2 } })
    const source: ViewSource = {
      snapshot: () => ({
        revision: 1,
        timestamp: 0,
        context: { url: 'https://chat.test/town', path: '/town', query: {}, title: 'Town' },
        root: {
          id: 'root',
          role: 'document',
          children: [
            ...Array.from({ length: before }, (_, i) => heading(`a${i}`)),
            { id: 'saved', role: 'feed', name: 'Saved messages', children: Array.from({ length: items }, (_, i) => post(`post.${i}`, `user${i}`, `message ${i}`)) },
            ...Array.from({ length: after }, (_, i) => heading(`b${i}`)),
          ],
        },
      }),
      async run() {
        return { ok: true }
      },
      exclude: new Set(),
    }
    return projectionView(source)
  }

  it("doesn't cut the outline inside a list: the list runs to its end, and the rest of the page is read from there", async () => {
    // 50 headings, then the feed's 17 lines (head, kind, 15 items): the 60-line cap falls inside the feed
    const view = crowded(50, 15, 10)
    const first = await view.view(true)
    expect(first).toContain("feed 'Saved messages' (15 items; id saved)")
    for (let i = 0; i < 15; i++) expect(first).toContain(`  post.${i}: `)
    expect(first).not.toContain('Section b0')
    // what's left is only what follows the list
    expect(first).toContain('[read (page)] read the rest of the page outline (10 more lines)')
    const rest = await view.read(PAGE)
    expect(rest.ok && rest.lines).toEqual(Array.from({ length: 10 }, (_, i) => `heading 'Section b${i}'`))
  })

  it("cuts a long item's line in the middle: what follows its message (saved, where it was posted) is kept", async () => {
    const words = Array.from({ length: 60 }, (_, i) => `word${i}`).join(' ')
    const a = post('post.a', 'ann', words)
    a.name = `At 1:00 PM, ann wrote, ${words}, message is saved`
    a.text = 'In voluptatem, minus team'
    const lines = (await page([a, post('post.b', 'bob', 'hi')]).view.view(true)).split('\n')
    const line = lines.find((l) => l.startsWith('  post.a: '))!
    expect(line).toMatch(/^ {2}post\.a: At 1:00 PM, ann wrote, word0 word1 .*…/)
    expect(line).toMatch(/…word\d+ .*word59, message is saved · In voluptatem, minus team$/)
    expect(line).not.toContain('word30 ')
    expect(line.length - '  post.a: '.length).toBeLessThanOrEqual(ITEM_CONTENT)
  })

  it('finds an item by text its shown line leaves out', async () => {
    const words = Array.from({ length: 60 }, (_, i) => `word${i}`).join(' ')
    const { view } = page([post('post.a', 'ann', words), post('post.b', 'bob', 'hi')])
    const found = await view.find!({ collection: 'messages', text: 'word30 word31' })
    expect(found.ok && found.lines.map((l) => l.split(':')[0].trim())).toEqual(['post.a'])
  })
})

describe('declaredId', () => {
  it("tells an id the app gave from one the projection derived", () => {
    expect(declaredId({ id: 'post.abc', role: 'article' })).toBe(true)
    expect(declaredId({ id: 'channel-view/post.abc', role: 'article' })).toBe(true)
    expect(declaredId({ id: 'article:at-1-pm', role: 'article' })).toBe(false)
    expect(declaredId({ id: 'post.abc/button:reply~2', role: 'button' })).toBe(false)
    expect(declaredId({ id: 'article', role: 'article' })).toBe(false)
  })
})
