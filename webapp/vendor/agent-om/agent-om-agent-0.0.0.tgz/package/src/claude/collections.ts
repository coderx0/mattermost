import type { SemanticNode, SemanticState } from '@agent-om/core'
import { actionCandidates, type ActionCandidate } from '../candidates'
import { contentOf, indexNodes, nameOf, stateOf, type Located } from '../describe'

// Repeated items in Claude's view (guideline 2.6): a list or feed whose items
// each have an id the app gave them, and whose controls have ids relative to
// their item (`post.abc.save`), is shown once as a kind of item and then as one
// line per item. The kind is every control an item can have, by its key
// (`.save`) and what it does; an item's line is its content and what it has of
// the kind: the controls only some items have, a control whose label or state
// differs from the kind's, what hovering over it shows if that differs. Nothing
// is grouped because it looks alike: only ids the app declared are read, so a
// list that doesn't follow the guideline is shown as it was.
//
// The items are the page's data, kept apart from its controls: the page's
// actions are built without them (view.ts), so however many items a list
// holds, none of them crowds out a control of the page. An item's own actions
// are built from the item alone (itemActions) and go on its line: its keyed
// controls by the kind, its other controls (a mention, a link in its text)
// each by the call that takes it, wherever its line is shown (the outline,
// `read`, `find_items`).

/** How an option is called, as the tool call that takes it. */
export function callOf(c: ActionCandidate): string {
  const s = c.step
  if (s.type === 'click') return `click ${s.target}`
  if (s.type === 'hover') return `hover ${s.target}`
  if (s.type === 'toggle') return `toggle ${s.target} ${s.on ? 'on' : 'off'}`
  if (s.type === 'input') return `type ${s.target}`
  if (s.type === 'select') return `select ${s.target} ${JSON.stringify(s.value)}`
  if (s.type === 'submit') return `submit ${s.target}`
  if (s.type === 'read') return `read ${s.target}`
  if (s.type === 'secret') return `fill_secret ${s.target}`
  return s.type
}

/** The containers whose items can form a collection. */
const COLLECTION_ROLES = new Set(['list', 'feed'])
/** The items of a collection. */
const ITEM_ROLES = new Set(['listitem', 'article'])
/** Items shown before the rest are held back: the first and last few. */
export const ITEMS_SHOWN = 20
const ITEMS_HEAD = 5
const ITEMS_TAIL = 10
/** What an item's line shows of its content before it's cut. */
export const ITEM_CONTENT = 200
/** What a cut line keeps of its end: what follows a message (where it was posted, its state) says as much as its start. */
const ITEM_END = 80

/**
 * Whether the app gave a node its id (`data-agentom-id`), from the
 * projection's id format: a derived id's last part is its role, with a slug
 * of its name (`button:save`) and a `~n` for a repeat; a slug never has a dot.
 */
export function declaredId(node: SemanticNode) {
  const last = node.id.split('/').at(-1) ?? node.id
  const derived = /^([a-z]+)(?::[a-z0-9-]*)?(?:~\d+)?$/.exec(last)
  return !(derived && derived[1] === node.role)
}

/** A control of an item, by its key relative to the item. */
export type ItemControl = { key: string; node: SemanticNode }

export type CollectionItem = { node: SemanticNode; controls: ItemControl[] }

/** A key of the kind: how many items have it, and the label most of them show (none when each item's differs: an author's name). */
export type KindKey = { key: string; count: number; label?: string; role: string }

export type Collection = {
  node: SemanticNode
  parents: SemanticNode[]
  items: CollectionItem[]
  /** every key any item has, in the order items show them */
  kind: KindKey[]
  /** what hovering over an item shows, as most items say it */
  hover?: string[]
  /** a description every item has, word for word (a drag hint): the kind's, said once */
  described?: string
}

const labelOf = (node: SemanticNode) => node.name ?? ''
const hoverOf = (node: SemanticNode) => (node.reveals?.length ? node.reveals.join(', ') : '')

/** The most common of some values (the first seen, on a tie). */
function commonest(values: string[]) {
  const counts = new Map<string, number>()
  for (const v of values) counts.set(v, (counts.get(v) ?? 0) + 1)
  let best = values[0]
  for (const [v, n] of counts) if (n > (counts.get(best) ?? 0)) best = v
  return best
}

/** The collections on the page, outside `exclude`: a list or feed with two items or more, every item with a declared id. */
export function collectionsOf(state: SemanticState, exclude: ReadonlySet<string>): Collection[] {
  const out: Collection[] = []
  for (const { node, parents } of indexNodes(state.root).values()) {
    if (!COLLECTION_ROLES.has(node.role)) continue
    if (exclude.has(node.id) || parents.some((p) => exclude.has(p.id))) continue
    // its items: the item roles below it, not inside another item or another collection
    const items: SemanticNode[] = []
    const walk = (n: SemanticNode) => {
      for (const c of n.children ?? []) {
        if (ITEM_ROLES.has(c.role)) items.push(c)
        else if (!COLLECTION_ROLES.has(c.role)) walk(c)
      }
    }
    walk(node)
    if (items.length < 2 || !items.every(declaredId)) continue

    const withControls = items.map((item) => ({ node: item, controls: controlsOf(item) }))
    const keys = new Map<string, { labels: string[]; role: string }>()
    for (const { controls } of withControls) {
      // a family counts once per item; its members' labels are each item's own
      const seen = new Set<string>()
      for (const c of controls) {
        const key = familyOf(c.key)
        const k = keys.get(key) ?? { labels: [], role: c.node.role }
        if (key !== c.key) {
          if (!seen.has(key)) k.labels.push('')
          seen.add(key)
        } else k.labels.push(labelOf(c.node))
        keys.set(key, k)
      }
    }
    const hovers = items.map(hoverOf).filter(Boolean)
    const described = items[0].description && items.every((i) => i.description === items[0].description) ? items[0].description : undefined
    out.push({
      node,
      parents,
      items: withControls,
      kind: [...keys].map(([key, { labels, role }]) => {
        if (key.endsWith('.{name}')) return { key, count: labels.length, role }
        const label = commonest(labels)
        // the kind's label only when most items that have it show it (an author's name is each item's own)
        const shared = labels.length === 1 || labels.filter((l) => l === label).length * 2 > labels.length
        return { key, count: labels.length, role, ...(shared ? { label } : {}) }
      }),
      ...(hovers.length ? { hover: commonest(hovers).split(', ') } : {}),
      ...(described ? { described } : {}),
    })
  }
  return out
}

/** An item's controls with ids relative to it (`<item>.<key>`), in page order. */
function controlsOf(item: SemanticNode): ItemControl[] {
  const prefix = `${item.id}.`
  const out: ItemControl[] = []
  const walk = (n: SemanticNode) => {
    for (const c of n.children ?? []) {
      if (c.id.startsWith(prefix)) out.push({ key: c.id.slice(item.id.length), node: c })
      walk(c)
    }
  }
  walk(item)
  return out
}

/**
 * The kind's key a control belongs to: its own (`.save`), or for a key of two
 * parts or more (`.reaction.plus1`, `.participant.ashley.berry`) its family,
 * the first part (`.reaction.{name}`): one of a set of controls of one kind
 * inside the item, such as its reactions, each named by the rest of its key
 * (a name can have dots of its own).
 */
export const familyOf = (key: string) => {
  const [, first, ...rest] = key.split('.')
  return rest.length ? `.${first}.{name}` : key
}

/** A family member's name: the rest of its key (`ashley.berry` of `.participant.ashley.berry`). */
const memberOf = (key: string) => key.split('.').slice(2).join('.')

/** The collections' items, by id: the page's actions are built without them (they're the page's data). */
export function itemIds(collections: Collection[]) {
  return new Set(collections.flatMap((col) => col.items.map((item) => item.node.id)))
}

/** An item's actions, by item id. */
export type ItemActions = ReadonlyMap<string, ActionCandidate[]>

/**
 * Each item's actions, built from the item alone: its own options, told apart
 * and described within it, with no limit shared with the rest of the page.
 * While a popup is open, only the items inside it have any (only the popup
 * can be used), as the page's actions are.
 */
export function itemActions(state: SemanticState, collections: Collection[], { exclude = new Set(), secrets = false }: { exclude?: ReadonlySet<string>; secrets?: boolean } = {}): Map<string, ActionCandidate[]> {
  const out = new Map<string, ActionCandidate[]>()
  const modal = state.context.modalId
  const index = modal ? indexNodes(state.root) : undefined
  for (const col of collections) {
    for (const { node } of col.items) {
      const loc = index?.get(node.id)
      // the popup holds the item, or is inside it
      const reachable = !modal || !!loc?.parents.some((p) => p.id === modal) || findIn(node, modal)
      out.set(node.id, reachable ? actionCandidates({ ...state, root: node }, exclude, { secrets }) : [])
    }
  }
  return out
}

/** Whether a node holds the node `id` (a popup opened inside an item). */
const findIn = (node: SemanticNode, id: string): boolean => node.id === id || !!node.children?.some((c) => findIn(c, id))

/** Words in a row the name must hold for the text's copy of them to be left out. */
const REPEAT_WORDS = 4

/**
 * What text adds to a name: the text without any run of words the name
 * already holds ("…, ann wrote, hello there" and "In town, hello there · Last
 * reply…" give "In town · Last reply…"); a run shorter than a few words stays.
 */
export function beyondName(name: string, text: string) {
  const words = text.replace(/^[\s:;,.·-]+/, '').split(/\s+/).filter(Boolean)
  // the longest start of the text the name holds, however short ("hi"), then any run of a few words or more
  let start = 0
  while (start < words.length && name.includes(words.slice(0, start + 1).join(' '))) start++
  const kept: string[] = []
  for (let i = start; i < words.length; ) {
    let end = i
    while (end < words.length && name.includes(words.slice(i, end + 1).join(' '))) end++
    if (end - i >= REPEAT_WORDS) i = end
    else kept.push(words[i++])
  }
  return kept.join(' ').replace(/^[\s:;,.·-]+|[\s:;,·-]+$/g, '')
}

/**
 * A line too long to show whole keeps its start and its end, from a word on,
 * and loses its middle: a message's body is what runs long, and what comes
 * after it (whether it's saved, where it was posted) says as much as who
 * wrote it.
 */
function cutMiddle(text: string) {
  if (text.length <= ITEM_CONTENT) return text
  const tail = text.slice(-ITEM_END)
  const end = tail.slice(tail.indexOf(' ') + 1)
  return `${text.slice(0, ITEM_CONTENT - end.length - 1)}…${end}`
}

/**
 * What an item shows, in one line: its name, and what its text adds to it;
 * without a name, its content; with neither (a row that is only its link), its
 * first control's label. Cut in the middle when long, unless `whole`.
 */
function itemContent({ node, controls }: CollectionItem, described?: string, whole = false) {
  const name = node.name ?? ''
  const more = name && node.text ? beyondName(name, node.text) : ''
  // a description every item has is the kind's, not this item's content
  const own = node.description === described ? { ...node, description: undefined } : node
  const text = (name ? (more ? `${name} · ${more}` : name) : contentOf(own, true)) || (controls[0] ? labelOf(controls[0].node) : '')
  return whole ? text : cutMiddle(text)
}

/**
 * An item's line: its id and content, then what it has of the kind that not
 * every item has, a control whose label or state differs from the kind's, and
 * what hovering over it shows if that differs; then, from its `actions`, each
 * control it has that isn't one of the kind's (no key of its own: a mention, a
 * link in its text), by the call that takes it. With `whole`, its content
 * uncut (what find_items matches).
 */
export function itemLine(col: Collection, item: CollectionItem, { whole = false, actions = [] }: { whole?: boolean; actions?: readonly ActionCandidate[] } = {}) {
  const parts: string[] = []
  const all = col.items.length
  const content = itemContent(item, col.described, whole)
  for (const k of col.kind) {
    // a family: each of its members, by its own key and label
    const members = item.controls.filter((x) => familyOf(x.key) === k.key)
    for (const c of members) {
      const label = labelOf(c.node)
      const notes = stateOf(c.node)
      const differs = label !== k.label
      if (k.count < all || differs || notes.length) {
        // a label the item's content already says (its author), or a member's that starts with its name ("ashley.berry
        // profile image"), isn't repeated; one that says more ("bob reacted with :plus1:") is
        const known = content.includes(label) || (c.key !== k.key && label.startsWith(memberOf(c.key)))
        const said = differs && label && !known ? ` '${label}'` : ''
        // every item has it and this one's label is the kind's or already said: nothing to tell (a family's
        // members are always told: which ones an item has is what it says)
        if (k.count === all && !said && !notes.length && c.key === k.key) continue
        parts.push(`${c.key}${said}${notes.length ? ` (${notes.join(', ')})` : ''}`)
      }
    }
  }
  const hover = hoverOf(item.node)
  const kindHover = col.hover?.join(', ') ?? ''
  if (hover !== kindHover) parts.push(hover ? `hover shows: ${hover}` : 'nothing on hover')
  // its other controls: the kind's keys and hovering over it are said above
  const keyed = new Set(item.controls.map((c) => c.node.id))
  for (const a of actions) if (a.nodeId !== item.node.id && !keyed.has(a.nodeId)) parts.push(`[${callOf(a)}] ${a.description}`)
  return `${item.node.id}: ${content}${parts.length ? ` · ${parts.join(' · ')}` : ''}`
}

/** The calls each control of the items takes, by node id (what the kind's line writes with `{id}`). */
export function callsOf(actions: ItemActions) {
  const calls = new Map<string, string[]>()
  for (const list of actions.values()) for (const a of list) calls.set(a.nodeId, [...(calls.get(a.nodeId) ?? []), callOf(a)])
  return calls
}

/** The kind's line: every control an item can have, by its call with `{id}` for the item's id, and what it does. */
export function kindLine(col: Collection, calls: ReadonlyMap<string, string[]>, notes: Map<string, string> = new Map()) {
  const all = col.items.length
  const keys = col.kind.map((k) => {
    // the calls taking this key on the first item that has it, written with {id}
    const item = col.items.find((i) => i.controls.some((c) => familyOf(c.key) === k.key))!
    const control = item.controls.find((c) => familyOf(c.key) === k.key)!
    // a family's calls name the member: `{id}.reaction.{name}`
    const forms = (calls.get(control.node.id) ?? [`click ${control.node.id}`]).map((call) => call.split(control.node.id).join(`{id}${k.key}`))
    const family = k.key.endsWith('.{name}')
    const label = family ? ' (one for each, named on each item)' : k.label === undefined ? ' (its label is on each item)' : k.label ? ` '${k.label}'` : ''
    return `[${forms.join('] or [')}] ${k.role}${label}${k.count < all ? ' (some items)' : ''}`
  })
  const hover = col.hover ? [`[hover {id}] shows: ${col.hover.join(', ')}`] : []
  // a long note said earlier in the view is referred to, not said again
  const first = col.described && notes.get(col.described)
  if (col.described && !first) notes.set(col.described, nameOf(col.node))
  const described = col.described ? [first ? `each says the same as each of ${first}` : `each says '${col.described}'`] : []
  return `  each item ({id} is its id): ${[...keys, ...hover, ...described].join(' · ')}`
}

/** Which items an outline shows: all up to ITEMS_SHOWN, else the first and last few. */
export function shownItems(col: Collection): { items: CollectionItem[]; held: number; at: number } {
  const n = col.items.length
  if (n <= ITEMS_SHOWN) return { items: col.items, held: 0, at: n }
  return { items: [...col.items.slice(0, ITEMS_HEAD), ...col.items.slice(n - ITEMS_TAIL)], held: n - ITEMS_HEAD - ITEMS_TAIL, at: ITEMS_HEAD }
}

/** The collection a node is, or is inside (an item, a control of one). */
export function collectionOf(collections: Collection[], loc: Located) {
  return collections.find((c) => c.node.id === loc.node.id || loc.parents.some((p) => p.id === c.node.id))
}

/** The collection's own line: its name and what it says of itself (how many, which, how to get more), and its id, which find_items and read take. */
export function headLine(col: Collection) {
  const what = col.node.description ?? col.node.text
  return `${nameOf(col.node)}${what ? `: ${what}` : ''} (${col.items.length} items; id ${col.node.id})`
}
