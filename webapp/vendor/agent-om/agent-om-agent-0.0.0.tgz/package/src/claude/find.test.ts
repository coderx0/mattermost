import { describe, expect, it } from 'vitest'
import type { ActionStep } from '@agent-om/actions'
import type { SemanticNode, SemanticState } from '@agent-om/core'
import { FIND_SCROLLS } from './find'
import { ProjectionTools } from './tools'
import { projectionView, type ViewSource } from './view'

// find_items: a collection's items found without the model, scrolling a list
// that renders only a window of its items (as a virtual list does) for more.

/** 200 messages, oldest first; the page renders 20 of them, the newest at first. */
function longFeed(total = 200, shown = 20, by = 10) {
  let from = total - shown
  const ran: ActionStep[] = []
  const message = (i: number): SemanticNode => ({
    id: `post.${i}`,
    role: 'article',
    name: `user${i % 7} wrote, message number ${i}${i === 42 ? ' about the budget' : ''}`,
    children: [
      { id: `post.${i}.author`, role: 'button', name: `user${i % 7}` },
      ...(i % 10 === 0 ? [{ id: `post.${i}.replies`, role: 'button', name: '3 replies' }] : []),
    ],
  })
  const snapshot = (): SemanticState => ({
    revision: 1,
    timestamp: 0,
    context: { url: 'https://chat.test/town', path: '/town', query: {}, title: 'Town' },
    root: {
      id: 'root',
      role: 'document',
      children: [{ id: 'messages', role: 'feed', name: 'Messages', children: Array.from({ length: shown }, (_, k) => message(from + k)) }],
    },
  })
  const source: ViewSource = {
    snapshot,
    async run(step) {
      ran.push(step)
      // the first item brought into view moves the window up, the last down, as far as the list goes
      if (step.type === 'scroll') {
        if (step.target === `post.${from}`) from = Math.max(0, from - by)
        else if (step.target === `post.${from + shown - 1}`) from = Math.min(total - shown, from + by)
      }
      return { ok: true }
    },
    exclude: new Set(),
  }
  const view = projectionView(source)
  return { view, ran, tools: new ProjectionTools({ hooks: view }) }
}

type RunnableTool = { name: string; run(input: unknown): Promise<string> }
const named = (t: ProjectionTools, name: string) => (t.tools as unknown as RunnableTool[]).find((x) => x.name === name)!

describe('find_items', () => {
  it('finds among the items on the page without scrolling', async () => {
    const { view, ran } = longFeed()
    const r = await view.find!({ collection: 'messages', text: 'message number 190' })
    expect(r.ok && r.lines).toEqual(['post.190: user1 wrote, message number 190 · .replies'])
    expect(ran).toEqual([])
  })

  it('scrolls the list for more until it finds one, and gives back only the match', async () => {
    const { view, ran } = longFeed()
    const r = await view.find!({ collection: 'messages', text: 'budget', direction: 'up' })
    expect(r.ok && r.lines).toEqual(['post.42: user0 wrote, message number 42 about the budget'])
    expect(r.ok && r.summary).toMatch(/^Looked through \d+ items, scrolling \d+ times; stopped because found a match\.$/)
    expect(ran.every((s) => s.type === 'scroll')).toBe(true)
    expect(ran.length).toBeGreaterThan(5)
  })

  it('stops where the list goes no further, and says no item matched', async () => {
    const { tools } = longFeed()
    const out = await named(tools, 'find_items').run({ collection: 'messages', text: 'nowhere', direction: 'up' })
    expect(out).toContain('No item matches.')
    expect(out).toContain('Looked through 200 items')
    expect(out).toContain('scrolling up showed no new items')
  })

  it('counts the matches as far as the list goes', async () => {
    const { tools } = longFeed()
    // every tenth message has replies: 0, 10, …, 190
    expect(await named(tools, 'find_items').run({ collection: 'messages', has: '.replies', direction: 'up', count: true })).toMatch(/^20 items match\. Looked through 200 items/)
  })

  it(`stops after ${FIND_SCROLLS} scrolls`, async () => {
    const { view, ran } = longFeed(2000, 20, 5)
    const r = await view.find!({ collection: 'messages', text: 'nowhere', direction: 'up' })
    expect(ran).toHaveLength(FIND_SCROLLS)
    expect(r.ok && r.summary).toContain(`it scrolled ${FIND_SCROLLS} times`)
  })

  it('says when a match has scrolled out of the page', async () => {
    const { view } = longFeed()
    const r = await view.find!({ collection: 'messages', text: 'user3', direction: 'up', limit: 40 })
    expect(r.ok && r.lines.some((l) => l.endsWith('(scrolled out of the page: scroll back to act on it)'))).toBe(true)
  })

  it("refuses what isn't a list of items, and counts as an action", async () => {
    const { tools } = longFeed()
    await expect(named(tools, 'find_items').run({ collection: 'nothing' })).rejects.toThrow('nothing is not a list of items or a table on the page')
    expect(ProjectionTools.isAction({ type: 'tool_use', id: 't', name: 'find_items', input: {} } as never)).toBe(true)
  })
})

describe('find_items in a table', () => {
  /** A table of countries with an Edit button per row (its row header's text says which row) and 60 rows on the page, 50 projected. */
  function countries() {
    const names = ['France', 'Japan', 'India', 'Japanese Islands']
    const snapshot = (): SemanticState => ({
      revision: 1,
      timestamp: 0,
      context: { url: 'https://app.test/countries', path: '/countries', query: {}, title: 'Countries' },
      root: {
        id: 'root',
        role: 'document',
        children: [{
          id: 'table:countries',
          role: 'table',
          name: 'Countries',
          table: { columns: ['Country', 'Visitors'], rows: names.map((n, i) => [n, String((i + 1) * 10)]), totalRows: 60 },
          children: names.map((n) => ({ id: `country.${n.toLowerCase().replace(/ /g, '-')}.edit`, role: 'button', name: 'Edit', row: n })),
        }],
      },
    })
    const ran: ActionStep[] = []
    const view = projectionView({ snapshot, run: async (s) => (ran.push(s), { ok: true }), exclude: new Set() })
    return { view, ran, tools: new ProjectionTools({ hooks: view }) }
  }

  it("finds a table's rows by their text, with the controls that act on each", async () => {
    const { tools, ran } = countries()
    const out = await named(tools, 'find_items').run({ collection: 'table:countries', text: 'japan', limit: 5 })
    expect(out.split('\n')).toEqual([
      "row 2: Country: Japan · Visitors: 20 · [click country.japan.edit] button 'Edit'",
      "row 4: Country: Japanese Islands · Visitors: 40 · [click country.japanese-islands.edit] button 'Edit'",
      'Looked through 4 rows; the table has 60 rows on the page and the first 4 were searched.',
    ])
    expect(ran).toEqual([])
  })

  it('counts the rows that match, and says a table is not scrolled', async () => {
    const { tools } = countries()
    expect(await named(tools, 'find_items').run({ collection: 'table:countries', text: 'a', count: true, direction: 'down' })).toBe(
      "4 items match. Looked through 4 rows; the table has 60 rows on the page and the first 4 were searched; a table is searched as it is on the page: it isn't scrolled (use its own paging for more).",
    )
  })

  it("refuses has on a table: it applies to a list's items", async () => {
    const { tools } = countries()
    await expect(named(tools, 'find_items').run({ collection: 'table:countries', has: '.edit' })).rejects.toThrow("has applies to a list's items, not to a table's rows")
  })
})
