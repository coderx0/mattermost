import type { ActionStep } from '@agent-om/actions'
import { ACTIONABLE_ROLES, type SemanticNode, type SemanticState } from '@agent-om/core'
import { indexNodes, nameOf } from '../describe'
import { rowLine } from '../reveal'
import { collectionsOf, familyOf, itemLine, type Collection, type CollectionItem } from './collections'

// Finding a collection's items without the model (guideline 2.6): the items
// on the page are matched by plain rules; with a direction, the collection is
// scrolled to render more (a long list, one that loads more as it scrolls, one
// that renders only what's in view) and matched again, until enough are found,
// the list shows nothing new, or a cap. Only the matches go back to the model:
// the items that don't match never enter its conversation. Nothing is guessed:
// a match is text the item's line holds, or a control it has.
//
// A table is searched too: its rows, as the projection holds them (the rows
// on the page, up to its row cap), each read as "Header: cell · …", with the
// controls the projection says act on that row (a control's `row`). A table
// isn't scrolled: its rows past the cap, or on another page of it, are said
// to be there, not searched.

export type FindQuery = {
  /** the collection's id, as read_page shows it */
  collection: string
  /** the item's line holds this text (ignoring case) */
  text?: string
  /** the item has this control, by its key (`.replies`, or `replies`) */
  has?: string
  /** scroll the list towards its start ("up") or its end ("down") for more items */
  direction?: 'up' | 'down'
  /** only how many items match (the list is searched as far as it goes) */
  count?: boolean
  /** how many matches to find before stopping (default 1) */
  limit?: number
}

export type FindResult =
  | {
      ok: true
      /** the matching items' lines, in the order found, each saying whether it's on the page now */
      lines: string[]
      /** how many items were looked through, how many scrolls, why it stopped */
      summary: string
      count: number
    }
  | { ok: false; reason: string; message: string }

/** Scrolls one search takes at most, and items it looks through. */
export const FIND_SCROLLS = 20
export const FIND_ITEMS = 1000

export const NOT_A_COLLECTION = 'not-a-collection'

type Source = {
  snapshot(): SemanticState | Promise<SemanticState>
  run(step: ActionStep): Promise<{ ok: true } | { ok: false; reason: string; message: string }>
  exclude: ReadonlySet<string>
}

const keyOf = (key: string) => (key.startsWith('.') ? key : `.${key}`)

/** Whether an item matches: its line holds the text, and it has the control. */
function matches(item: CollectionItem, line: string, q: FindQuery) {
  if (q.text && !line.toLowerCase().includes(q.text.toLowerCase())) return false
  if (q.has) {
    const want = keyOf(q.has)
    if (!item.controls.some((c) => c.key === want || familyOf(c.key) === want || familyOf(c.key) === `${want}.{name}`)) return false
  }
  return true
}

const TOGGLES = new Set(['checkbox', 'switch', 'menuitemcheckbox'])

/** How a control in a row is acted on, as the tool call that takes it. */
function callFor(n: SemanticNode) {
  const on = n.state?.checked ?? n.state?.pressed
  if (TOGGLES.has(n.role) || n.state?.pressed !== undefined) return `[toggle ${n.id} ${on === true ? 'off' : 'on'}] ${nameOf(n)}`
  return `[click ${n.id}] ${nameOf(n)}`
}

/** A table's rows that match, with the controls that act on each. */
function findRows(table: SemanticNode, q: FindQuery): FindResult {
  const { columns, rows, totalRows } = table.table!
  // the controls the projection ties to a row, by the row's header text
  const controls: SemanticNode[] = []
  const walk = (n: SemanticNode) => n.children?.forEach((c) => (ACTIONABLE_ROLES.has(c.role) && c.row ? controls.push(c) : walk(c)))
  walk(table)
  const want = q.count ? Infinity : Math.max(1, q.limit ?? 1)
  const found: string[] = []
  let count = 0
  rows.forEach((cells, i) => {
    const line = rowLine(columns, cells)
    if (q.text && !line.toLowerCase().includes(q.text.toLowerCase())) return
    count++
    if (found.length >= want) return
    const own = controls.filter((c) => cells.includes(c.row!))
    found.push(`row ${i + 1}: ${line}${own.length ? ` · ${own.map(callFor).join(' · ')}` : ''}`)
  })
  const held = totalRows > rows.length ? `; the table has ${totalRows} rows on the page and the first ${rows.length} were searched` : ''
  const other = q.direction ? '; a table is searched as it is on the page: it isn\'t scrolled (use its own paging for more)' : ''
  return { ok: true, lines: q.count ? [] : found, count, summary: `Looked through ${rows.length} rows${held}${other}.` }
}

export async function findItems(q: FindQuery, source: Source): Promise<FindResult> {
  const collectionIn = (state: SemanticState) => collectionsOf(state, source.exclude).find((c) => c.node.id === q.collection)
  const first = await source.snapshot()
  let col = collectionIn(first)
  if (!col) {
    const table = indexNodes(first.root).get(q.collection)?.node
    if (table?.table && !q.has) return findRows(table, q)
    const message = table?.table ? `has applies to a list's items, not to a table's rows` : `${q.collection} is not a list of items or a table on the page`
    return { ok: false, reason: NOT_A_COLLECTION, message }
  }

  const want = q.count ? Infinity : Math.max(1, q.limit ?? 1)
  /** every item looked through, by id: its line, and whether it matched */
  const seen = new Map<string, { line: string; match: boolean }>()
  const found: string[] = []
  const take = (c: Collection) => {
    let added = 0
    for (const item of c.items) {
      if (seen.has(item.node.id)) continue
      const line = itemLine(c, item)
      // matched on the whole line: the text a long one's cut leaves out is still the item's
      const match = matches(item, itemLine(c, item, true), q)
      seen.set(item.node.id, { line, match })
      if (match) found.push(item.node.id)
      added++
    }
    return added
  }
  take(col)

  let scrolls = 0
  let stopped = q.direction ? '' : 'the items on the page were searched (give a direction to scroll for more)'
  while (!stopped) {
    if (found.length >= want) stopped = `found ${found.length === 1 ? 'a match' : `${found.length} matches`}`
    else if (scrolls >= FIND_SCROLLS) stopped = `it scrolled ${FIND_SCROLLS} times, the most one search does`
    else if (seen.size >= FIND_ITEMS) stopped = `it looked through ${FIND_ITEMS} items, the most one search does`
    if (stopped) break
    // the item at the list's edge brought into view: the list moves that way, rendering or loading more
    const edge = q.direction === 'up' ? col.items[0] : col.items.at(-1)
    if (!edge) {
      stopped = 'the list has no items'
      break
    }
    const r = await source.run({ type: 'scroll', target: edge.node.id })
    scrolls++
    if (!r.ok) {
      stopped = `the list couldn't be scrolled (${r.reason})`
      break
    }
    const next = collectionIn(await source.snapshot())
    if (!next) {
      stopped = 'the list is no longer on the page'
      break
    }
    col = next
    if (!take(col)) stopped = `scrolling ${q.direction} showed no new items: the list goes no further that way`
  }

  const onPage = new Set(col.items.map((i) => i.node.id))
  const lines = found
    .slice(0, q.count ? 0 : want)
    .map((id) => `${seen.get(id)!.line}${onPage.has(id) ? '' : ' (scrolled out of the page: scroll back to act on it)'}`)
  const summary = `Looked through ${seen.size} items${scrolls ? `, scrolling ${scrolls} time${scrolls > 1 ? 's' : ''}` : ''}; stopped because ${stopped}.`
  return { ok: true, lines, summary, count: found.length }
}
