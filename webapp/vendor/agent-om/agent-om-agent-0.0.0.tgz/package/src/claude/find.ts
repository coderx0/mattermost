import type { ActionStep } from '@agent-om/actions'
import type { SemanticState } from '@agent-om/core'
import { collectionsOf, familyOf, itemLine, type Collection, type CollectionItem } from './collections'

// Finding a collection's items without the model (guideline 2.6): the items
// on the page are matched by plain rules; with a direction, the collection is
// scrolled to render more (a long list, one that loads more as it scrolls, one
// that renders only what's in view) and matched again, until enough are found,
// the list shows nothing new, or a cap. Only the matches go back to the model:
// the items that don't match never enter its conversation. Nothing is guessed:
// a match is text the item's line holds, or a control it has.

export type FindQuery = {
  /** the collection's id, as read_page shows it */
  collection: string
  /** the item's line holds this text (ignoring case) */
  text?: string
  /** the item has this control, by its key (`.replies`, or `replies`) */
  has?: string
  /** scroll the list towards its start ("up") or its end ("down") for more items */
  direction?: 'up' | 'down'
  /** only how many items match (the list is searched as far as it goes) */
  count?: boolean
  /** how many matches to find before stopping (default 1) */
  limit?: number
}

export type FindResult =
  | {
      ok: true
      /** the matching items' lines, in the order found, each saying whether it's on the page now */
      lines: string[]
      /** how many items were looked through, how many scrolls, why it stopped */
      summary: string
      count: number
    }
  | { ok: false; reason: string; message: string }

/** Scrolls one search takes at most, and items it looks through. */
export const FIND_SCROLLS = 20
export const FIND_ITEMS = 1000

export const NOT_A_COLLECTION = 'not-a-collection'

type Source = {
  snapshot(): SemanticState | Promise<SemanticState>
  run(step: ActionStep): Promise<{ ok: true } | { ok: false; reason: string; message: string }>
  exclude: ReadonlySet<string>
}

const keyOf = (key: string) => (key.startsWith('.') ? key : `.${key}`)

/** Whether an item matches: its line holds the text, and it has the control. */
function matches(item: CollectionItem, line: string, q: FindQuery) {
  if (q.text && !line.toLowerCase().includes(q.text.toLowerCase())) return false
  if (q.has) {
    const want = keyOf(q.has)
    if (!item.controls.some((c) => c.key === want || familyOf(c.key) === want || familyOf(c.key) === `${want}.{name}`)) return false
  }
  return true
}

export async function findItems(q: FindQuery, source: Source): Promise<FindResult> {
  const collectionIn = (state: SemanticState) => collectionsOf(state, source.exclude).find((c) => c.node.id === q.collection)
  let col = collectionIn(await source.snapshot())
  if (!col) return { ok: false, reason: NOT_A_COLLECTION, message: `${q.collection} is not a list of items on the page` }

  const want = q.count ? Infinity : Math.max(1, q.limit ?? 1)
  /** every item looked through, by id: its line, and whether it matched */
  const seen = new Map<string, { line: string; match: boolean }>()
  const found: string[] = []
  const take = (c: Collection) => {
    let added = 0
    for (const item of c.items) {
      if (seen.has(item.node.id)) continue
      const line = itemLine(c, item)
      const match = matches(item, line, q)
      seen.set(item.node.id, { line, match })
      if (match) found.push(item.node.id)
      added++
    }
    return added
  }
  take(col)

  let scrolls = 0
  let stopped = q.direction ? '' : 'the items on the page were searched (give a direction to scroll for more)'
  while (!stopped) {
    if (found.length >= want) stopped = `found ${found.length === 1 ? 'a match' : `${found.length} matches`}`
    else if (scrolls >= FIND_SCROLLS) stopped = `it scrolled ${FIND_SCROLLS} times, the most one search does`
    else if (seen.size >= FIND_ITEMS) stopped = `it looked through ${FIND_ITEMS} items, the most one search does`
    if (stopped) break
    // the item at the list's edge brought into view: the list moves that way, rendering or loading more
    const edge = q.direction === 'up' ? col.items[0] : col.items.at(-1)
    if (!edge) {
      stopped = 'the list has no items'
      break
    }
    const r = await source.run({ type: 'scroll', target: edge.node.id })
    scrolls++
    if (!r.ok) {
      stopped = `the list couldn't be scrolled (${r.reason})`
      break
    }
    const next = collectionIn(await source.snapshot())
    if (!next) {
      stopped = 'the list is no longer on the page'
      break
    }
    col = next
    if (!take(col)) stopped = `scrolling ${q.direction} showed no new items: the list goes no further that way`
  }

  const onPage = new Set(col.items.map((i) => i.node.id))
  const lines = found
    .slice(0, q.count ? 0 : want)
    .map((id) => `${seen.get(id)!.line}${onPage.has(id) ? '' : ' (scrolled out of the page: scroll back to act on it)'}`)
  const summary = `Looked through ${seen.size} items${scrolls ? `, scrolling ${scrolls} time${scrolls > 1 ? 's' : ''}` : ''}; stopped because ${stopped}.`
  return { ok: true, lines, summary, count: found.length }
}
