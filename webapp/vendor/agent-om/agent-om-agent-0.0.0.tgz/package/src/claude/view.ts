import type { SemanticState } from '@agent-om/core'
import type { ActionStep } from '@agent-om/actions'
import { actionCandidates, type ActionCandidate } from '../candidates'
import { indexNodes, messagesOf } from '../describe'
import type { AgentEvent } from '../loop'
import { confirmationReason } from '../policy'
import { PAGE, PAGE_LINES, PAGE_LINES_READ, readCandidates, revealed, type Reading } from '../reveal'
import { holdsSecret, isSecretField, type AskSecret } from '../secret'
import { modelState, outlineEntries } from '../state'

// Claude's view of a page and its steps, on any projection: the view a
// standard Claude agent reads, built by our agent's functions unchanged, so it
// decides on what our agent decides on; only our agent's history is left out
// (Claude's conversation is its history). What the run has read, and the
// messages showing when it began, are kept as our agent keeps them (loop.ts).
// It needs only a snapshot and a way to run a step, so it runs in a page (the
// dashboard's Claude mode, the benchmark's projection setup) or in Node over a
// page that loads whole new documents (eval/apps), keeping what it has shown
// across them.
//
// A host that asks its user (the dashboard) adds the policy and the steps'
// progress: a risky target is confirmed first, as our agent's loop does, from
// the projection at that moment and never from the model; each step and its
// result are told in our agent's words. Without them (the benchmark), a step
// runs as it comes.
//
// A step's target that isn't on the page waits for the page to settle first
// (a turn's later calls meet the page its earlier ones changed). Still missing
// behind a popup opened since the view last shown, the step isn't taken: the
// model hears that only the popup can be used, and no step is told.
//
// A secret is never typed by the model: typing into a secret field is
// refused. With a host that asks its user (`askSecret`), the view offers
// `fill_secret` on each secret field, and the field gets what the user enters
// (secret.ts); the model hears only whether it's filled.
//
// On a new page the view is the whole page; on the same page, only what
// changed since the view last shown (new, gone and changed lines), unless
// that would be longer or the whole page is asked for. What was shown is
// forgotten when the conversation's old tool results are cleared (the
// harness says so), so the next view is whole again.
//
// With a host that can load a page by its path (`open`: from Node, where a
// load doesn't end the loop), the view can open one, as typing its address:
// the page loads anew, so the next view is whole.

/** A step on the projection, by node id. */
export type ProjectionStep =
  | { type: 'click'; id: string }
  /** move the pointer onto it: what the page shows only on hover shows */
  | { type: 'hover'; id: string }
  | { type: 'toggle'; id: string; on: boolean }
  | { type: 'type'; id: string; text: string }
  | { type: 'select'; id: string; value: string }
  | { type: 'submit'; id: string }
  /** fill a secret field with what the user enters (the host's `askSecret`) */
  | { type: 'fill_secret'; id: string }

export type ActResult = { ok: true } | { ok: false; reason: string; message: string }
export type ReadResult = { ok: true; lines: string[] } | { ok: false }

/** The view and steps: in the dashboard's page (Claude mode; the benchmark's projection.ts), or in Node over any app's page (eval/apps). */
export type ProjectionHooks = {
  /** the page as Claude reads it: whole on a new page or when asked (`full`), else what changed since the last view */
  view(full?: boolean): Promise<string>
  /** forget the view last shown (the model's copy of it was cleared): the next is whole */
  forget(): void | Promise<void>
  /** run one step through the executor */
  act(step: ProjectionStep): Promise<ActResult>
  /** what element `id` (or the page outline, "(page)") holds back; from now on the view carries it too */
  read(id: string): Promise<ReadResult>
  /** open the site's page at a path, as typing its address (a host that can: `open` in ViewSource) */
  open?(path: string): Promise<ActResult>
}

/** How an option is called, as the tool call that takes it. */
function callOf(c: ActionCandidate): string {
  const s = c.step
  if (s.type === 'click') return `click ${s.target}`
  if (s.type === 'hover') return `hover ${s.target}`
  if (s.type === 'toggle') return `toggle ${s.target} ${s.on ? 'on' : 'off'}`
  if (s.type === 'input') return `type ${s.target}`
  if (s.type === 'select') return `select ${s.target} ${JSON.stringify(s.value)}`
  if (s.type === 'submit') return `submit ${s.target}`
  if (s.type === 'read') return `read ${s.target}`
  if (s.type === 'secret') return `fill_secret ${s.target}`
  return s.type
}

/** What a view showed, by what each line is about: outline lines by node, reads by element, actions by tool call; and the popup open then. */
type Shown = { header: string; path: string; outline: Map<string, string>; reading: Map<string, Reading>; actions: Map<string, string>; popup?: string }

const LEGEND = 'Lines start with + (new), - (gone) or ~ (changed, shown as it is now).'

function whole(v: Shown): string {
  return [
    v.header,
    '',
    'Outline:',
    ...v.outline.values(),
    ...(v.reading.size ? ['', 'Read:', ...[...v.reading.values()].flatMap((r) => [`${r.of}:`, ...r.lines.map((l) => `  ${l}`)])] : []),
    '',
    'Actions (the tool call that takes each, then what it does):',
    ...[...v.actions].map(([call, d]) => `${call} ${d}`),
  ].join('\n')
}

/** The lines of a section that are new, gone or changed, in the page's order (gone ones last). */
function changes<T>(was: Map<string, T>, now: Map<string, T>, same: (a: T, b: T) => boolean, line: (key: string, v: T) => string[]): string[] {
  const out: string[] = []
  for (const [k, v] of now) {
    const old = was.get(k)
    if (old === undefined) out.push(...prefixed('+', line(k, v)))
    else if (!same(old, v)) out.push(...prefixed('~', line(k, v)))
  }
  for (const [k, v] of was) if (!now.has(k)) out.push(...prefixed('-', line(k, v).slice(0, 1)))
  return out
}
const prefixed = (mark: string, lines: string[]) => lines.map((l, i) => (i ? `  ${l}` : `${mark} ${l}`))

/** What changed from the view last shown to this one; undefined when nothing did. */
function changed(was: Shown, now: Shown): string | undefined {
  const outline = changes(was.outline, now.outline, (a, b) => a === b, (_, l) => [l])
  const reading = changes(was.reading, now.reading, (a, b) => a.of === b.of && a.lines.join('\n') === b.lines.join('\n'), (_, r) => [`${r.of}:`, ...r.lines])
  const actions = changes(was.actions, now.actions, (a, b) => a === b, (call, d) => [`${call} ${d}`])
  if (!outline.length && !reading.length && !actions.length) return undefined
  return [
    `${now.header}: the same page as your last read_page; only what changed since then (read_page with full: true shows the whole page).`,
    LEGEND,
    ...(outline.length ? ['', 'Outline:', ...outline] : []),
    ...(reading.length ? ['', 'Read:', ...reading] : []),
    ...(actions.length ? ['', 'Actions:', ...actions] : []),
  ].join('\n')
}

export type ViewSource = {
  /** the page's projection for a view (settled: the host's rule, or the harness's after each step) */
  snapshot(): SemanticState | Promise<SemanticState>
  /** run one step through our executor */
  run(step: ActionStep): Promise<ActResult>
  /** the host's own UI, never read or acted on */
  exclude: ReadonlySet<string>
  /** the projection right now, for the policy and the steps' words (default: `snapshot`) */
  now?: () => SemanticState | Promise<SemanticState>
  /** a risky target needs this to go ahead; declined, the step isn't taken (its result: `declined`) */
  confirm?: (prompt: string) => Promise<boolean>
  /** each step taken and its result, and each read, in our agent's words */
  onEvent?: (e: AgentEvent) => void
  /** asks the user for a secret field's secret; with it, the view offers `fill_secret` */
  askSecret?: AskSecret
  /** load the site's page at a path, a whole page load (AgentPage's `open`); with it, the view can open pages */
  open?: (path: string) => Promise<ActResult>
}

/** A step's result when the user declined it (`confirm`, or entering a secret). */
export const DECLINED = 'declined'
/** A `type` into a secret field: refused, a secret is never typed by the model. */
export const SECRET_FIELD = 'secret-field'
/** A `fill_secret` on a field that isn't a secret field: refused. */
export const NOT_SECRET = 'not-secret'
/** A `fill_secret` after which the field holds nothing. */
export const NOT_FILLED = 'not-filled'
/** A step not taken: its target is outside a popup that opened since the view last shown, and only the popup can be used. */
export const BEHIND_POPUP = 'behind-popup'

/**
 * A step in our agent's words: `option`, as offered (the confirmation's
 * prompt); `done`, as the agent's panel lists it ("clicked link 'Campaigns'"),
 * a secret's text left out (`fromUser`: a secret the user entered).
 */
function said(state: SemanticState, step: ActionStep, id: string, exclude: ReadonlySet<string>, fromUser = false) {
  const node = indexNodes(state.root).get(id)?.node
  const type = fromUser ? 'secret' : step.type
  const options = actionCandidates(state, exclude, { secrets: fromUser }).filter((c) => c.nodeId === id && c.step.type === type)
  const option = step.type === 'select' ? (options.find((c) => 'value' in c.step && c.step.value === step.value) ?? options[0]) : options[0]
  const what = option?.what ?? (node ? `${node.role} '${node.name ?? id}'` : id)
  const done =
    fromUser ? `filled ${what} with a secret the user entered`
    : step.type === 'input' ? (isSecretField(node) ? `typed a secret into ${what}` : `typed ${JSON.stringify(step.value)} into ${what}`)
    : step.type === 'toggle' ? `turned ${step.on ? 'on' : 'off'} ${what}`
    : step.type === 'select' ? `chose '${step.value}' in ${what}`
    : step.type === 'submit' ? `submitted ${what}`
    : step.type === 'hover' ? `hovered over ${what}`
    : `clicked ${what}`
  return { node, what, option: option?.description ?? what, done }
}

export function projectionView({ snapshot, run, exclude, now = snapshot, confirm, onEvent, askSecret, open }: ViewSource): ProjectionHooks {
  /** messages showing when the run began, dropped once they change or go (as our agent does) */
  let earlier: Map<string, string> | undefined
  /** what the run has read: its content goes with every view while it's on the page */
  const expanded = new Set<string>()
  /** the view as last shown to the model, with what it has read since */
  let shown: Shown | undefined
  /** the steps taken, numbered for onEvent */
  let steps = 0

  const look = async () => {
    const state = await snapshot()
    const messages = messagesOf(state.root)
    if (!earlier) earlier = messages
    else for (const [id, text] of earlier) if (messages.get(id) !== text) earlier.delete(id)
    const present = indexNodes(state.root)
    for (const id of expanded) if (id !== PAGE && !present.has(id)) expanded.delete(id)
    return state
  }

  const current = async (): Promise<Shown> => {
    const state = await look()
    const view = { exclude, earlier, expanded }
    const m = modelState('', state, [], view)
    const entries = outlineEntries(state, exclude, earlier)
    const options = [...actionCandidates(state, exclude, { secrets: !!askSecret }), ...readCandidates(state, exclude, expanded, entries.length)]
    const reading = new Map<string, Reading>()
    for (const id of expanded) {
      const r = id === PAGE ? undefined : revealed(state, new Set([id]))[0]
      if (r) reading.set(id, r)
    }
    return {
      header: `Page: ${m.title} (${m.path})${m.screen ? `, screen ${m.screen}` : ''}`,
      path: m.path,
      outline: new Map(entries.slice(0, m.page.length).map((e) => [e.id, e.line])),
      reading,
      actions: new Map(options.map((c) => [`[${callOf(c)}]`, c.description])),
      ...(state.context.modalId ? { popup: state.context.modalId } : {}),
    }
  }

  /** A secret field filled with what the user enters: checked first, then asked for, typed, and checked again once the page settles. */
  async function fillSecret(id: string): Promise<ActResult> {
    const state = await now()
    const node = indexNodes(state.root).get(id)?.node
    if (!node) return { ok: false, reason: 'not-found', message: `${id} is not on the page` }
    if (!askSecret || !isSecretField(node)) return { ok: false, reason: NOT_SECRET, message: `${id} is not a secret field` }
    const words = said(state, { type: 'input', target: id, value: '' }, id, exclude, true)
    const risk = confirm && confirmationReason(node)
    if (risk && !(await confirm(`${words.option}: ${risk}. Go ahead?`))) return { ok: false, reason: DECLINED, message: 'The user declined the step.' }
    const entered = await askSecret(words.what)
    if (entered === null) return { ok: false, reason: DECLINED, message: 'The user declined to enter the secret.' }
    const n = ++steps
    onEvent?.({ type: 'acting', step: n, description: words.done })
    let r = await run({ type: 'input', target: id, value: entered })
    if (r.ok && !holdsSecret(await snapshot(), id)) r = { ok: false, reason: NOT_FILLED, message: `${id} holds nothing after filling it` }
    onEvent?.({ type: 'result', step: n, ok: r.ok, detail: r.ok ? '' : r.reason })
    return r
  }

  return {
    async view(full = false) {
      const now = await current()
      const was = shown
      shown = now
      if (full || !was || was.path !== now.path) return whole(now)
      const diff = changed(was, now)
      if (diff === undefined) return `${now.header}: nothing changed since your last read_page.`
      const all = whole(now)
      return diff.length < all.length ? diff : all
    },

    forget() {
      shown = undefined
    },

    async act(step) {
      // The model may write several calls from one view; a later one meets the page an earlier one
      // changed. A target not on the page may be on its way (a menu still closing, a list loading):
      // wait for the page to settle before looking again.
      let state = await now()
      if (!indexNodes(state.root).has(step.id)) state = await snapshot()
      // Still not there, behind a popup the model hasn't seen (an earlier action opened it): only the
      // popup can be used until it closes, so the step isn't taken; the model reads the popup first.
      const popup = state.context.modalId
      if (popup && popup !== shown?.popup && !indexNodes(state.root).has(step.id))
        return { ok: false, reason: BEHIND_POPUP, message: `${step.id} is outside a popup that opened since the last view` }
      if (step.type === 'fill_secret') return fillSecret(step.id)
      const s: ActionStep =
        step.type === 'type' ? { type: 'input', target: step.id, value: step.text }
        : step.type === 'toggle' ? { type: 'toggle', target: step.id, on: step.on }
        : step.type === 'select' ? { type: 'select', target: step.id, value: step.value }
        : { type: step.type, target: step.id }
      if (step.type === 'type' && isSecretField(indexNodes(state.root).get(step.id)?.node))
        return { ok: false, reason: SECRET_FIELD, message: `${step.id} is a secret field` }
      if (!confirm && !onEvent) return run(s)
      const words = said(state, s, step.id, exclude)
      // hovering only shows things: nothing to confirm
      const risk = confirm && s.type !== 'hover' && words.node && confirmationReason(words.node)
      if (risk && !(await confirm(`${words.option}: ${risk}. Go ahead?`))) return { ok: false, reason: DECLINED, message: 'The user declined the step.' }
      const n = ++steps
      onEvent?.({ type: 'acting', step: n, description: words.done })
      const r = await run(s)
      // the panel lists a step once; a failure says why, as our agent's do
      onEvent?.({ type: 'result', step: n, ok: r.ok, detail: r.ok ? '' : r.reason })
      return r
    },

    async read(id) {
      onEvent?.({ type: 'reading', step: steps + 1, description: `reading ${id}` })
      const state = await look()
      if (id === PAGE) {
        const entries = outlineEntries(state, exclude, earlier)
        if (entries.length <= PAGE_LINES) return { ok: false }
        expanded.add(PAGE)
        const more = entries.slice(PAGE_LINES, PAGE_LINES_READ)
        // the model has these lines now: the next view doesn't send them as new
        if (shown) for (const e of more) shown.outline.set(e.id, e.line)
        return { ok: true, lines: more.map((e) => e.line) }
      }
      const reading = revealed(state, new Set([id]))[0]
      if (!reading) return { ok: false }
      expanded.add(id)
      shown?.reading.set(id, reading)
      return { ok: true, lines: reading.lines }
    },

    ...(open
      ? {
          async open(path: string): Promise<ActResult> {
            const n = ++steps
            onEvent?.({ type: 'acting', step: n, description: `opened ${path}` })
            const r = await open(path)
            // the page loaded anew, even at the same path: the next view is whole
            shown = undefined
            onEvent?.({ type: 'result', step: n, ok: r.ok, detail: r.ok ? '' : r.reason })
            return r
          },
        }
      : {}),
  }
}
