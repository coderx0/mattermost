import type { SemanticState } from '@agent-om/core'
import type { ActionStep } from '@agent-om/actions'
import { actionCandidates, type ActionCandidate } from '../candidates'
import { indexNodes, messagesOf, nameOf } from '../describe'
import type { AgentEvent } from '../loop'
import { confirmationReason } from '../policy'
import { PAGE, PAGE_LINES, PAGE_LINES_READ, readCandidates, revealed, type Reading } from '../reveal'
import { holdsSecret, isSecretField, type AskSecret } from '../secret'
import { modelState, outlineEntries } from '../state'
import { collapsedIds, collectionOf, collectionsOf, headLine, itemLine, kindLine, shownItems, type Collection } from './collections'
import { findItems, type FindQuery, type FindResult } from './find'

// Claude's view of a page and its steps, on any projection: the view a
// standard Claude agent reads, built by our agent's functions unchanged, so it
// decides on what our agent decides on; only our agent's history is left out
// (Claude's conversation is its history). What the run has read, and the
// messages showing when it began, are kept as our agent keeps them (loop.ts).
// It needs only a snapshot and a way to run a step, so it runs in a page (the
// dashboard's Claude mode, the benchmark's projection setup) or in Node over a
// page that loads whole new documents (eval/apps), keeping what it has shown
// across them.
//
// A host that asks its user (the dashboard) adds the policy and the steps'
// progress: a risky target is confirmed first, as our agent's loop does, from
// the projection at that moment and never from the model; each step and its
// result are told in our agent's words. Without them (the benchmark), a step
// runs as it comes.
//
// A step's target that isn't on the page waits for the page to settle first
// (a turn's later calls meet the page its earlier ones changed). Still missing
// behind a popup opened since the view last shown, the step isn't taken: the
// model hears that only the popup can be used, and no step is told.
//
// A secret is never typed by the model: typing into a secret field is
// refused. With a host that asks its user (`askSecret`), the view offers
// `fill_secret` on each secret field, and the field gets what the user enters
// (secret.ts); the model hears only whether it's filled.
//
// On a new page the view is the whole page; on the same page, only what
// changed since the view last shown (new, gone and changed lines), unless
// that would be longer or the whole page is asked for. What was shown is
// forgotten when the conversation's old tool results are cleared (the
// harness says so), so the next view is whole again.
//
// With a host that can load a page by its path (`open`: from Node, where a
// load doesn't end the loop), the view can open one, as typing its address:
// the page loads anew, so the next view is whole.

/** A step on the projection, by node id. */
export type ProjectionStep =
  | { type: 'click'; id: string }
  /** move the pointer onto it: what the page shows only on hover shows */
  | { type: 'hover'; id: string }
  | { type: 'toggle'; id: string; on: boolean }
  | { type: 'type'; id: string; text: string }
  | { type: 'select'; id: string; value: string }
  | { type: 'submit'; id: string }
  /** fill a secret field with what the user enters (the host's `askSecret`) */
  | { type: 'fill_secret'; id: string }

export type ActResult = { ok: true } | { ok: false; reason: string; message: string }
export type ReadResult = { ok: true; lines: string[] } | { ok: false }

/** The view and steps: in the dashboard's page (Claude mode; the benchmark's projection.ts), or in Node over any app's page (eval/apps). */
export type ProjectionHooks = {
  /** the page as Claude reads it: whole on a new page or when asked (`full`), else what changed since the last view */
  view(full?: boolean): Promise<string>
  /** forget the view last shown (the model's copy of it was cleared): the next is whole */
  forget(): void | Promise<void>
  /** run one step through the executor */
  act(step: ProjectionStep): Promise<ActResult>
  /** what element `id` (or the page outline, "(page)") holds back; from now on the view carries it too */
  read(id: string): Promise<ReadResult>
  /** open the site's page at a path, as typing its address (a host that can: `open` in ViewSource) */
  open?(path: string): Promise<ActResult>
  /** find a collection's items that match, scrolling it for more (find.ts); a host that wraps the view passes it on to offer find_items */
  find?(query: FindQuery): Promise<FindResult>
}

/** How an option is called, as the tool call that takes it. */
function callOf(c: ActionCandidate): string {
  const s = c.step
  if (s.type === 'click') return `click ${s.target}`
  if (s.type === 'hover') return `hover ${s.target}`
  if (s.type === 'toggle') return `toggle ${s.target} ${s.on ? 'on' : 'off'}`
  if (s.type === 'input') return `type ${s.target}`
  if (s.type === 'select') return `select ${s.target} ${JSON.stringify(s.value)}`
  if (s.type === 'submit') return `submit ${s.target}`
  if (s.type === 'read') return `read ${s.target}`
  if (s.type === 'secret') return `fill_secret ${s.target}`
  return s.type
}

/** Whether a node is a collection, or inside one (guideline 2.6): the collection's own lines show it. */
function inCollection(state: SemanticState, cols: Collection[], id: string) {
  const loc = indexNodes(state.root).get(id)
  return !!loc && !!collectionOf(cols, loc)
}

/** A line of the outline, by the node it's about; `block`, the collection whose lines it's one of. */
type OutlineEntry = { id: string; line: string; block?: string }

/**
 * Where the outline is cut to show at most `limit` lines: never inside a
 * collection, whose lines (at most its head, kind and ITEMS_SHOWN items) run
 * on to its end, so a list is never shown with some of its items gone and its
 * count saying otherwise.
 */
function cutAt(entries: OutlineEntry[], limit: number) {
  let end = Math.min(limit, entries.length)
  while (end > 0 && end < entries.length && entries[end].block && entries[end].block === entries[end - 1].block) end++
  return end
}

/**
 * The outline's entries with each collection in place of its items' lines: its
 * own line, its kind, then its items (the first and last few, or all once
 * read), where it sits on the page.
 */
function withCollections(state: SemanticState, entries: OutlineEntry[], cols: Collection[], calls: ReadonlyMap<string, string[]>, expanded: ReadonlySet<string>, notes: Map<string, string>): OutlineEntry[] {
  if (!cols.length) return entries
  const index = indexNodes(state.root)
  const order = new Map([...index.keys()].map((id, i) => [id, i]))
  const block = (col: Collection): OutlineEntry[] => {
    const all = expanded.has(col.node.id)
    const { items, held, at } = all ? { items: col.items, held: 0, at: col.items.length } : shownItems(col)
    const lines = items.map((item) => ({ id: item.node.id, line: `  ${itemLine(col, item)}` }))
    if (held) lines.splice(at, 0, { id: `${col.node.id}#held`, line: `  … ${held} more items (read ${col.node.id} shows them all)` })
    const own = [{ id: col.node.id, line: headLine(col) }, { id: `${col.node.id}#each`, line: kindLine(col, calls, notes) }, ...lines]
    return own.map((e) => ({ ...e, block: col.node.id }))
  }
  const out: OutlineEntry[] = []
  const placed = new Set<Collection>()
  for (const e of entries) {
    const loc = index.get(e.id)
    const col = loc && collectionOf(cols, loc)
    if (!col) out.push(e)
    else if (!placed.has(col)) {
      placed.add(col)
      out.push(...block(col))
    }
  }
  // a collection none of whose nodes had a line: where it sits in the page's order
  for (const col of cols) {
    if (placed.has(col)) continue
    const mine = order.get(col.node.id) ?? Infinity
    const at = out.findIndex((e) => (order.get(e.id) ?? -1) > mine)
    out.splice(at < 0 ? out.length : at, 0, ...block(col))
  }
  return out
}

/** Notes this long, said word for word on several actions, are written once. */
const LONG_NOTE = 80

/**
 * The actions as the view lists them, by call: a named toolbar's plain buttons
 * on one line (`toolbar 'Formatting': [click button:bold] bold · …`), and a
 * long note an action shares word for word with an earlier one written once.
 */
function compactActions(state: SemanticState, options: ActionCandidate[], notes: Map<string, string> = new Map()) {
  const index = indexNodes(state.root)
  const toolbars = new Map<string, { name: string; buttons: string[] }>()
  const out = new Map<string, string>()
  for (const c of options) {
    const loc = index.get(c.nodeId)
    const bar = loc?.parents.findLast((p) => p.role === 'toolbar' && p.name)
    // a plain button: its option says only what it is
    if (bar && c.step.type === 'click' && loc!.node.role === 'button' && c.description === `button '${loc!.node.name}'`) {
      const t = toolbars.get(bar.id) ?? { name: nameOf(bar), buttons: [] }
      if (!toolbars.has(bar.id)) {
        toolbars.set(bar.id, t)
        out.set(`${t.name}:`, '') // its place among the actions
      }
      t.buttons.push(`[${callOf(c)}] ${loc!.node.name}`)
      continue
    }
    let description = c.description
    const note = /; '([^']{80,})'/.exec(description)?.[1]
    if (note && note.length >= LONG_NOTE) {
      const first = notes.get(note)
      if (first) description = description.replace(`'${note}'`, `(the same note as ${first})`)
      else notes.set(note, `[${callOf(c)}]`)
    }
    out.set(`[${callOf(c)}]`, description)
  }
  for (const t of toolbars.values()) out.set(`${t.name}:`, t.buttons.join(' · '))
  return out
}

/** What a view showed, by what each line is about: outline lines by node, reads by element, actions by tool call; and the popup open then. */
type Shown = { header: string; path: string; outline: Map<string, string>; reading: Map<string, Reading>; actions: Map<string, string>; popup?: string }

const LEGEND = 'Lines start with + (new), - (gone) or ~ (changed, shown as it is now).'

function whole(v: Shown): string {
  return [
    v.header,
    '',
    'Outline:',
    ...v.outline.values(),
    ...(v.reading.size ? ['', 'Read:', ...[...v.reading.values()].flatMap((r) => [`${r.of}:`, ...r.lines.map((l) => `  ${l}`)])] : []),
    '',
    'Actions (the tool call that takes each, then what it does):',
    ...[...v.actions].map(([call, d]) => `${call} ${d}`),
  ].join('\n')
}

/** The lines of a section that are new, gone or changed, in the page's order (gone ones last). */
function changes<T>(was: Map<string, T>, now: Map<string, T>, same: (a: T, b: T) => boolean, line: (key: string, v: T) => string[]): string[] {
  const out: string[] = []
  for (const [k, v] of now) {
    const old = was.get(k)
    if (old === undefined) out.push(...prefixed('+', line(k, v)))
    else if (!same(old, v)) out.push(...prefixed('~', line(k, v)))
  }
  for (const [k, v] of was) if (!now.has(k)) out.push(...prefixed('-', line(k, v).slice(0, 1)))
  return out
}
const prefixed = (mark: string, lines: string[]) => lines.map((l, i) => (i ? `  ${l}` : `${mark} ${l}`))

/** What changed from the view last shown to this one; undefined when nothing did. */
function changed(was: Shown, now: Shown): string | undefined {
  const outline = changes(was.outline, now.outline, (a, b) => a === b, (_, l) => [l])
  const reading = changes(was.reading, now.reading, (a, b) => a.of === b.of && a.lines.join('\n') === b.lines.join('\n'), (_, r) => [`${r.of}:`, ...r.lines])
  const actions = changes(was.actions, now.actions, (a, b) => a === b, (call, d) => [`${call} ${d}`])
  if (!outline.length && !reading.length && !actions.length) return undefined
  return [
    `${now.header}: the same page as your last read_page; only what changed since then (read_page with full: true shows the whole page).`,
    LEGEND,
    ...(outline.length ? ['', 'Outline:', ...outline] : []),
    ...(reading.length ? ['', 'Read:', ...reading] : []),
    ...(actions.length ? ['', 'Actions:', ...actions] : []),
  ].join('\n')
}

export type ViewSource = {
  /** the page's projection for a view (settled: the host's rule, or the harness's after each step) */
  snapshot(): SemanticState | Promise<SemanticState>
  /** run one step through our executor */
  run(step: ActionStep): Promise<ActResult>
  /** the host's own UI, never read or acted on */
  exclude: ReadonlySet<string>
  /** the projection right now, for the policy and the steps' words (default: `snapshot`) */
  now?: () => SemanticState | Promise<SemanticState>
  /** a risky target needs this to go ahead; declined, the step isn't taken (its result: `declined`) */
  confirm?: (prompt: string) => Promise<boolean>
  /** each step taken and its result, and each read, in our agent's words */
  onEvent?: (e: AgentEvent) => void
  /** asks the user for a secret field's secret; with it, the view offers `fill_secret` */
  askSecret?: AskSecret
  /** load the site's page at a path, a whole page load (AgentPage's `open`); with it, the view can open pages */
  open?: (path: string) => Promise<ActResult>
}

/** A step's result when the user declined it (`confirm`, or entering a secret). */
export const DECLINED = 'declined'
/** A `type` into a secret field: refused, a secret is never typed by the model. */
export const SECRET_FIELD = 'secret-field'
/** A `fill_secret` on a field that isn't a secret field: refused. */
export const NOT_SECRET = 'not-secret'
/** A `fill_secret` after which the field holds nothing. */
export const NOT_FILLED = 'not-filled'
/** A step not taken: its target is outside a popup that opened since the view last shown, and only the popup can be used. */
export const BEHIND_POPUP = 'behind-popup'

/**
 * A step in our agent's words: `option`, as offered (the confirmation's
 * prompt); `done`, as the agent's panel lists it ("clicked link 'Campaigns'"),
 * a secret's text left out (`fromUser`: a secret the user entered).
 */
function said(state: SemanticState, step: ActionStep, id: string, exclude: ReadonlySet<string>, fromUser = false) {
  const node = indexNodes(state.root).get(id)?.node
  const type = fromUser ? 'secret' : step.type
  const options = actionCandidates(state, exclude, { secrets: fromUser }).filter((c) => c.nodeId === id && c.step.type === type)
  const option = step.type === 'select' ? (options.find((c) => 'value' in c.step && c.step.value === step.value) ?? options[0]) : options[0]
  const what = option?.what ?? (node ? `${node.role} '${node.name ?? id}'` : id)
  const done =
    fromUser ? `filled ${what} with a secret the user entered`
    : step.type === 'input' ? (isSecretField(node) ? `typed a secret into ${what}` : `typed ${JSON.stringify(step.value)} into ${what}`)
    : step.type === 'toggle' ? `turned ${step.on ? 'on' : 'off'} ${what}`
    : step.type === 'select' ? `chose '${step.value}' in ${what}`
    : step.type === 'submit' ? `submitted ${what}`
    : step.type === 'hover' ? `hovered over ${what}`
    : `clicked ${what}`
  return { node, what, option: option?.description ?? what, done }
}

export function projectionView({ snapshot, run, exclude, now = snapshot, confirm, onEvent, askSecret, open }: ViewSource): ProjectionHooks {
  /** messages showing when the run began, dropped once they change or go (as our agent does) */
  let earlier: Map<string, string> | undefined
  /** what the run has read: its content goes with every view while it's on the page */
  const expanded = new Set<string>()
  /** the view as last shown to the model, with what it has read since */
  let shown: Shown | undefined
  /** the steps taken, numbered for onEvent */
  let steps = 0

  const look = async () => {
    const state = await snapshot()
    const messages = messagesOf(state.root)
    if (!earlier) earlier = messages
    else for (const [id, text] of earlier) if (messages.get(id) !== text) earlier.delete(id)
    const present = indexNodes(state.root)
    for (const id of expanded) if (id !== PAGE && !present.has(id)) expanded.delete(id)
    return state
  }

  /** The page as the view shows it: the outline's lines (collections in place of their items) and the options (collections' and toolbars' controls on their own lines). */
  const pageOf = (state: SemanticState) => {
    const cols = collectionsOf(state, exclude)
    const acts = actionCandidates(state, exclude, { secrets: !!askSecret })
    const calls = new Map<string, string[]>()
    for (const c of acts) calls.set(c.nodeId, [...(calls.get(c.nodeId) ?? []), callOf(c)])
    // long notes said once across the whole view, outline and actions
    const notes = new Map<string, string>()
    const entries = withCollections(state, outlineEntries(state, exclude, earlier), cols, calls, expanded, notes)
    const reads = readCandidates(state, exclude, expanded, entries.length, cutAt(entries, PAGE_LINES)).filter((c) => !inCollection(state, cols, c.nodeId))
    for (const col of cols) {
      if (!expanded.has(col.node.id) && shownItems(col).held) {
        reads.push({ key: `read:${col.node.id}`, description: `read all ${col.items.length} items of ${nameOf(col.node)}`, what: nameOf(col.node), nodeId: col.node.id, step: { type: 'read', target: col.node.id } })
      }
    }
    const { controls, hovers } = collapsedIds(cols)
    const options = acts.filter((c) => !controls.has(c.nodeId) && !(c.step.type === 'hover' && hovers.has(c.nodeId)))
    return { cols, entries, actions: compactActions(state, [...options, ...reads], notes) }
  }

  const current = async (): Promise<Shown> => {
    const state = await look()
    const view = { exclude, earlier, expanded }
    const m = modelState('', state, [], view)
    const { cols, entries, actions } = pageOf(state)
    const reading = new Map<string, Reading>()
    for (const id of expanded) {
      // a read collection shows all its items in the outline instead
      const r = id === PAGE || cols.some((c) => c.node.id === id) ? undefined : revealed(state, new Set([id]))[0]
      if (r) reading.set(id, r)
    }
    return {
      header: `Page: ${m.title} (${m.path})${m.screen ? `, screen ${m.screen}` : ''}`,
      path: m.path,
      outline: new Map(entries.slice(0, cutAt(entries, expanded.has(PAGE) ? PAGE_LINES_READ : PAGE_LINES)).map((e) => [e.id, e.line])),
      reading,
      actions,
      ...(state.context.modalId ? { popup: state.context.modalId } : {}),
    }
  }

  /** A secret field filled with what the user enters: checked first, then asked for, typed, and checked again once the page settles. */
  async function fillSecret(id: string): Promise<ActResult> {
    const state = await now()
    const node = indexNodes(state.root).get(id)?.node
    if (!node) return { ok: false, reason: 'not-found', message: `${id} is not on the page` }
    if (!askSecret || !isSecretField(node)) return { ok: false, reason: NOT_SECRET, message: `${id} is not a secret field` }
    const words = said(state, { type: 'input', target: id, value: '' }, id, exclude, true)
    const risk = confirm && confirmationReason(node)
    if (risk && !(await confirm(`${words.option}: ${risk}. Go ahead?`))) return { ok: false, reason: DECLINED, message: 'The user declined the step.' }
    const entered = await askSecret(words.what)
    if (entered === null) return { ok: false, reason: DECLINED, message: 'The user declined to enter the secret.' }
    const n = ++steps
    onEvent?.({ type: 'acting', step: n, description: words.done })
    let r = await run({ type: 'input', target: id, value: entered })
    if (r.ok && !holdsSecret(await snapshot(), id)) r = { ok: false, reason: NOT_FILLED, message: `${id} holds nothing after filling it` }
    onEvent?.({ type: 'result', step: n, ok: r.ok, detail: r.ok ? '' : r.reason })
    return r
  }

  return {
    async view(full = false) {
      const now = await current()
      const was = shown
      shown = now
      if (full || !was || was.path !== now.path) return whole(now)
      const diff = changed(was, now)
      if (diff === undefined) return `${now.header}: nothing changed since your last read_page.`
      const all = whole(now)
      return diff.length < all.length ? diff : all
    },

    forget() {
      shown = undefined
    },

    async act(step) {
      // The model may write several calls from one view; a later one meets the page an earlier one
      // changed. A target not on the page may be on its way (a menu still closing, a list loading):
      // wait for the page to settle before looking again.
      let state = await now()
      if (!indexNodes(state.root).has(step.id)) state = await snapshot()
      // Still not there, behind a popup the model hasn't seen (an earlier action opened it): only the
      // popup can be used until it closes, so the step isn't taken; the model reads the popup first.
      const popup = state.context.modalId
      if (popup && popup !== shown?.popup && !indexNodes(state.root).has(step.id))
        return { ok: false, reason: BEHIND_POPUP, message: `${step.id} is outside a popup that opened since the last view` }
      if (step.type === 'fill_secret') return fillSecret(step.id)
      const s: ActionStep =
        step.type === 'type' ? { type: 'input', target: step.id, value: step.text }
        : step.type === 'toggle' ? { type: 'toggle', target: step.id, on: step.on }
        : step.type === 'select' ? { type: 'select', target: step.id, value: step.value }
        : { type: step.type, target: step.id }
      if (step.type === 'type' && isSecretField(indexNodes(state.root).get(step.id)?.node))
        return { ok: false, reason: SECRET_FIELD, message: `${step.id} is a secret field` }
      if (!confirm && !onEvent) return run(s)
      const words = said(state, s, step.id, exclude)
      // hovering only shows things: nothing to confirm
      const risk = confirm && s.type !== 'hover' && words.node && confirmationReason(words.node)
      if (risk && !(await confirm(`${words.option}: ${risk}. Go ahead?`))) return { ok: false, reason: DECLINED, message: 'The user declined the step.' }
      const n = ++steps
      onEvent?.({ type: 'acting', step: n, description: words.done })
      const r = await run(s)
      // the panel lists a step once; a failure says why, as our agent's do
      onEvent?.({ type: 'result', step: n, ok: r.ok, detail: r.ok ? '' : r.reason })
      return r
    },

    async find(query) {
      const n = ++steps
      onEvent?.({ type: 'acting', step: n, description: `searched ${query.collection}${query.text ? ` for '${query.text}'` : ''}${query.has ? ` for items with ${query.has}` : ''}` })
      const r = await findItems(query, { snapshot, run, exclude })
      onEvent?.({ type: 'result', step: n, ok: r.ok, detail: r.ok ? r.summary : r.reason })
      return r
    },

    async read(id) {
      onEvent?.({ type: 'reading', step: steps + 1, description: `reading ${id}` })
      const state = await look()
      const col = collectionsOf(state, exclude).find((c) => c.node.id === id)
      if (col) {
        // all its items: from now on the outline shows them all
        expanded.add(id)
        const lines = col.items.map((item) => `  ${itemLine(col, item)}`)
        if (shown) for (const [i, item] of col.items.entries()) shown.outline.set(item.node.id, lines[i])
        return { ok: true, lines }
      }
      if (id === PAGE) {
        const { entries } = pageOf(state)
        const from = cutAt(entries, PAGE_LINES)
        if (entries.length <= from) return { ok: false }
        expanded.add(PAGE)
        const more = entries.slice(from, cutAt(entries, PAGE_LINES_READ))
        // the model has these lines now: the next view doesn't send them as new
        if (shown) for (const e of more) shown.outline.set(e.id, e.line)
        return { ok: true, lines: more.map((e) => e.line) }
      }
      const reading = revealed(state, new Set([id]))[0]
      if (!reading) return { ok: false }
      expanded.add(id)
      shown?.reading.set(id, reading)
      return { ok: true, lines: reading.lines }
    },

    ...(open
      ? {
          async open(path: string): Promise<ActResult> {
            const n = ++steps
            onEvent?.({ type: 'acting', step: n, description: `opened ${path}` })
            const r = await open(path)
            // the page loaded anew, even at the same path: the next view is whole
            shown = undefined
            onEvent?.({ type: 'result', step: n, ok: r.ok, detail: r.ok ? '' : r.reason })
            return r
          },
        }
      : {}),
  }
}
