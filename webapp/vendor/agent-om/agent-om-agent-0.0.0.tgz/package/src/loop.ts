import type { SemanticNode, SemanticState } from '@agent-om/core'
import type { SitemapNode } from '@agent-om/core/sitemap'
import type { ActionStep } from '@agent-om/actions'
import { EMPTY_TEXT, NONE, actionCandidates, answerCandidates, textCandidates, type ActionCandidate, type AnswerCandidate } from './candidates'
import { NO_CHANGE, changeSummary } from './change'
import { choice, noul, type Decide } from './decide'
import { describedOf, indexNodes, labelOf, messagesOf, nameOf, notesOf } from './describe'
import { fillReadback, fillSteps, type FieldFill, type FormFill } from './form'
import { optionKeys, type OptionKeys } from './keys'
import { StepFailed, type AgentPage } from './page'
import { confirmationReason, staleReason } from './policy'
import { PAGE, readCandidates, revealed, rowAnswers, type Reading } from './reveal'
import { holdsSecret, isSecretField, type AskSecret } from './secret'
import { modelState, outlineOf, type ModelState, type ModelView } from './state'
import { CHANGE, stepRequest } from './step'
import { AbortedError } from './util'
import type { Writer } from './writer'

// The agent loop. Each step: look at the settled page, ask the decision model
// whether the goal is met, the next action among every action the page allows,
// and which content shows the answer (step.ts); take its top action, check it
// against the guards and policy, act, and record what changed. The
// decision model never writes: with a writer (decision + writer mode) the
// writer writes the text typed into a field, a whole form's values (a form
// filled in one step, form.ts) and the final answer; without one (decision
// model only) the text is a run of the goal's words and the answer is the
// content the decision model points at, in the page's own words. A secret
// field (a password) is filled only with what the user enters when asked
// (`askSecret`, secret.ts): no model sees or writes it.
//
// The page is looked at once per step: the settled page after a step is the
// next step's page (nothing ran in between), so the wait isn't paid twice.
//
// The top action is taken however its probability is split (several right
// steps share it); finishing has thresholds (`thresholds`). Guards in code
// catch what a model in a loop does when it's lost: steps that change
// nothing, the same step again on an unchanged page, going back and forth.

export type AgentChoice = { key: string; description: string; p: number }

/** Finish (a review's pick, and a decision's `chosen` key when the goal is met). */
export const DONE = 'done'

/** What the decision model answered for a step and what the loop makes of it. */
export type AgentDecision = {
  step: number
  /** the probability that the goal is met */
  done: number
  /** the next action's most probable options (at most 5, `none` among them) */
  next: AgentChoice[]
  /** what the loop does: finish (`done`), find nothing to do (`none`), or the option it takes */
  chosen: AgentChoice
}

export type AgentEvent =
  | { type: 'deciding'; step: number }
  | { type: 'decided'; decision: AgentDecision }
  /** the request is near the size past which the decision model is slower and less accurate */
  | { type: 'large-request'; step: number; bytes: number }
  /** the model reads content the page outline held back (nothing on the page changes) */
  | { type: 'reading'; step: number; description: string }
  /** the writer writes the text for a field, a form's values, or the final answer */
  | { type: 'writing'; step: number; what: 'field' | 'form' | 'answer'; description?: string }
  /** the writer's final answer failed: the run still finishes, its answer the content pointed at */
  | { type: 'writer-failed'; step: number; what: 'answer'; message: string }
  | { type: 'acting'; step: number; description: string }
  | { type: 'result'; step: number; ok: boolean; detail: string }

/** The content the agent pointed at as the answer, in the page's own words. */
export type AgentAnswer = { nodeId: string; label: string; text: string }

export type AgentResult =
  /** `text`: the final answer (the writer's, or the pointed content's own words); `answer`: the content pointed at */
  | { status: 'done'; message: string; text?: string; answer?: AgentAnswer }
  /** nothing on the page moves toward the goal, as the decision model or a guard found */
  | { status: 'blocked'; message: string }
  | { status: 'stopped'; message: string }
  | { status: 'failed'; message: string }

export type AgentOptions = {
  query: string
  page: AgentPage
  decide: Decide
  /** writes the text for a field and the final answer; without one, text is a run of the goal's words */
  writer?: Writer
  /** a risky target, or undoing the previous step, needs this to go ahead (policy from the projection, never the model) */
  confirm: (prompt: string) => Promise<boolean>
  /**
   * Asks the user for the secret a secret field takes (a password), which goes
   * to the page and to no model; declining (null) stops the run. Without it,
   * secret fields aren't offered.
   */
  askSecret?: AskSecret
  /**
   * The decision model found nothing to do ("none" on top, the goal not met): offer the user the most
   * probable steps; their pick (a key) is carried out, null stops. Without it, the run ends blocked.
   */
  unblock?: (prompt: string, options: AgentChoice[]) => Promise<string | null>
  /**
   * Stepping through: called with every decision before it's carried out.
   * Resolve undefined to go on, another option's key (or `done`) to do that
   * instead, or null to stop.
   */
  review?: (decision: AgentDecision, options: AgentChoice[]) => Promise<string | null | undefined>
  /** node ids (with their subtrees) the agent must not use or read, e.g. its own search box */
  exclude?: ReadonlySet<string>
  /** the app's semantic sitemap, if it has one: what pages exist beyond the current one (docs/sitemap.md) */
  sitemap?: SitemapNode
  signal?: AbortSignal
  onEvent?: (event: AgentEvent) => void
  /** steps (actions) per run; default 10 */
  maxSteps?: number
  /** reads of held-back content per run (reveal.ts); they don't count as steps. Default 5 */
  maxReads?: number
  /**
   * When the run finishes: `done`, the probability the goal is met from which it
   * does (default 0.8); `doneWhenNone`, from which it does when "none" is the top
   * next action (default 0.5); `doneWhenStuck`, from which it does when a guard
   * would stop it on a page that hasn't changed (the same step again, steps that
   * change nothing; default 0.4). `unsure`: a top action less probable than this
   * asks the user (`unblock`) instead of being taken; default 0, never.
   */
  thresholds?: { done?: number; doneWhenNone?: number; doneWhenStuck?: number; unsure?: number }
  /**
   * The run's option keys (keys.ts), a fresh set unless given: tests and the
   * benchmark's reachability check give their own, to read back which option
   * a key stands for.
   */
  keys?: OptionKeys
}

/** A request this big (in bytes of JSON) is near the decision model's limit for its normal mode (about 32 KB of text). */
export const LARGE_REQUEST = 30_000
/** Readings kept from earlier pages, and their size in characters. */
export const MEMORY_READINGS = 5
export const MEMORY_CHARS = 2_000
/** Actions in a row that change nothing before the run is blocked. */
export const NO_CHANGE_LIMIT = 3

/** A reading kept after its element left the page: what it was, where, and what it showed. */
export type Remembered = Reading & { on: string }

export async function runAgent(options: AgentOptions): Promise<AgentResult> {
  const { query, page, decide, writer, confirm, askSecret, unblock, review, signal, onEvent, sitemap } = options
  const exclude = options.exclude ?? new Set<string>()
  const maxSteps = options.maxSteps ?? 10
  const maxReads = options.maxReads ?? 5
  const keys = options.keys ?? optionKeys()
  const doneAt = options.thresholds?.done ?? 0.8
  const doneWhenNoneAt = options.thresholds?.doneWhenNone ?? 0.5
  const doneWhenStuckAt = options.thresholds?.doneWhenStuck ?? 0.4
  const unsureBelow = options.thresholds?.unsure ?? 0

  const history: string[] = []
  let step = 0
  let failures = 0
  let staleRetries = 0
  let unchanged = 0
  /** the last option carried out and the page it was carried out on, to catch the same step again on an unchanged page */
  let lastRun: { key: string; page: string } | undefined
  /** the last step that worked, so the agent never silently undoes it */
  let lastDone: ActionStep | undefined
  /** the page after each action, to catch going back and forth */
  const trail: string[] = []
  /** each node as last seen, to report value changes across a popup opening and closing */
  const seen = new Map<string, SemanticNode>()
  const remember = (s: SemanticState) => indexNodes(s.root).forEach(({ node }, id) => seen.set(id, node))
  /** messages showing when the task began; one is dropped once it changes or goes, so a reappearance is news */
  let earlier: Map<string, string> | undefined
  /** elements the model has read: their content goes with every decision while they're on the page */
  const expanded = new Set<string>()
  /** each read element's content as last seen, kept in `memory` once it leaves the page */
  const lastReading = new Map<string, Remembered>()
  const memory: Remembered[] = []
  let reads = 0
  /** the settled page a step ended on: the next step's page, nothing having run since */
  let carried: SemanticState | undefined

  try {
    for (;;) {
      if (signal?.aborted) throw new AbortedError()
      const before = carried ?? (await page.observe(signal))
      carried = undefined
      remember(before)
      const messages = messagesOf(before.root)
      if (!earlier) earlier = messages
      else for (const [id, text] of earlier) if (messages.get(id) !== text) earlier.delete(id)
      // what was read and has left the page (another page included) is remembered, not lost
      const present = indexNodes(before.root)
      for (const id of expanded) {
        if (id === PAGE || present.has(id)) continue
        const last = lastReading.get(id)
        if (last) memory.push(last)
        lastReading.delete(id)
        expanded.delete(id)
      }
      for (const id of expanded) {
        const [reading] = id === PAGE ? [] : revealed(before, new Set([id]))
        if (reading) lastReading.set(id, { ...reading, on: before.context.path })
      }

      const view: ModelView = { exclude, sitemap, earlier, expanded }
      const reading = reads < maxReads ? readCandidates(before, exclude, expanded, outlineOf(before, exclude, earlier).length) : []
      const actions = [...actionCandidates(before, exclude, { fill: !!writer?.form, secrets: !!askSecret }), ...reading]
      const answers = [...answerCandidates(before, exclude, earlier), ...rowAnswers(before, expanded)]
      const state: ModelState & { memory?: string[] } = {
        ...modelState(query, before, history, view),
        ...(memory.length ? { memory: memoryLines(memory) } : {}),
      }
      const { request, options: byKey, answers: answerByKey } = stepRequest(state, actions, answers, keys, { sitemap: !!sitemap })
      onEvent?.({ type: 'deciding', step: step + 1 })
      const bytes = JSON.stringify(request).length
      if (bytes > LARGE_REQUEST) onEvent?.({ type: 'large-request', step: step + 1, bytes })
      const res = await decide(request, signal)

      // Finish when the goal is met (or "none" is the top action and it may well be); else the top action.
      const done = noul(res, 'done')
      const next = choice(res, 'next')
      const describe = (key: string, p = 0): AgentChoice => ({ key, description: byKey.get(key)?.description ?? key, p })
      const ranked = next.ranked.slice(0, 5).map((r) => describe(r.option, r.p))
      let key: string = done >= doneAt || (next.choice === NONE && done >= doneWhenNoneAt) ? DONE : next.choice
      const decision: AgentDecision = { step: step + 1, done, next: ranked, chosen: describe(key, key === DONE ? done : next.confidence) }
      onEvent?.({ type: 'decided', decision })

      if (review) {
        const all = [...byKey].map(([k, o]) => ({ key: k, description: o.description, p: 0 }))
        const picked = await review(decision, all)
        if (picked === null) return { status: 'stopped', message: 'Stopped.' }
        if (picked !== undefined && (picked === DONE || byKey.has(picked))) key = picked
      }

      if (key === DONE) return await finish(before, state, res, answerByKey)
      const unsure = key !== NONE && next.confidence < unsureBelow
      if (key === NONE || !byKey.has(key) || unsure) {
        if (!unblock) return { status: 'blocked', message: 'Nothing on the page moves toward the goal.' }
        // the most probable steps; the page's first ones if the question went unranked
        const top = next.ranked.filter((r) => r.option !== NONE && byKey.has(r.option)).slice(0, 3).map((r) => describe(r.option, r.p))
        const offered = top.length ? top : [...byKey.keys()].slice(0, 3).map((k) => describe(k))
        if (!offered.length) return { status: 'blocked', message: 'Nothing on the page can be used for this.' }
        const picked = await unblock(unsure ? 'Not sure what to do next. Pick a step, or stop:' : 'Not sure how to go on. Pick a step, or stop:', offered)
        if (!picked || !byKey.has(picked)) return { status: 'stopped', message: 'Stopped.' }
        key = picked
      }
      const candidate = byKey.get(key)!

      // A read: the element's content goes with the next decisions; nothing on the page changes.
      if (candidate.step.type === 'read') {
        expanded.add(candidate.step.target)
        reads++
        onEvent?.({ type: 'reading', step: step + 1, description: candidate.description })
        history.push(`(${candidate.description})`)
        continue
      }
      if (step >= maxSteps) return { status: 'failed', message: `Stopped after ${maxSteps} steps without reaching the goal.` }

      // Guard: the same step again on a page that hasn't changed since it ran.
      const here = fingerprint(before)
      // Stuck on an unchanged page that may well be the goal (an in-page anchor clicked again on the
      // right help page): finish there, not stop.
      if (lastRun?.key === key && lastRun.page === here)
        return done >= doneWhenStuckAt
          ? await finish(before, state, res, answerByKey)
          : { status: 'blocked', message: 'Stopped: the same step again on a page that has not changed.' }

      // A whole form in one step: the writer gives every field its value.
      if (candidate.step.type === 'fill') {
        const outcome = await fillForm(candidate, candidate.step.fill, before, state, res, answerByKey, key, here, done)
        if (outcome) return outcome
        continue
      }

      let stepToRun: ActionStep
      if (candidate.step.type === 'input') {
        const text = await textFor(candidate, before, state)
        if (text === null) {
          // the writer found nothing to type: a step that changed nothing, said so
          step++
          history.push(`${step}. no text to type into ${candidate.what}: nothing in the goal or on the page gives a value`)
          onEvent?.({ type: 'result', step, ok: false, detail: 'no text' })
          lastRun = { key, page: here }
          if (++unchanged >= NO_CHANGE_LIMIT) return done >= doneWhenStuckAt ? await finish(before, state, res, answerByKey) : blocked()
          continue
        }
        stepToRun = { type: 'input', target: candidate.nodeId, value: text }
      } else if (candidate.step.type === 'secret') {
        // the value: what the user enters once the step has passed the policy, given to the page only
        stepToRun = { type: 'input', target: candidate.nodeId, value: '' }
      } else stepToRun = candidate.step

      // Policy, against a fresh look at the page.
      const decided = indexNodes(before.root).get(candidate.nodeId)!.node
      const stale = staleReason(decided, await page.snapshot())
      if (stale) {
        if (++staleRetries > 2) return { status: 'failed', message: 'The page keeps changing under the chosen step.' }
        history.push(`(not done: ${nameOf(decided)} ${stale}; deciding again)`)
        continue
      }
      staleRetries = 0
      // hovering only shows things: nothing to confirm, whatever the element does when clicked
      const risk = stepToRun.type === 'hover' ? undefined : confirmationReason(decided)
      if (risk && !(await confirm(`${candidate.description}: ${risk}. Go ahead?`))) return { status: 'stopped', message: 'Cancelled.' }
      if (undoesLast(stepToRun, lastDone) && !(await confirm(`${candidate.description} would undo the previous step. Go ahead?`)))
        return { status: 'stopped', message: 'Cancelled.' }
      const fromUser = candidate.step.type === 'secret'
      const entered = fromUser ? await askSecret!(candidate.what, signal) : null
      if (fromUser && entered === null) return { status: 'stopped', message: 'Cancelled.' }

      // Act.
      step++
      const secret = isSecretField(decided)
      const description = describeStep(candidate, stepToRun, secret, fromUser)
      onEvent?.({ type: 'acting', step, description })
      lastRun = { key, page: here }
      try {
        await page.act(fromUser ? { type: 'input', target: candidate.nodeId, value: entered! } : stepToRun, signal)
      } catch (e) {
        if (!(e instanceof StepFailed)) throw e
        if (e.reason === 'aborted') throw new AbortedError()
        failures++
        history.push(`${step}. ${description} → failed (${e.reason})`)
        onEvent?.({ type: 'result', step, ok: false, detail: e.reason })
        if (failures >= 2) return { status: 'failed', message: `Stopped after repeated failures (last: ${e.reason}).` }
        continue
      }
      failures = 0
      lastDone = stepToRun
      const after = await page.observe(signal)
      carried = after
      const change = changeSummary(before, after, seen)
      remember(after)
      // a field that turns out to hold a secret once typed into (redacted by the app) is said so too
      const typedSecret = !secret && stepToRun.type === 'input' && holdsSecret(after, candidate.nodeId)
      // a secret the user entered: the field holds a value now, or it wasn't filled
      const notFilled = fromUser && !holdsSecret(after, candidate.nodeId)
      const outcome = notFilled ? `not filled: it holds nothing${change !== NO_CHANGE ? `; ${change}` : ''}` : change
      history.push(`${step}. ${typedSecret ? describeStep(candidate, stepToRun, true) : description} → ${outcome}`)
      onEvent?.({ type: 'result', step, ok: !notFilled, detail: outcome })

      // Guards: steps that change nothing, going back and forth.
      unchanged = change === NO_CHANGE ? unchanged + 1 : 0
      if (unchanged >= NO_CHANGE_LIMIT) return done >= doneWhenStuckAt ? await finish(before, state, res, answerByKey) : blocked()
      trail.push(fingerprint(after))
      if (backAndForth(trail)) return { status: 'blocked', message: 'Stopped: going back and forth between the same two pages.' }
    }
  } catch (e) {
    if (e instanceof AbortedError || signal?.aborted) return { status: 'stopped', message: 'Stopped.' }
    return { status: 'failed', message: e instanceof Error ? e.message : String(e) }
  }

  /**
   * A form filled in one step: the writer's values, set field by field in page
   * order, then the form read back for the history. Returns the run's end,
   * or undefined to go on to the next step.
   */
  async function fillForm(
    candidate: ActionCandidate,
    fill: FormFill,
    before: SemanticState,
    modelView: ModelState,
    res: Awaited<ReturnType<Decide>>,
    answerByKey: Map<string, AnswerCandidate>,
    key: string,
    here: string,
    done: number,
  ): Promise<AgentResult | undefined> {
    const name = candidate.what
    onEvent?.({ type: 'writing', step: step + 1, what: 'form', description: name })
    const values = await writer!.form!({ state: modelView, form: { name, fields: fill.fields } }, signal)
    const { fills, dropped } = fillSteps(fill.fields, values)
    const toRun = fills.filter((f) => f.step)
    const notOffered = dropped.length ? `no such choice for ${dropped.join(', ')}` : ''
    if (!toRun.length) {
      // nothing to set: a step that changed nothing, said so
      step++
      history.push(`${step}. nothing to fill in ${name}: ${notOffered || (fills.length ? 'its fields already hold those values' : 'nothing in the goal or on the page gives a value')}`)
      onEvent?.({ type: 'result', step, ok: false, detail: 'nothing to fill' })
      lastRun = { key, page: here }
      if (++unchanged >= NO_CHANGE_LIMIT) return done >= doneWhenStuckAt ? await finish(before, modelView, res, answerByKey) : blocked()
      return undefined
    }

    // Policy, against a fresh look at the page: the form and every field the fill sets.
    const index = indexNodes(before.root)
    const targets = [candidate.nodeId, ...toRun.map((f) => String((f.step as { target: unknown }).target))]
    const now = await page.snapshot()
    for (const id of targets) {
      const node = index.get(id)?.node
      const stale = node && staleReason(node, now)
      if (stale) {
        if (++staleRetries > 2) return { status: 'failed', message: 'The page keeps changing under the chosen step.' }
        history.push(`(not done: ${nameOf(node)} ${stale}; deciding again)`)
        return undefined
      }
    }
    staleRetries = 0
    const risky = targets.map((id) => index.get(id)?.node).find((n) => n && confirmationReason(n))
    if (risky && !(await confirm(`${candidate.description}: ${confirmationReason(risky)}. Go ahead?`))) return { status: 'stopped', message: 'Cancelled.' }

    step++
    onEvent?.({ type: 'acting', step, description: `filling ${name}: ${toRun.map((f) => `${f.field.label} ${f.said}`).join(', ')}` })
    lastRun = { key, page: here }
    const ran = new Set<FieldFill>()
    let failed: { label: string; reason: string } | undefined
    for (const f of toRun) {
      try {
        await page.act(f.step!, signal)
        ran.add(f)
        lastDone = f.step
      } catch (e) {
        if (!(e instanceof StepFailed)) throw e
        if (e.reason === 'aborted') throw new AbortedError()
        failed = { label: f.field.label, reason: e.reason }
        break
      }
    }
    const after = await page.observe(signal)
    carried = after
    // what was set, and what already held its value (in page order)
    const set = fills.filter((f) => !f.step || ran.has(f))
    const readback = fillReadback(name, set, fill.fields, after, fill.formId)
    // the fields and their error messages: the readback says them
    const fieldIds = new Set(fill.fields.flatMap((f) => (f.radios ? f.radios.map((r) => r.nodeId) : [f.nodeId])))
    const quiet = new Set(fieldIds)
    for (const { node } of indexNodes(after.root).values()) if (fieldIds.has(node.id) && node.errorMessage) quiet.add(node.errorMessage)
    const change = changeSummary(before, after, seen, quiet)
    remember(after)
    const tail = [failed ? `failed at ${failed.label} (${failed.reason})` : '', notOffered, change !== NO_CHANGE ? change : ''].filter(Boolean)
    history.push(`${step}. ${readback}${tail.length ? ` → ${tail.join('; ')}` : ''}`)
    onEvent?.({ type: 'result', step, ok: !failed, detail: failed ? `failed at ${failed.label} (${failed.reason})` : readback })

    if (failed) {
      if (++failures >= 2) return { status: 'failed', message: `Stopped after repeated failures (last: ${failed.reason}).` }
    } else failures = 0
    // Guards: a fill that set nothing changed nothing; going back and forth.
    unchanged = ran.size ? 0 : unchanged + 1
    if (unchanged >= NO_CHANGE_LIMIT) return done >= doneWhenStuckAt ? await finish(before, modelView, res, answerByKey) : blocked()
    trail.push(fingerprint(after))
    if (backAndForth(trail)) return { status: 'blocked', message: 'Stopped: going back and forth between the same two pages.' }
    return undefined
  }

  function blocked(): AgentResult {
    return { status: 'blocked', message: `Stopped: ${NO_CHANGE_LIMIT} steps in a row changed nothing.` }
  }

  /**
   * Finish: the content the decision model points at, and the writer's answer
   * if there is a writer, unless the goal asked for a change (the answer
   * question's `change`): then there's nothing to tell, and no writer call.
   */
  async function finish(
    state: SemanticState,
    modelView: ModelState,
    res: Awaited<ReturnType<Decide>>,
    answerByKey: Map<string, AnswerCandidate>,
  ): Promise<AgentResult> {
    const a = res.answer ? choice(res, 'answer').choice : NONE
    const found = a !== NONE ? answerByKey.get(a) : undefined
    let answer: AgentAnswer | undefined
    if (found) {
      await page.scroll(found.nodeId)
      const node = indexNodes(state.root).get(found.nodeId)?.node
      answer = { nodeId: found.nodeId, label: found.label ?? (node ? (labelOf(node) ?? nameOf(node)) : found.nodeId), text: found.text }
    }
    let text = answer?.text
    if (writer && a !== CHANGE) {
      onEvent?.({ type: 'writing', step: step + 1, what: 'answer' })
      // the goal is met: a failed answer doesn't undo that (a stop by the user still stops)
      try {
        text = (await writer.answer({ state: modelView }, signal)) || text
      } catch (e) {
        if (e instanceof AbortedError || signal?.aborted) throw e
        onEvent?.({ type: 'writer-failed', step: step + 1, what: 'answer', message: e instanceof Error ? e.message : String(e) })
      }
    }
    const message = history.length || writer ? 'Done.' : 'Nothing to do: the page already shows it.'
    return { status: 'done', message, ...(text ? { text } : {}), ...(answer ? { answer } : {}) }
  }

  /** The text to type: the writer's, or the decision model's pick of a run of the goal's words. */
  async function textFor(candidate: ActionCandidate, state: SemanticState, modelView: ModelState): Promise<string | null> {
    const loc = indexNodes(state.root).get(candidate.nodeId)!
    // the whole page as for every decision: what the field searches or filters is on the page, not in its label
    const field = candidate.what + notesOf(loc.node) + describedOf(loc.node)
    if (writer) {
      onEvent?.({ type: 'writing', step: step + 1, what: 'field', description: candidate.what })
      return writer.field({ state: { ...modelView, field } }, signal)
    }
    const texts = textCandidates(query)
    const res = await decide(
      {
        state: { ...modelView, field },
        questions: {
          text: {
            type: 'choice',
            instructions: 'Which text from `goal` should be typed into `field`? `page` shows what is on the page, `history` what was already done.',
            criteria: Object.fromEntries(texts.map((t) => [t, t === EMPTY_TEXT ? 'Leave the field empty' : `Type "${t}"`])),
          },
        },
      },
      signal,
    )
    const t = choice(res, 'text').choice
    return t === EMPTY_TEXT ? '' : t
  }
}

/** The page, for telling whether it changed: its place and its projection, focus aside. */
function fingerprint(state: SemanticState) {
  const { path, query } = state.context
  return `${path}?${JSON.stringify(query)}|${JSON.stringify(state.root, (k, v) => (k === 'focused' ? undefined : v))}`
}

/** The last four pages alternate between two: A, B, A, B. */
function backAndForth(trail: string[]) {
  if (trail.length < 4) return false
  const [a, b, c, d] = trail.slice(-4)
  return a !== b && a === c && b === d
}

/** Turning a toggle back the other way right after setting it. */
function undoesLast(step: ActionStep, last: ActionStep | undefined) {
  return step.type === 'toggle' && last?.type === 'toggle' && step.target === last.target && step.on !== last.on
}

/** Readings from earlier pages, newest last, within the memory's size. */
function memoryLines(memory: Remembered[]): string[] {
  const out: string[] = []
  let size = 0
  for (const m of memory.slice(-MEMORY_READINGS).reverse()) {
    const line = `${m.of} (on ${m.on}): ${m.lines.join(' | ')}`
    const room = MEMORY_CHARS - size
    if (room <= 0) break
    out.unshift(line.length > room ? `${line.slice(0, room - 1)}…` : line)
    size += Math.min(line.length, room)
  }
  return out
}

/**
 * A step in a few words, for the history: "clicked link 'Acquisition'",
 * "typed \"reddit\" into searchbox 'Search referrers'". A secret is never said:
 * "filled textbox 'Password' with a secret the user entered" (`fromUser`), or
 * "typed a secret into …" for text a field turned out to keep secret.
 */
function describeStep(candidate: ActionCandidate, step: ActionStep, secret = false, fromUser = false) {
  const what = candidate.what
  if (fromUser) return `filled ${what} with a secret the user entered`
  if (step.type === 'input') return secret ? `typed a secret into ${what}` : `typed "${step.value}" into ${what}`
  if (step.type === 'toggle') return `turned ${step.on ? 'on' : 'off'} ${what}`
  if (step.type === 'select') return `chose '${step.value}' in ${what}`
  if (step.type === 'submit') return `submitted ${what}`
  if (step.type === 'hover') return `hovered over ${what}`
  return `clicked ${what}`
}
