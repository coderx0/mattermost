import { ACTIONABLE_ROLES, type SemanticState } from '@agent-om/core'
import { LIST_SHOWN, MAX_CONTENT, contentOf, indexNodes, nameOf, outlinedList, type Located } from './describe'
import type { ActionCandidate, AnswerCandidate } from './candidates'

// Progressive disclosure: the page outline holds content back to stay short (a
// table's rows, a list's items, what content shows, outline lines past its
// cap). The model reads it when it needs it: each held-back element is a
// `read:<id>` option; once read, the element stays expanded and every decision
// carries its current content, rebuilt from the latest snapshot. Nothing here
// acts on the page. The projection already holds all of it (`table.rows`,
// `items`, `text`); this only decides when the model sees it.

/** The outline's own lines past its cap, as one readable thing. */
export const PAGE = '(page)'
export const READ = 'read:'

/** Lines of the outline sent before the rest are held back, and once they're read. */
export const PAGE_LINES = 60
export const PAGE_LINES_READ = 300


/** What an element reveals when read: its label in the outline's words, and its lines. */
export type Reading = { of: string; lines: string[] }

const outside = (loc: Located, exclude: ReadonlySet<string>) =>
  exclude.has(loc.node.id) || loc.parents.some((p) => exclude.has(p.id))

/** A row as "Header: cell · Header: cell", skipping empty cells (a checkbox column, an actions column). */
export function rowLine(columns: string[], cells: string[]) {
  const parts = cells.flatMap((cell, i) => {
    if (!cell) return []
    const header = columns.length === cells.length ? columns[i] : ''
    return [header ? `${header}: ${cell}` : cell]
  })
  return parts.join(' · ')
}

/**
 * Content the outline names without showing what it shows: annotated content
 * (a metric's value, a chart's summary), not inside other content (that one's
 * read shows it).
 */
const namedContent = ({ node, parents }: Located) =>
  !!node.name && !!node.kind && !ACTIONABLE_ROLES.has(node.role) && !parents.some((p) => p.kind)

/** What a node holds back from the outline, and what reading it shows; undefined if nothing. */
function heldBack(loc: Located): { what: string; lines: string[] } | undefined {
  const { node } = loc
  const table = node.table
  if (table && table.rows.length) {
    const lines = table.rows.map((cells) => rowLine(table.columns, cells))
    // the projection holds the first rows only (its row cap): say so, or the
    // ones held read as the whole table (a 91-day range read as ending on day 50)
    const rest = table.totalRows - table.rows.length
    if (rest > 0) {
      return {
        what: `the first ${table.rows.length} of ${table.totalRows} rows of ${nameOf(node)}`,
        lines: [...lines, `(the other ${rest} rows of the ${table.totalRows} can't be read)`],
      }
    }
    return { what: `the rows of ${nameOf(node)} (${table.rows.length} on the page)`, lines }
  }
  if (node.items && node.items.length > LIST_SHOWN) {
    return { what: `all ${node.items.length} items of ${nameOf(node)}`, lines: node.items }
  }
  // what content shows is read when it's needed (to judge a goal met, typically on the last step)
  if (namedContent(loc)) {
    const text = contentOf(node, true)
    return text ? { what: nameOf(node), lines: [text] } : undefined
  }
  // a named list the outline shows its first items of: the rest
  if (outlinedList(node, loc.parents) && contentOf(node, true) !== contentOf(node)) {
    return { what: `all of ${nameOf(node)}`, lines: [contentOf(node, true)] }
  }
  // content without a name is shown by what it shows, cut (status text never is)
  if (node.kind && contentOf(node, true).length > MAX_CONTENT) {
    return { what: `all of ${nameOf(node)}`, lines: [contentOf(node, true)] }
  }
  return undefined
}

/**
 * One `read:` option per element whose content the outline holds back and
 * that isn't expanded yet (inside the open popup only, while one is: the rest
 * of the page can't be used until it closes); plus the page outline's own
 * lines past its cap (`shown`: the lines the outline shows, its cap unless
 * a view cuts it elsewhere).
 */
export function readCandidates(
  state: SemanticState,
  exclude: ReadonlySet<string>,
  expanded: ReadonlySet<string>,
  outlineLines: number,
  shown = PAGE_LINES,
): ActionCandidate[] {
  const out: ActionCandidate[] = []
  const modal = state.context.modalId
  for (const loc of indexNodes(state.root).values()) {
    if (expanded.has(loc.node.id) || outside(loc, exclude)) continue
    if (modal && loc.node.id !== modal && !loc.parents.some((p) => p.id === modal)) continue
    const held = heldBack(loc)
    const id = loc.node.id
    if (held) out.push({ key: READ + id, description: `read ${held.what}`, what: nameOf(loc.node), nodeId: id, step: { type: 'read', target: id } })
  }
  if (!expanded.has(PAGE) && outlineLines > shown) {
    out.push({
      key: READ + PAGE,
      description: `read the rest of the page outline (${outlineLines - shown} more lines)`,
      what: 'the page outline',
      nodeId: state.root.id,
      step: { type: 'read', target: PAGE },
    })
  }
  return out
}

/** The current content of every expanded element still on the page (the page outline itself excepted). */
export function revealed(state: SemanticState, expanded: ReadonlySet<string>): Reading[] {
  const index = indexNodes(state.root)
  const out: Reading[] = []
  for (const id of expanded) {
    const loc = index.get(id)
    const held = loc && heldBack(loc)
    if (held) out.push({ of: nameOf(loc.node), lines: held.lines })
  }
  return out
}

/**
 * A read table's rows as answers, by their first cell ("row 3 'reddit.com'";
 * what each holds is in `reading`), with the table's name when more than one
 * table has been read.
 */
export function rowAnswers(state: SemanticState, expanded: ReadonlySet<string>): AnswerCandidate[] {
  const index = indexNodes(state.root)
  const tables = [...expanded].flatMap((id) => {
    const node = index.get(id)?.node
    return node?.table ? [node] : []
  })
  const out: AnswerCandidate[] = []
  for (const node of tables) {
    const of = tables.length > 1 ? ` of ${nameOf(node)}` : ''
    node.table!.rows.forEach((cells, i) => {
      const text = rowLine(node.table!.columns, cells)
      if (!text) return
      const label = cells.find(Boolean)
      out.push({
        key: `${node.id}#row-${i + 1}`,
        description: `row ${i + 1}${label ? ` '${label}'` : ''}${of}`,
        nodeId: node.id,
        text,
        label,
      })
    })
  }
  return out
}
