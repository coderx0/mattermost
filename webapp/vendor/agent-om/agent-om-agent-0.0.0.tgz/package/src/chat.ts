// One call to a generative model through OpenRouter's chat completions, with
// structured output: the reply is JSON matching `schema`, never free text.
// Used by the writer (writer.ts).
// https://openrouter.ai/docs/api/reference/overview

export type ChatRequest = {
  /** what the model is for and how to read the message */
  system: string
  /** the message: the situation, as JSON */
  user: unknown
  /** JSON Schema of the reply (strict: an object with required fields only) */
  schema: Record<string, unknown>
  /**
   * How much the model reasons before replying (`reasoning.effort`); `none` turns it off.
   * Unset, the model's own default applies (some reason by default).
   */
  reasoning?: 'none' | 'low' | 'medium' | 'high'
}

export type Chat = <T>(request: ChatRequest, signal?: AbortSignal) => Promise<T>

/**
 * The JSON object in a structured-output reply, or undefined if there is none.
 * Models don't always send the object alone: with reasoning off, Mercury 2.5
 * sometimes followed it with a stray code fence ("{…}\n```"), or wrapped it in
 * one. The object is read from its first "{" to its last "}".
 */
export function replyObject(content: string): unknown {
  const start = content.indexOf('{')
  const end = content.lastIndexOf('}')
  if (start < 0 || end < start) return undefined
  try {
    return JSON.parse(content.slice(start, end + 1))
  } catch {
    return undefined
  }
}

/** Calls made for one request when the reply holds no JSON object (an empty reply): the first and one more. */
export const CHAT_ATTEMPTS = 2

/** `model`: an OpenRouter chat model id that supports structured output (see models.ts). */
export function openRouterChat(apiKey: string, model: string, fetchImpl: typeof fetch = (...a) => fetch(...a)): Chat {
  return async <T>({ system, user, schema, reasoning }: ChatRequest, signal?: AbortSignal) => {
    let content = ''
    for (let attempt = 1; ; attempt++) {
      const res = await fetchImpl('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model,
          messages: [
            { role: 'system', content: system },
            { role: 'user', content: JSON.stringify(user) },
          ],
          response_format: { type: 'json_schema', json_schema: { name: 'reply', strict: true, schema } },
          ...(reasoning ? { reasoning: { effort: reasoning } } : {}),
        }),
        signal,
      })
      const body = (await res.json().catch(() => null)) as {
        choices?: { message?: { content?: string } }[]
        error?: { message?: string }
      } | null
      const got = body?.choices?.[0]?.message?.content
      if (!res.ok || typeof got !== 'string') {
        throw new Error(`Chat API ${res.status}: ${body?.error?.message ?? res.statusText}`)
      }
      content = got
      const reply = replyObject(content)
      if (reply !== undefined) return reply as T
      if (attempt >= CHAT_ATTEMPTS) break
    }
    throw new Error(`Chat API: not JSON: ${JSON.stringify(content.slice(0, 200))}`)
  }
}
