import type { ActionCandidate, AnswerCandidate } from './candidates'

// The keys the models choose by: short and stable for the whole run. Each
// element gets a number the first time it's offered and keeps it, so a key
// means the same element in every step, in the history and in a hand-off to
// the reasoning model: `a7` acts on element 7 (clicks, toggles or types into
// it), `a7.2` chooses the second choice of a drop-down that was offered,
// `h7` hovers over it (to show what the page shows only on hover),
// `r7` reads what element 7 holds back, `c7` points at it as the answer
// (`c7#3`: its third row), `f7` fills form 7 in one step (`f7.2`: the second
// part of a large one). The descriptions say what each does; the loop maps
// a key back to its option (and the option to its node).

export type OptionKeys = {
  /** the key an action is offered under */
  action(c: ActionCandidate): string
  /** the key an answer is offered under */
  answer(c: AnswerCandidate): string
  /** the option's own key (ActionCandidate.key or AnswerCandidate.key) a short key was last given for */
  ref(key: string): string | undefined
}

export function optionKeys(): OptionKeys {
  const numbers = new Map<string, number>()
  /** a drop-down's choices, numbered as they're first offered */
  const choices = new Map<string, Map<string, number>>()
  const refs = new Map<string, string>()
  const number = (id: string) => {
    let n = numbers.get(id)
    if (n === undefined) numbers.set(id, (n = numbers.size + 1))
    return n
  }
  const keep = (key: string, ref: string) => (refs.set(key, ref), key)
  return {
    action(c) {
      const s = c.step
      if (s.type === 'read') return keep(`r${number(s.target)}`, c.key)
      if (s.type === 'hover') return keep(`h${number(c.nodeId)}`, c.key)
      if (s.type === 'fill') return keep(`f${number(s.target)}${s.fill.chunks > 1 ? `.${s.fill.chunk}` : ''}`, c.key)
      if (s.type === 'select') {
        const of = choices.get(c.nodeId) ?? choices.set(c.nodeId, new Map()).get(c.nodeId)!
        const value = String(s.value)
        let i = of.get(value)
        if (i === undefined) of.set(value, (i = of.size + 1))
        return keep(`a${number(c.nodeId)}.${i}`, c.key)
      }
      return keep(`a${number(c.nodeId)}`, c.key)
    },
    answer(c) {
      const row = /#row-(\d+)$/.exec(c.key)?.[1]
      return keep(`c${number(c.nodeId)}${row ? `#${row}` : ''}`, c.key)
    },
    ref: (key) => refs.get(key),
  }
}
