import { describe, expect, it } from 'vitest'
import type { SitemapNode } from '@agent-om/core/sitemap'
import { siteOutline } from './site-outline'

const MAP: SitemapNode = {
  path: '/',
  name: 'Home',
  children: [
    { path: 'campaigns', views: { view: ['archived'] }, children: [{ path: '{campaignId}', views: { tab: ['performance', 'ad-groups'] } }] },
    { path: 'products/{handle}', holds: ['Product Information', 'Shipping & Returns'] },
  ],
}

describe('siteOutline', () => {
  it('shows each page with its name, views and what it holds, and marks the current one', () => {
    expect(siteOutline(MAP, '/campaigns/c-1', { tab: 'ad-groups' })).toEqual([
      '/: Home',
      '  campaigns ?view=archived',
      '    {campaignId} ?tab=performance|ad-groups   ← you are here (tab=ad-groups)',
      '  products/{handle} — holds: Product Information, Shipping & Returns',
    ])
  })
})
