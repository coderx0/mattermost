import { NONE, type ActionCandidate, type AnswerCandidate } from './candidates'
import { MAX_CRITERIA, type ChoiceQuestion, type DecideRequest, type NoulQuestion } from './decide'
import type { OptionKeys } from './keys'

// One step's request to the decision model: is the goal met (`done`), the
// next action among every action the page allows (`next`, one flat choice,
// plus "none"), and which content shows the answer (`answer`). Asked
// together and answered independently; the loop combines them (loop.ts).

export const NEXT_INSTRUCTIONS =
  "Choose the single next action that moves toward `goal`. `page` is the page's current state; `history` is what was already done, so don't repeat an action that already worked."
export const NEXT_SITEMAP =
  " `sitemap` lists the app's pages, each indented under the page it sits below, with the current one marked: when the page the goal needs isn't linked from this one, use it to pick the link that leads toward it."
/**
 * Said when a form can be filled in one step (form.ts): offered a form's fill
 * and each of its fields, the decision model mostly took the fields one by
 * one (a new campaign wizard: 4–7 field steps a run, 0–1 fills).
 */
export const NEXT_FILL = ' To set several fields of one form, fill the form at once rather than field by field.'
export const NO_ACTION = 'None of these actions moves toward the goal.'

export const DONE_QUESTION: NoulQuestion = {
  type: 'noul',
  instructions: 'Is `goal` already achieved by what the page shows now? Judge from `page`, `path`, `screen` and `history`.',
  criteria: {
    true: 'The page already shows what the goal asks for, or the requested change has been made. Nothing more to do.',
    false: 'Something still has to be done on the page to achieve the goal.',
  },
}

export const POINT_INSTRUCTIONS = 'If `goal` asks for information, which element on the page shows it?'
export const NO_ANSWER = 'Nothing on the page shows the information the goal asks for.'
/**
 * The answer question's choice for a goal that asks for a change, not for
 * information: a run that finishes on it has nothing to tell, so the writer
 * isn't asked for a final answer (about 1.5 s a run).
 */
export const CHANGE = 'change'
export const CHANGE_ANSWER = 'The goal asks for a change to be made on the page, not for information.'

export type StepRequest = { request: DecideRequest; options: Map<string, ActionCandidate>; answers: Map<string, AnswerCandidate> }

/** The request for one step over `options` (actions and reads) and `answers`, by the run's short keys. */
export function stepRequest(
  state: unknown,
  options: ActionCandidate[],
  answers: AnswerCandidate[],
  keys: OptionKeys,
  { sitemap = false }: { sitemap?: boolean } = {},
): StepRequest {
  // within the API's cap, with room for "none": actions first, reads after them
  const byKey = new Map(options.slice(0, MAX_CRITERIA - 1).map((o) => [keys.action(o), o]))
  const answerByKey = new Map(answers.slice(0, MAX_CRITERIA - 1).map((a) => [keys.answer(a), a]))
  const fills = [...byKey.values()].some((o) => o.step.type === 'fill')
  const next: ChoiceQuestion = {
    type: 'choice',
    instructions: NEXT_INSTRUCTIONS + (sitemap ? NEXT_SITEMAP : '') + (fills ? NEXT_FILL : ''),
    criteria: { ...Object.fromEntries([...byKey].map(([k, o]) => [k, o.description])), [NONE]: NO_ACTION },
  }
  const answer: ChoiceQuestion = {
    type: 'choice',
    instructions: POINT_INSTRUCTIONS,
    criteria: { ...Object.fromEntries([...answerByKey].map(([k, a]) => [k, a.description])), [NONE]: NO_ANSWER, [CHANGE]: CHANGE_ANSWER },
  }
  return { request: { state, questions: { done: DONE_QUESTION, next, answer } }, options: byKey, answers: answerByKey }
}
