import { defineConfig } from 'vitest/config'

// The agent reasons over projection snapshots, which are plain data: its tests
// run in Node (no browser), which also shows it can run outside the page,
// driving one through Playwright. The real app's end-to-end tests are the
// dashboard's (apps/dashboard/src/agent.test.tsx).
export default defineConfig({
  test: {
    include: ['src/**/*.test.ts'],
    environment: 'node',
  },
})
