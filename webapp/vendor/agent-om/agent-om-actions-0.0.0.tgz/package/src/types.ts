/**
 * What an action acts on: an element, a function returning one (called each
 * time the step checks its target, so it follows re-renders), or a string the
 * host's `resolveTarget` option turns into an element.
 */
export type ActionTarget = Element | string | (() => Element | null | undefined)

/** A string target (met once it resolves to an element) or a function (met once it returns truthy). */
export type WaitCondition = string | (() => unknown)

/** One action. A sequence of these is the whole action language. */
export type ActionStep =
  | { type: 'click'; target: ActionTarget }
  /** Move the pointer onto the target, as a user does to show what the page shows only on hover. */
  | { type: 'hover'; target: ActionTarget }
  /** Replace the field's value. */
  | { type: 'input'; target: ActionTarget; value: string }
  /** Native `<select>`: option value or label; several for `<select multiple>`. */
  | { type: 'select'; target: ActionTarget; value: string | string[] }
  /** Flip a checkbox, switch, pressed or expanded control; with `on`, set it (no-op if already so). */
  | { type: 'toggle'; target: ActionTarget; on?: boolean }
  /** Submit the target form, or the form the target belongs to (a submit button becomes the submitter). */
  | { type: 'submit'; target: ActionTarget }
  | { type: 'scroll'; target: ActionTarget; smooth?: boolean }
  | { type: 'wait'; ms: number }
  | { type: 'wait'; until: WaitCondition; timeout?: number }

export const ACTION_FAILURES = [
  /** the target didn't resolve to a connected element */
  'not-found',
  /** not rendered (display: none, hidden, closed details...) */
  'not-rendered',
  'inert',
  'disabled',
  /** another element is on top of it at its centre (overlay, sticky header, modal backdrop) */
  'covered',
  /** input on something that isn't a text-like input or textarea */
  'not-editable',
  'readonly',
  /** select on something that isn't a native <select>, or several values on a single select */
  'not-selectable',
  'no-option',
  /** toggle on something with no checked / pressed / expanded state */
  'not-toggleable',
  /** toggle clicked, but the state didn't change */
  'unchanged',
  /** submit on something that isn't in a form */
  'no-form',
  /** the form fails constraint validation, so it wasn't submitted */
  'invalid',
  /** a wait condition wasn't met in time */
  'timeout',
  'aborted',
  /** a string target, but no resolveTarget option */
  'no-resolver',
] as const

export type ActionFailure = (typeof ACTION_FAILURES)[number]
